/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name  : MotRefMdl.h
* Module Description: MotRefMdl Header Stub
* Project           : CBD
* Author            : Selva Sengottaiyan
***********************************************************************************************************************
* Version Control:
* %version:          2 %
* %derived_by:       nz4qtt %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 06/02/15  1        Selva       Initial Version                                                                 EA4#299
**********************************************************************************************************************/


#define  MOTREFMDL_INVTERDEADTIBRDGVLTGSCAHILIM_ULS_F32  1.0F
#define  MOTREFMDL_INVTERDEADTIBRDGVLTGSCALOLIM_ULS_F32  0.8F

