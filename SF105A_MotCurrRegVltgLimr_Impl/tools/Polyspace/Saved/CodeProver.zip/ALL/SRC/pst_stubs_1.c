#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern struct __PST__g__23 _main_gen_init_g23(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__g__22 _main_gen_init_g22(void);

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__23 _main_gen_init_g23(void)
{
    static struct __PST__g__23 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_AntiWdupCmdScaDax(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_AntiWdupCmdScaDax;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_AntiWdupCmdScaDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_AntiWdupCmdScaQax(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_AntiWdupCmdScaQax;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_AntiWdupCmdScaQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_CurrLoaScarPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_CurrLoaScarPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_CurrLoaScarPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_DualEcuLoaScarPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_DualEcuLoaScarPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_DualEcuLoaScarPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_FETLoaScarPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_FETLoaScarPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_FETLoaScarPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_IvtrLoaScarPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_IvtrLoaScarPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_IvtrLoaScarPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgBrdgLpFil(void)
{
    extern struct __PST__g__23 MotCurrRegVltgLimr_Pim_MotVltgBrdgLpFil;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_MotVltgBrdgLpFil = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgQaxFfLpFil(void)
{
    extern struct __PST__g__23 MotCurrRegVltgLimr_Pim_MotVltgQaxFfLpFil;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_MotVltgQaxFfLpFil = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrCurrLoaScarSlewRate(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrCurrLoaScarSlewRate;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrCurrLoaScarSlewRate = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDaxAntiWdupCoeff(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDaxAntiWdupCoeff;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDaxAntiWdupCoeff = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDualEcuLoaScarSlewRate(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDualEcuLoaScarSlewRate;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDualEcuLoaScarSlewRate = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrFETLoaScarSlewRate(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrFETLoaScarSlewRate;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrFETLoaScarSlewRate = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrIvtrLoaScarSlewRate(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrIvtrLoaScarSlewRate;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrIvtrLoaScarSlewRate = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredEna(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredEna;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredTi(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredTi;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredTi = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgFilEna(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgFilEna;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgFilEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglHiLim(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglHiLim;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglHiLim = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglLoLim(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglLoLim;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglLoLim = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfFilEna(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfFilEna;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfFilEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglHiLim(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglHiLim;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglHiLim = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglLoLim(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglLoLim;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglLoLim = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupCoeff(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupCoeff;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupCoeff = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupScagDi(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupScagDi;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupScagDi = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegCfgCurrLoopSecOrderTrfFctEna(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotCurrRegCfgCurrLoopSecOrderTrfFctEna;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegCfgCurrLoopSecOrderTrfFctEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtDax(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtDax;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtDax = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtQax(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtQax;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtQax = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotRefMdlFbCtrlDi(void)
{
    extern __PST__g__27 MotCurrRegVltgLimr_Cal_MotRefMdlFbCtrlDi;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotRefMdlFbCtrlDi = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca(void)
{
    extern __PST__g__22 MotCurrRegVltgLimr_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDaxIntglPreLim(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDaxIntglPreLim;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDaxIntglPreLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdDax(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdDax;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdQax(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdQax;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxIntglPreLim(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxIntglPreLim;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxIntglPreLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotCtrlMotVltgDaxPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_MotCtrlMotVltgDaxPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_MotCtrlMotVltgDaxPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotCtrlMotVltgQaxPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_MotCtrlMotVltgQaxPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_MotCtrlMotVltgQaxPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgIntglCmdDaxPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_MotVltgIntglCmdDaxPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_MotVltgIntglCmdDaxPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgIntglCmdQaxPrev(void)
{
    extern __PST__FLOAT32 MotCurrRegVltgLimr_Pim_MotVltgIntglCmdQaxPrev;
    
    /* initialization with random value */
    {
        MotCurrRegVltgLimr_Pim_MotVltgIntglCmdQaxPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlBrdgVltg;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElecDly(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAgElecDly;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElecDly = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrDaxCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrDaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxMax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrDaxMax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrDaxMax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotDampgDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotDampgDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotDampgQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotDampgQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotIntglGainDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotIntglGainDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotIntglGainQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotIntglGainQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotPropGainDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotPropGainDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotPropGainQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotPropGainQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotReacncDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotReacncDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotReacncQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotReacncQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDaxFf(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgDaxFf;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgDaxFf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQaxFf(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgQaxFf;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgQaxFf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlSysSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotBackEmfVltg(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotBackEmfVltg;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotBackEmfVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotREstimd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotREstimd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotREstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgQax = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq();
    
    /* init for variable MotCurrRegVltgLimr_Pim_AntiWdupCmdScaDax */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_AntiWdupCmdScaDax();
    
    /* init for variable MotCurrRegVltgLimr_Pim_AntiWdupCmdScaQax */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_AntiWdupCmdScaQax();
    
    /* init for variable MotCurrRegVltgLimr_Pim_CurrLoaScarPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_CurrLoaScarPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_DualEcuLoaScarPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_DualEcuLoaScarPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_FETLoaScarPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_FETLoaScarPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_IvtrLoaScarPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_IvtrLoaScarPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_MotVltgBrdgLpFil */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgBrdgLpFil();
    
    /* init for variable MotCurrRegVltgLimr_Pim_MotVltgQaxFfLpFil */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgQaxFfLpFil();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrCurrLoaScarSlewRate */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrCurrLoaScarSlewRate();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDaxAntiWdupCoeff */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDaxAntiWdupCoeff();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDualEcuLoaScarSlewRate */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrDualEcuLoaScarSlewRate();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrFETLoaScarSlewRate */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrFETLoaScarSlewRate();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrIvtrLoaScarSlewRate */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrIvtrLoaScarSlewRate();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredEna */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredEna();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredTi */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrPredTi();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgFilEna */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgBrdgFilEna();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglHiLim */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglHiLim();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglLoLim */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgDaxIntglLoLim();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfFilEna */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxFfFilEna();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglHiLim */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglHiLim();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglLoLim */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrMotVltgQaxIntglLoLim();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupCoeff */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupCoeff();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupScagDi */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegVltgLimrQaxAntiWdupScagDi();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegCfgCurrLoopSecOrderTrfFctEna */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegCfgCurrLoopSecOrderTrfFctEna();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtDax */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtDax();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtQax */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotCurrRegCfgMotRVirtQax();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotRefMdlFbCtrlDi */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotRefMdlFbCtrlDi();
    
    /* init for variable MotCurrRegVltgLimr_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca */
    _main_gen_init_sym_MotCurrRegVltgLimr_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca();
    
    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrAntiWdupCmdScaDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrAntiWdupCmdScaQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotCurrCmdErrDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotCurrCmdErrQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotCurrCmdScaDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotCurrCmdScaQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgBrdgFild : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgCmdFinal : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgCmdPreLim : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDampgDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDampgQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDaxFb : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDaxIntglPreLim */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDaxIntglPreLim();
    
    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDecoupldFbDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDecoupldFbQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDircFbDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgDircFbQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPreLimDax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPreLimQax : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdDax */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdDax();
    
    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdQax */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgPropCmdQax();
    
    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxFb : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxFfFild : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxIntglPreLim */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgQaxIntglPreLim();
    
    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgSatnIvsRat : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrMotVltgSatnRat : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_dMotCurrRegVltgLimrPhaAdvPreDly : useless (never read) */

    /* init for variable MotCurrRegVltgLimr_Pim_MotCtrlMotVltgDaxPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotCtrlMotVltgDaxPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_MotCtrlMotVltgQaxPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotCtrlMotVltgQaxPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_MotVltgIntglCmdDaxPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgIntglCmdDaxPrev();
    
    /* init for variable MotCurrRegVltgLimr_Pim_MotVltgIntglCmdQaxPrev */
    _main_gen_init_sym_MotCurrRegVltgLimr_Pim_MotVltgIntglCmdQaxPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlBrdgVltg */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElecDly */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElecDly();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDaxCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDaxMax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxMax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotDampgDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotDampgQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotIntglGainDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotIntglGainQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotPropGainDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotPropGainQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotReacncDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotReacncQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVltgDaxFf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDaxFf();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVltgQaxFf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQaxFf();
    
    /* init for variable MOTCTRLMGR_MotCtrlSysSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotBackEmfVltg */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotBackEmfVltg();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotREstimd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotREstimd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCmdFinal : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotModlnIdx : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotPhaAdv : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotVltgDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVltgQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQax();
    
}
