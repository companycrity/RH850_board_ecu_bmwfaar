#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT32 pst_random_g_4;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT32 _main_gen_init_g4(void);

extern struct __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__104 _main_gen_init_g104(void);

extern struct __PST__g__90 _main_gen_init_g90(void);

extern union __PST__g__89 _main_gen_init_g89(void);

extern union __PST__g__87 _main_gen_init_g87(void);

extern union __PST__g__84 _main_gen_init_g84(void);

extern union __PST__g__81 _main_gen_init_g81(void);

extern union __PST__g__69 _main_gen_init_g69(void);

extern union __PST__g__63 _main_gen_init_g63(void);

extern union __PST__g__60 _main_gen_init_g60(void);

extern union __PST__g__57 _main_gen_init_g57(void);

extern union __PST__g__53 _main_gen_init_g53(void);

extern struct __PST__g__42 _main_gen_init_g42(void);

extern union __PST__g__41 _main_gen_init_g41(void);

extern __PST__g__39 _main_gen_init_g39(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

struct __PST__g__42 _main_gen_init_g42(void)
{
    static struct __PST__g__42 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PWR = bitf;
    }
    return x;
}

union __PST__g__41 _main_gen_init_g41(void)
{
    static union __PST__g__41 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g42();
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__53 _main_gen_init_g53(void)
{
    static union __PST__g__53 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__57 _main_gen_init_g57(void)
{
    static union __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__60 _main_gen_init_g60(void)
{
    static union __PST__g__60 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__63 _main_gen_init_g63(void)
{
    static union __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__69 _main_gen_init_g69(void)
{
    static union __PST__g__69 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__84 _main_gen_init_g84(void)
{
    static union __PST__g__84 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__87 _main_gen_init_g87(void)
{
    static union __PST__g__87 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__90 _main_gen_init_g90(void)
{
    static struct __PST__g__90 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.RCB1 = bitf;
    }
    return x;
}

union __PST__g__89 _main_gen_init_g89(void)
{
    static union __PST__g__89 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g90();
    return x;
}

struct __PST__g__105 _main_gen_init_g105(void)
{
    static struct __PST__g__105 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 4095);
        x.BRS = bitf;
    }
    return x;
}

union __PST__g__104 _main_gen_init_g104(void)
{
    static union __PST__g__104 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g105();
    return x;
}

__PST__g__39 _main_gen_init_g39(void)
{
    __PST__g__39 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g41();
    x.STCR0 = _main_gen_init_g53();
    x.CTL1 = _main_gen_init_g57();
    x.CTL2 = _main_gen_init_g60();
    x.MCTL1 = _main_gen_init_g63();
    x.TX0W = _main_gen_init_g69();
    x.MRWP0 = _main_gen_init_g81();
    x.MCTL0 = _main_gen_init_g84();
    x.CFG0 = _main_gen_init_g87();
    x.CFG1 = _main_gen_init_g89();
    x.BRS0 = _main_gen_init_g104();
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotAg0Meas_Ip_EgyModSt(void)
{
    extern __PST__UINT8 MotAg0Meas_Ip_EgyModSt;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_EgyModSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0ErrReg(void)
{
    extern __PST__UINT32 MotAg0Meas_Ip_MotAg0ErrReg;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0ErrReg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0ParFltCnt(void)
{
    extern __PST__UINT16 MotAg0Meas_Ip_MotAg0ParFltCnt;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0ParFltCnt = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0Polarity(void)
{
    extern __PST__SINT8 MotAg0Meas_Ip_MotAg0Polarity;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0SpiMecl(void)
{
    extern __PST__UINT16 MotAg0Meas_Ip_MotAg0SpiMecl;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0SpiMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0TurnCntrReg(void)
{
    extern __PST__UINT32 MotAg0Meas_Ip_MotAg0TurnCntrReg;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0TurnCntrReg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0VltgFltCnt(void)
{
    extern __PST__UINT16 MotAg0Meas_Ip_MotAg0VltgFltCnt;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0VltgFltCnt = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg0WarnReg(void)
{
    extern __PST__UINT32 MotAg0Meas_Ip_MotAg0WarnReg;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg0WarnReg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg1MeclQlfr(void)
{
    extern __PST__UINT8 MotAg0Meas_Ip_MotAg1MeclQlfr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg1MeclQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg1TurnCntrQlfr(void)
{
    extern __PST__UINT8 MotAg0Meas_Ip_MotAg1TurnCntrQlfr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg1TurnCntrQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_MotAg3Mecl(void)
{
    extern __PST__UINT16 MotAg0Meas_Ip_MotAg3Mecl;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_MotAg3Mecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Ip_TurnCntrIdptSig(void)
{
    extern __PST__UINT8 MotAg0Meas_Ip_TurnCntrIdptSig;
    
    /* initialization with random value */
    {
        MotAg0Meas_Ip_TurnCntrIdptSig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Cal_MotAg0MeasSnsrIfErrNtcMask(void)
{
    extern __PST__g__36 MotAg0Meas_Cal_MotAg0MeasSnsrIfErrNtcMask;
    
    /* initialization with random value */
    {
        MotAg0Meas_Cal_MotAg0MeasSnsrIfErrNtcMask = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0CoeffTbl(void)
{
    extern __PST__g__37 MotAg0Meas_Pim_MotAg0CoeffTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 26; _main_gen_tmp_0_0++)
            {
                /* base type */
                MotAg0Meas_Pim_MotAg0CoeffTbl[_main_gen_tmp_0_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0CorrnTbl(void)
{
    extern __PST__g__38 MotAg0Meas_Pim_MotAg0CorrnTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 128; _main_gen_tmp_1_0++)
            {
                /* base type */
                MotAg0Meas_Pim_MotAg0CorrnTbl[_main_gen_tmp_1_0] = pst_random_g_2;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0ParFltCntNtcPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0ParFltCntNtcPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0ParFltCntNtcPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0PrevSpiMecl(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0PrevSpiMecl;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0PrevSpiMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0PrevTCUpd(void)
{
    extern __PST__SINT16 MotAg0Meas_Pim_MotAg0PrevTCUpd;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0PrevTCUpd = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0QepFaildCntr(void)
{
    extern __PST__UINT32 MotAg0Meas_Pim_MotAg0QepFaildCntr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0QepFaildCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0QepFaildPrev(void)
{
    extern __PST__UINT8 MotAg0Meas_Pim_MotAg0QepFaildPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0QepFaildPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0SnsrCfg(void)
{
    extern __PST__UINT32 MotAg0Meas_Pim_MotAg0SnsrCfg;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0SnsrCfg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrParFltCntNtcPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0TurnCntrParFltCntNtcPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0TurnCntrParFltCntNtcPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrParFltCntPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0TurnCntrParFltCntPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0TurnCntrParFltCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrPrev(void)
{
    extern __PST__SINT16 MotAg0Meas_Pim_MotAg0TurnCntrPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0TurnCntrPrev = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrRollgCntrPrev(void)
{
    extern __PST__UINT8 MotAg0Meas_Pim_MotAg0TurnCntrRollgCntrPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0TurnCntrRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0VltgFltCntNtcPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0VltgFltCntNtcPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0VltgFltCntNtcPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAgCtrlRegCfg(void)
{
    extern __PST__UINT8 MotAg0Meas_Pim_MotAgCtrlRegCfg;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAgCtrlRegCfg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAgMecl0Polarity(void)
{
    extern __PST__SINT8 MotAg0Meas_Pim_MotAgMecl0Polarity;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAgMecl0Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAgSnsrCfgSt(void)
{
    extern __PST__UINT8 MotAg0Meas_Pim_MotAgSnsrCfgSt;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAgSnsrCfgSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Irv_MotAg0Qlfr(void)
{
    extern __PST__UINT8 MotAg0Meas_Irv_MotAg0Qlfr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Irv_MotAg0Qlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Irv_TurnCntr0Qlfr(void)
{
    extern __PST__UINT8 MotAg0Meas_Irv_TurnCntr0Qlfr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Irv_TurnCntr0Qlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CSIH1(void)
{
    extern __PST__g__39 CSIH1;
    
    /* initialization with random value */
    {
        CSIH1 = _main_gen_init_g39();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0InitOffs(void)
{
    extern __PST__SINT32 MotAg0Meas_Pim_MotAg0InitOffs;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0InitOffs = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0InitOffsCntr(void)
{
    extern __PST__UINT8 MotAg0Meas_Pim_MotAg0InitOffsCntr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0InitOffsCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0MeclRollgCntrPrev(void)
{
    extern __PST__UINT8 MotAg0Meas_Pim_MotAg0MeclRollgCntrPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0MeclRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0ParFltCntPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0ParFltCntPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0ParFltCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0RawMeclPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0RawMeclPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0RawMeclPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Pim_MotAg0VltgFltCntPrev(void)
{
    extern __PST__UINT16 MotAg0Meas_Pim_MotAg0VltgFltCntPrev;
    
    /* initialization with random value */
    {
        MotAg0Meas_Pim_MotAg0VltgFltCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0QepFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg0QepFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg0QepFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0RawRes(void)
{
    extern __PST__g__109 MOTCTRLMGR_MotCtrlMotAg0RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 5; _main_gen_tmp_2_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg0RawRes[_main_gen_tmp_2_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 MotAg0Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 MotAg0Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Clk_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Clk_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Clk_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Cs_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Cs_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Cs_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Mosi_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Mosi_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Mosi_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Clk_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Clk_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Clk_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Cs_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Cs_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Cs_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Mosi_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Mosi_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Mosi_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_MotAg0CoeffTbl_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_MotAg0CoeffTbl_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_MotAg0CoeffTbl_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_MotAg0SnsrCfgDmaStrt_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_MotAg0SnsrCfgDmaStrt_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_MotAg0SnsrCfgDmaStrt_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 MotAg0Meas_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        MotAg0Meas_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg0Meas_Cli_MotAg0CoeffTblRead_MotAgCoeffTbl(void)
{
    extern __PST__g__37 MotAg0Meas_Cli_MotAg0CoeffTblRead_MotAgCoeffTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 26; _main_gen_tmp_3_0++)
            {
                /* base type */
                MotAg0Meas_Cli_MotAg0CoeffTblRead_MotAgCoeffTbl[_main_gen_tmp_3_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg0Meas_Cli_MotAg0CoeffTblWr_MotAgCoeffTbl(void)
{
    extern __PST__g__37 MotAg0Meas_Cli_MotAg0CoeffTblWr_MotAgCoeffTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 26; _main_gen_tmp_4_0++)
            {
                /* base type */
                MotAg0Meas_Cli_MotAg0CoeffTblWr_MotAgCoeffTbl[_main_gen_tmp_4_0] = pst_random_g_10;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotAg0Meas_Ip_EgyModSt */
    _main_gen_init_sym_MotAg0Meas_Ip_EgyModSt();
    
    /* init for variable MotAg0Meas_Ip_MotAg0ErrReg */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0ErrReg();
    
    /* init for variable MotAg0Meas_Ip_MotAg0ParFltCnt */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0ParFltCnt();
    
    /* init for variable MotAg0Meas_Ip_MotAg0Polarity */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0Polarity();
    
    /* init for variable MotAg0Meas_Ip_MotAg0SpiMecl */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0SpiMecl();
    
    /* init for variable MotAg0Meas_Ip_MotAg0TurnCntrReg */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0TurnCntrReg();
    
    /* init for variable MotAg0Meas_Ip_MotAg0VltgFltCnt */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0VltgFltCnt();
    
    /* init for variable MotAg0Meas_Ip_MotAg0WarnReg */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg0WarnReg();
    
    /* init for variable MotAg0Meas_Ip_MotAg1MeclQlfr */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg1MeclQlfr();
    
    /* init for variable MotAg0Meas_Ip_MotAg1TurnCntrQlfr */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg1TurnCntrQlfr();
    
    /* init for variable MotAg0Meas_Ip_MotAg3Mecl */
    _main_gen_init_sym_MotAg0Meas_Ip_MotAg3Mecl();
    
    /* init for variable MotAg0Meas_Ip_TurnCntrIdptSig */
    _main_gen_init_sym_MotAg0Meas_Ip_TurnCntrIdptSig();
    
    /* init for variable MotAg0Meas_Op_MotAg0MeclQlfr : useless (never read) */

    /* init for variable MotAg0Meas_Op_MotAg0QepFaild : useless (never read) */

    /* init for variable MotAg0Meas_Op_MotAg0SnsrCfgAdr : useless (never read) */

    /* init for variable MotAg0Meas_Op_MotAg0TurnCntr : useless (never read) */

    /* init for variable MotAg0Meas_Op_MotAg0TurnCntrQlfr : useless (never read) */

    /* init for variable MotAg0Meas_Op_MotAg0TurnCntrRollgCntr : useless (never read) */

    /* init for variable MotAg0Meas_Cal_MotAg0MeasSnsrIfErrNtcMask */
    _main_gen_init_sym_MotAg0Meas_Cal_MotAg0MeasSnsrIfErrNtcMask();
    
    /* init for variable MotAg0Meas_Pim_MotAg0CoeffTbl */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0CoeffTbl();
    
    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0Delta : useless (never read) */

    /* init for variable MotAg0Meas_Pim_dMotAg0MeasPwrRstStsLtch : useless (never read) */

    /* init for variable MotAg0Meas_Pim_MotAg0CorrnTbl */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0CorrnTbl();
    
    /* init for variable MotAg0Meas_Pim_MotAg0ParFltCntNtcPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0ParFltCntNtcPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0PrevSpiMecl */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0PrevSpiMecl();
    
    /* init for variable MotAg0Meas_Pim_MotAg0PrevTCUpd */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0PrevTCUpd();
    
    /* init for variable MotAg0Meas_Pim_MotAg0QepFaildCntr */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0QepFaildCntr();
    
    /* init for variable MotAg0Meas_Pim_MotAg0QepFaildPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0QepFaildPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0SnsrCfg */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0SnsrCfg();
    
    /* init for variable MotAg0Meas_Pim_MotAg0TurnCntrParFltCntNtcPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrParFltCntNtcPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0TurnCntrParFltCntPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrParFltCntPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0TurnCntrPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0TurnCntrRollgCntrPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0TurnCntrRollgCntrPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0VltgFltCntNtcPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0VltgFltCntNtcPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAgCtrlRegCfg */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAgCtrlRegCfg();
    
    /* init for variable MotAg0Meas_Pim_MotAgMecl0Polarity */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAgMecl0Polarity();
    
    /* init for variable MotAg0Meas_Pim_MotAgSnsrCfgSt */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAgSnsrCfgSt();
    
    /* init for variable MotAg0Meas_Irv_MotAg0Qlfr */
    _main_gen_init_sym_MotAg0Meas_Irv_MotAg0Qlfr();
    
    /* init for variable MotAg0Meas_Irv_TurnCntr0Qlfr */
    _main_gen_init_sym_MotAg0Meas_Irv_TurnCntr0Qlfr();
    
    /* init for variable CSIH1 */
    _main_gen_init_sym_CSIH1();
    
    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0RawAgReg : useless (never read) */

    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0RawErrReg : useless (never read) */

    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0RawStsReg : useless (never read) */

    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0RawTurnCntrReg : useless (never read) */

    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0RawWarnReg : useless (never read) */

    /* init for variable MotAg0Meas_Pim_dMotAg0MeasMotAg0RtOffs : useless (never read) */

    /* init for variable MotAg0Meas_Pim_MotAg0InitOffs */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0InitOffs();
    
    /* init for variable MotAg0Meas_Pim_MotAg0InitOffsCntr */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0InitOffsCntr();
    
    /* init for variable MotAg0Meas_Pim_MotAg0MeclRollgCntrPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0MeclRollgCntrPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0ParFltCntPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0ParFltCntPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0RawMeclPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0RawMeclPrev();
    
    /* init for variable MotAg0Meas_Pim_MotAg0VltgFltCntPrev */
    _main_gen_init_sym_MotAg0Meas_Pim_MotAg0VltgFltCntPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg0QepFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0QepFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg0RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg0ErrReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0Mecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0MeclRollgCntr : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0ParFltCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0SpiMecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0TurnCntrReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0VltgFltCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg0WarnReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg3Mecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAgMeasTi : useless (never read) */

    /* init for variable MotAg0Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd */
    _main_gen_init_sym_MotAg0Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd();
    
    /* init for variable MotAg0Meas_Srv_CnvSnpshtData_s16_SnpshtData : useless (never read) */

    /* init for variable MotAg0Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd */
    _main_gen_init_sym_MotAg0Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd();
    
    /* init for variable MotAg0Meas_Srv_CnvSnpshtData_u16_SnpshtData : useless (never read) */

    /* init for variable MotAg0Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable MotAg0Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_MotAg0Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable MotAg0Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Clk_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Clk_Return();
    
    /* init for variable MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Cs_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Cs_Return();
    
    /* init for variable MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Mosi_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetFctGpioMotAg0Mosi_Return();
    
    /* init for variable MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Clk_PinSt : useless (never read) */

    /* init for variable MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Clk_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Clk_Return();
    
    /* init for variable MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Cs_PinSt : useless (never read) */

    /* init for variable MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Cs_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Cs_Return();
    
    /* init for variable MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Mosi_PinSt : useless (never read) */

    /* init for variable MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Mosi_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_IoHwAb_SetGpioMotAg0Mosi_Return();
    
    /* init for variable MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_RequestResultPtr();
    
    /* init for variable MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_MotAg0CoeffTbl_GetErrorStatus_Return();
    
    /* init for variable MotAg0Meas_Srv_MotAg0CoeffTbl_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable MotAg0Meas_Srv_MotAg0CoeffTbl_SetRamBlockStatus_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_MotAg0CoeffTbl_SetRamBlockStatus_Return();
    
    /* init for variable MotAg0Meas_Srv_MotAg0SnsrCfgDmaStrt_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_MotAg0SnsrCfgDmaStrt_Return();
    
    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable MotAg0Meas_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_MotAg0Meas_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable MotAg0Meas_Cli_MotAg0CoeffTblRead_MotAgCoeffTbl */
    _main_gen_init_sym_MotAg0Meas_Cli_MotAg0CoeffTblRead_MotAgCoeffTbl();
    
    /* init for variable MotAg0Meas_Cli_MotAg0CoeffTblWr_MotAgCoeffTbl */
    _main_gen_init_sym_MotAg0Meas_Cli_MotAg0CoeffTblWr_MotAgCoeffTbl();
    
}
