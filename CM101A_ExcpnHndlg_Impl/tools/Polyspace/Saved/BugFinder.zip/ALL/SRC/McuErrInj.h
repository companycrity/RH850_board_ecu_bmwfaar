/* Contract file for CM101A */
#include "lockstep_regs.h"
#include "Os.h"
#include "NxtrMath.h"
#include <float.h>
#include "WdgM.h"

#define MCUDIAGCERRINJ  STD_OFF

#if (MCUDIAGCERRINJ == STD_ON)
extern void ClrErrInjReg_Oper(void);
extern void ReadErrInjReg_Oper(uint32* ErrId);

extern uint32 McuDiagcTestVar1_G;

extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjMcuRtErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjModErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjMemProtnErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjFpuErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjWdgErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjOsPrmntGenericRtErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjOsTmpGenericRtErr (void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjClkMonrErr(void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjMcuVltgMonrErr(void);
extern  FUNC(void, CDD_ExcpnHndlg_CODE) InjProgSeqErr (void);
extern FUNC(void, CDD_ExcpnHndlg_CODE) InjPbgRtErr (void);

#define MCUERRINJ_NTC0022BIT01CASE01_CNT_U32                                    0x00220201U

#define MCUERRINJ_NTC0022BIT00CASE01_CNT_U32                                    0x00220101U
#define MCUERRINJ_NTC0022BIT00CASE02_CNT_U32                                    0x00220102U
#define MCUERRINJ_NTC0022BIT02CASE01_CNT_U32                                    0x00220401U
#define MCUERRINJ_NTC0022BIT03CASE01_CNT_U32                                    0x00220801U
#define MCUERRINJ_NTC0022BIT04CASE01_CNT_U32                                    0x00221001U
#define MCUERRINJ_NTC0022BIT05CASE01_CNT_U32                                    0x00222001U
#define MCUERRINJ_NTC0022BIT06CASE01_CNT_U32                                    0x00224001U
#define MCUERRINJ_NTC0022BIT06CASE02_CNT_U32                                    0x00224002U
#define MCUERRINJ_NTC0022BIT06CASE03_CNT_U32                                    0x00224003U
#define MCUERRINJ_NTC0022BIT06CASE04_CNT_U32                                    0x00224004U
#define MCUERRINJ_NTC0022BIT07CASE01_CNT_U32                                    0x00228001U

#define MCUERRINJ_NTC0028BIT01CASE01_CNT_U32                                    0x00280201U
#define MCUERRINJ_NTC0028BIT01CASE02_CNT_U32                                    0x00280202U
#define MCUERRINJ_NTC0028BIT01CASE03_CNT_U32                                    0x00280203U
#define MCUERRINJ_NTC0028BIT02CASE01_CNT_U32                                    0x00280401U
#define MCUERRINJ_NTC0028BIT03CASE01_CNT_U32                                    0x00280801U

#define MCUERRINJ_NTC002ABIT00CASE01_CNT_U32                                    0x002A0101U
#define MCUERRINJ_NTC002ABIT02CASE01_CNT_U32                                    0x002A0401U

#define MCUERRINJ_NTC0025BIT01CASE01_CNT_U32                                    0x00250201U
#define MCUERRINJ_NTC0025BIT00CASE01_CNT_U32                                    0x00250101U
#define MCUERRINJ_NTC0023BIT02CASE01_CNT_U32                                    0x00230401U
#define MCUERRINJ_NTC0023BIT03CASE01_CNT_U32                                    0x00230801U
#define MCUERRINJ_NTC0023BIT06CASE01_CNT_U32                                    0x00234001U
#define MCUERRINJ_NTC0023BIT07CASE01_CNT_U32                                    0x00238001U


#define MCUERRINJ_NTC0027BIT02CASE01_CNT_U32                                    0x00270401U
#define MCUERRINJ_NTC0027BIT03CASE01_CNT_U32                                    0x00270801U
#define MCUERRINJ_NTC0027BIT06CASE01_CNT_U32                                    0x00274001U
#define MCUERRINJ_NTC0027BIT07CASE01_CNT_U32                                    0x00278001U
#define MCUERRINJ_NTC0024BIT00CASE01_CNT_U32                                    0x00240101U
#define MCUERRINJ_NTC0024BIT01CASE01_CNT_U32                                    0x00240201U
#define MCUERRINJ_NTC0024BIT02CASE01_CNT_U32                                    0x00240401U
#define MCUERRINJ_NTC002CBIT00CASE01_CNT_U32                                    0x002C0101U
#define MCUERRINJ_NTC0030BIT00CASE01_CNT_U32                                    0x00300101U
#define MCUERRINJ_NTC0030BIT01CASE01_CNT_U32                                    0x00300201U
#define MCUERRINJ_NTC0031BIT00CASE01_CNT_U32                                    0x00310101U
#define MCUERRINJ_NTC0049BIT00CASE01_CNT_U32                                    0x00490101U
#define MCUERRINJ_NTC0049BIT01CASE01_CNT_U32                                    0x00490201U


#endif

