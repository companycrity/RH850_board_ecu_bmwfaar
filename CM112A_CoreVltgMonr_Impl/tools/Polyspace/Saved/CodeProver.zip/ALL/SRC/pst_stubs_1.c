#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__98 _main_gen_init_g98(void);

extern union __PST__g__96 _main_gen_init_g96(void);

extern union __PST__g__94 _main_gen_init_g94(void);

extern union __PST__g__87 _main_gen_init_g87(void);

extern union __PST__g__84 _main_gen_init_g84(void);

extern union __PST__g__79 _main_gen_init_g79(void);

extern union __PST__g__73 _main_gen_init_g73(void);

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__73 _main_gen_init_g73(void)
{
    static union __PST__g__73 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__79 _main_gen_init_g79(void)
{
    static union __PST__g__79 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__84 _main_gen_init_g84(void)
{
    static union __PST__g__84 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__87 _main_gen_init_g87(void)
{
    static union __PST__g__87 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__94 _main_gen_init_g94(void)
{
    static union __PST__g__94 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__96 _main_gen_init_g96(void)
{
    static union __PST__g__96 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__98 _main_gen_init_g98(void)
{
    static union __PST__g__98 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* struct/union type */
    x.CVMF = _main_gen_init_g73();
    x.CVMDE = _main_gen_init_g79();
    x.CVMDMASK = _main_gen_init_g84();
    x.CVMDIAG = _main_gen_init_g87();
    x.CVMFC = _main_gen_init_g94();
    x.CVMDEW = _main_gen_init_g96();
    x.CVMREN = _main_gen_init_g98();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte(void)
{
    extern __PST__UINT8 CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte;
    
    /* initialization with random value */
    {
        CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__24 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CoreVltgMonr_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 CoreVltgMonr_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        CoreVltgMonr_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte */
    _main_gen_init_sym_CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable CoreVltgMonr_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_Return */
    _main_gen_init_sym_CoreVltgMonr_Srv_SetNtcSts_Return();
    
}
