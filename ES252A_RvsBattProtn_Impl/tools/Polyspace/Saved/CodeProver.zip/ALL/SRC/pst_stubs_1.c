#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_RvsBattProtn_Srv_CnvSnpshtData_f32_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 RvsBattProtn_Srv_CnvSnpshtData_f32_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        RvsBattProtn_Srv_CnvSnpshtData_f32_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 RvsBattProtn_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        RvsBattProtn_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 RvsBattProtn_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        RvsBattProtn_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 RvsBattProtn_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        RvsBattProtn_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcGndAdc(void)
{
    extern __PST__FLOAT32 RvsBattProtn_Ip_RvsBattDiagcGndAdc;
    
    /* initialization with random value */
    {
        RvsBattProtn_Ip_RvsBattDiagcGndAdc = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcGndAdcFaild(void)
{
    extern __PST__UINT8 RvsBattProtn_Ip_RvsBattDiagcGndAdcFaild;
    
    /* initialization with random value */
    {
        RvsBattProtn_Ip_RvsBattDiagcGndAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcRtnAdc(void)
{
    extern __PST__FLOAT32 RvsBattProtn_Ip_RvsBattDiagcRtnAdc;
    
    /* initialization with random value */
    {
        RvsBattProtn_Ip_RvsBattDiagcRtnAdc = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcRtnAdcFaild(void)
{
    extern __PST__UINT8 RvsBattProtn_Ip_RvsBattDiagcRtnAdcFaild;
    
    /* initialization with random value */
    {
        RvsBattProtn_Ip_RvsBattDiagcRtnAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_FAILSTEP_CNT_U16(void)
{
    extern __PST__UINT16 RVSBATTPROTN_FAILSTEP_CNT_U16;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_FAILSTEP_CNT_U16 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_GNDMEASDVLTGHILIMN_VOLT_F32(void)
{
    extern __PST__FLOAT32 RVSBATTPROTN_GNDMEASDVLTGHILIMN_VOLT_F32;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_GNDMEASDVLTGHILIMN_VOLT_F32 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_GNDMEASDVLTGLOLIMN_VOLT_F32(void)
{
    extern __PST__FLOAT32 RVSBATTPROTN_GNDMEASDVLTGLOLIMN_VOLT_F32;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_GNDMEASDVLTGLOLIMN_VOLT_F32 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_PASSSTEP_CNT_U16(void)
{
    extern __PST__UINT16 RVSBATTPROTN_PASSSTEP_CNT_U16;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_PASSSTEP_CNT_U16 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_RTNMEASDVLTGHILIMN_VOLT_F32(void)
{
    extern __PST__FLOAT32 RVSBATTPROTN_RTNMEASDVLTGHILIMN_VOLT_F32;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_RTNMEASDVLTGHILIMN_VOLT_F32 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_RTNMEASDVLTGLOLIMN_VOLT_F32(void)
{
    extern __PST__FLOAT32 RVSBATTPROTN_RTNMEASDVLTGLOLIMN_VOLT_F32;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_RTNMEASDVLTGLOLIMN_VOLT_F32 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_RVSBATTPROTN_RVSFLTTHD_VOLT_F32(void)
{
    extern __PST__FLOAT32 RVSBATTPROTN_RVSFLTTHD_VOLT_F32;
    
    /* initialization with random value */
    {
        RVSBATTPROTN_RVSFLTTHD_VOLT_F32 = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable RvsBattProtn_Srv_CnvSnpshtData_f32_SnpshtDataCnvd */
    _main_gen_init_sym_RvsBattProtn_Srv_CnvSnpshtData_f32_SnpshtDataCnvd();
    
    /* init for variable RvsBattProtn_Srv_CnvSnpshtData_f32_SnpshtData : useless (never read) */

    /* init for variable RvsBattProtn_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable RvsBattProtn_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_RvsBattProtn_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable RvsBattProtn_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_RvsBattProtn_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable RvsBattProtn_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_RvsBattProtn_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable RvsBattProtn_Ip_RvsBattDiagcGndAdc */
    _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcGndAdc();
    
    /* init for variable RvsBattProtn_Ip_RvsBattDiagcGndAdcFaild */
    _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcGndAdcFaild();
    
    /* init for variable RvsBattProtn_Ip_RvsBattDiagcRtnAdc */
    _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcRtnAdc();
    
    /* init for variable RvsBattProtn_Ip_RvsBattDiagcRtnAdcFaild */
    _main_gen_init_sym_RvsBattProtn_Ip_RvsBattDiagcRtnAdcFaild();
    
    /* init for variable RvsBattProtn_Op_RvsBattProtnStsQlfr : useless (never read) */

    /* init for variable RVSBATTPROTN_FAILSTEP_CNT_U16 */
    _main_gen_init_sym_RVSBATTPROTN_FAILSTEP_CNT_U16();
    
    /* init for variable RVSBATTPROTN_GNDMEASDVLTGHILIMN_VOLT_F32 */
    _main_gen_init_sym_RVSBATTPROTN_GNDMEASDVLTGHILIMN_VOLT_F32();
    
    /* init for variable RVSBATTPROTN_GNDMEASDVLTGLOLIMN_VOLT_F32 */
    _main_gen_init_sym_RVSBATTPROTN_GNDMEASDVLTGLOLIMN_VOLT_F32();
    
    /* init for variable RVSBATTPROTN_PASSSTEP_CNT_U16 */
    _main_gen_init_sym_RVSBATTPROTN_PASSSTEP_CNT_U16();
    
    /* init for variable RVSBATTPROTN_RTNMEASDVLTGHILIMN_VOLT_F32 */
    _main_gen_init_sym_RVSBATTPROTN_RTNMEASDVLTGHILIMN_VOLT_F32();
    
    /* init for variable RVSBATTPROTN_RTNMEASDVLTGLOLIMN_VOLT_F32 */
    _main_gen_init_sym_RVSBATTPROTN_RTNMEASDVLTGLOLIMN_VOLT_F32();
    
    /* init for variable RVSBATTPROTN_RVSFLTTHD_VOLT_F32 */
    _main_gen_init_sym_RVSBATTPROTN_RVSFLTTHD_VOLT_F32();
    
}
