#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__23 _main_gen_init_g23(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwMaxCurrLimr(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_BmwMaxCurrLimr;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_BmwMaxCurrLimr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwMaxCurrLimrSts(void)
{
    extern __PST__UINT8 BmwSplyCurrLim_Ip_BmwMaxCurrLimrSts;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_BmwMaxCurrLimrSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwStrtStopLim(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_BmwStrtStopLim;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_BmwStrtStopLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwStrtStopMsgActv(void)
{
    extern __PST__UINT8 BmwSplyCurrLim_Ip_BmwStrtStopMsgActv;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_BmwStrtStopMsgActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_BrdgVltg(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_BrdgVltg;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_BrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_MaxCurrAtHiSpd(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_MaxCurrAtHiSpd;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_MaxCurrAtHiSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_MaxCurrAtLoSpd(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_MaxCurrAtLoSpd;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_MaxCurrAtLoSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_RemCtrlPrkgEna(void)
{
    extern __PST__UINT8 BmwSplyCurrLim_Ip_RemCtrlPrkgEna;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_RemCtrlPrkgEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_SysMotTqCmdSca(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_SysMotTqCmdSca;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_SysMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMax(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMax;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMax = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMin(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMin;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMin = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimrGrdt(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimrGrdt;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimrGrdt = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrX(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 8; _main_gen_tmp_0_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrX[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrY(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 8; _main_gen_tmp_1_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrY[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsCpbyOffs(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsCpbyOffs;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsCpbyOffs = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMaxGrdt(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMaxGrdt;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMaxGrdt = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMinGrdt(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMinGrdt;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMinGrdt = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimMaxCurrLim(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimMaxCurrLim;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimMaxCurrLim = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrX(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 8; _main_gen_tmp_2_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrY(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 8; _main_gen_tmp_3_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimRemCtrlPrkgLim(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimRemCtrlPrkgLim;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimRemCtrlPrkgLim = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimX(void)
{
    extern __PST__g__26 BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 6; _main_gen_tmp_4_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimX[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimY(void)
{
    extern __PST__g__26 BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 6; _main_gen_tmp_5_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecX(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 8; _main_gen_tmp_6_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecX[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecY(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 8; _main_gen_tmp_7_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncX(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 8; _main_gen_tmp_8_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncX[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncY(void)
{
    extern __PST__g__24 BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 8; _main_gen_tmp_9_0++)
            {
                /* base type */
                BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncY[_main_gen_tmp_9_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrLimFltThd(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrLimFltThd;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrLimFltThd = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVrntMaxCurr(void)
{
    extern __PST__g__23 BmwSplyCurrLim_Cal_BmwSplyCurrLimVrntMaxCurr;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Cal_BmwSplyCurrLimVrntMaxCurr = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Pim_BmwMaxCurrLimGrdt(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Pim_BmwMaxCurrLimGrdt;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Pim_BmwMaxCurrLimGrdt = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Pim_SplyCurrLimGrdt(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Pim_SplyCurrLimGrdt;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Pim_SplyCurrLimGrdt = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Pim_VltgDptCurrLimGrdt(void)
{
    extern __PST__FLOAT32 BmwSplyCurrLim_Pim_VltgDptCurrLimGrdt;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Pim_VltgDptCurrLimGrdt = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwSplyCurrLim_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 BmwSplyCurrLim_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        BmwSplyCurrLim_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwSplyCurrLim_Ip_BmwMaxCurrLimr */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwMaxCurrLimr();
    
    /* init for variable BmwSplyCurrLim_Ip_BmwMaxCurrLimrSts */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwMaxCurrLimrSts();
    
    /* init for variable BmwSplyCurrLim_Ip_BmwStrtStopLim */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwStrtStopLim();
    
    /* init for variable BmwSplyCurrLim_Ip_BmwStrtStopMsgActv */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_BmwStrtStopMsgActv();
    
    /* init for variable BmwSplyCurrLim_Ip_BrdgVltg */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_BrdgVltg();
    
    /* init for variable BmwSplyCurrLim_Ip_MaxCurrAtHiSpd */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_MaxCurrAtHiSpd();
    
    /* init for variable BmwSplyCurrLim_Ip_MaxCurrAtLoSpd */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_MaxCurrAtLoSpd();
    
    /* init for variable BmwSplyCurrLim_Ip_RemCtrlPrkgEna */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_RemCtrlPrkgEna();
    
    /* init for variable BmwSplyCurrLim_Ip_SysMotTqCmdSca */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_SysMotTqCmdSca();
    
    /* init for variable BmwSplyCurrLim_Ip_VehSpd */
    _main_gen_init_sym_BmwSplyCurrLim_Ip_VehSpd();
    
    /* init for variable BmwSplyCurrLim_Op_SplyCurrLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMax */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMax();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMin */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimMin();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimrGrdt */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimBmwMaxCurrLimrGrdt();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrX */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrX();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrY */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimDegradedVltgMaxCurrY();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsCpbyOffs */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsCpbyOffs();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMaxGrdt */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMaxGrdt();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMinGrdt */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimEpsMinGrdt();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimMaxCurrLim */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimMaxCurrLim();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrX */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrX();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrY */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimNormVltgMaxCurrY();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimRemCtrlPrkgLim */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimRemCtrlPrkgLim();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimX */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimX();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimY */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVehSpdDptCurrLimY();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecX */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecX();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecY */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtDecY();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncX */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncX();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncY */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrGrdtIncY();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrLimFltThd */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVltgDptCurrLimFltThd();
    
    /* init for variable BmwSplyCurrLim_Cal_BmwSplyCurrLimVrntMaxCurr */
    _main_gen_init_sym_BmwSplyCurrLim_Cal_BmwSplyCurrLimVrntMaxCurr();
    
    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimBmwMaxCurrLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimCurrLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimCurrLimPrel : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimGlbLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimSplyCurrLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimVehSpdDptCurrLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_dBmwSplyCurrLimVltgDptCurrLim : useless (never read) */

    /* init for variable BmwSplyCurrLim_Pim_BmwMaxCurrLimGrdt */
    _main_gen_init_sym_BmwSplyCurrLim_Pim_BmwMaxCurrLimGrdt();
    
    /* init for variable BmwSplyCurrLim_Pim_SplyCurrLimGrdt */
    _main_gen_init_sym_BmwSplyCurrLim_Pim_SplyCurrLimGrdt();
    
    /* init for variable BmwSplyCurrLim_Pim_VltgDptCurrLimGrdt */
    _main_gen_init_sym_BmwSplyCurrLim_Pim_VltgDptCurrLimGrdt();
    
    /* init for variable BmwSplyCurrLim_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable BmwSplyCurrLim_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable BmwSplyCurrLim_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable BmwSplyCurrLim_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable BmwSplyCurrLim_Srv_SetNtcSts_Return */
    _main_gen_init_sym_BmwSplyCurrLim_Srv_SetNtcSts_Return();
    
}
