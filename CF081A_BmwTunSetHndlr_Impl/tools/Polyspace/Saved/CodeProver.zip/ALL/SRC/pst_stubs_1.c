#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__32 _main_gen_init_g32(void);

extern struct __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.BmwDesIninIdx = _main_gen_init_g6();
    x.BmwDesIninIdxWrSts = _main_gen_init_g6();
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.BmwDesIninOptSetAIdx = _main_gen_init_g6();
    x.BmwDesIninOptSetAIdxWrSts = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwTunSetHndlr_Ip_BmwRtIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Ip_BmwRtIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Ip_BmwRtIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Ip_BmwRtIdxVld(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Ip_BmwRtIdxVld;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Ip_BmwRtIdxVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Ip_TunSetHndlrEna(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Ip_TunSetHndlrEna;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Ip_TunSetHndlrEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrBmwRtIdxDebThd(void)
{
    extern __PST__g__29 BmwTunSetHndlr_Cal_BmwTunSetHndlrBmwRtIdxDebThd;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cal_BmwTunSetHndlrBmwRtIdxDebThd = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrCptDisadOutp(void)
{
    extern __PST__g__30 BmwTunSetHndlr_Cal_BmwTunSetHndlrCptDisadOutp;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cal_BmwTunSetHndlrCptDisadOutp = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrNrOfMotVrnt(void)
{
    extern __PST__g__30 BmwTunSetHndlr_Cal_BmwTunSetHndlrNrOfMotVrnt;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cal_BmwTunSetHndlrNrOfMotVrnt = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrOvrdDesRtIdx(void)
{
    extern __PST__g__30 BmwTunSetHndlr_Cal_BmwTunSetHndlrOvrdDesRtIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cal_BmwTunSetHndlrOvrdDesRtIdx = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Pim_BmwDesIninIdx(void)
{
    extern struct __PST__g__31 BmwTunSetHndlr_Pim_BmwDesIninIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Pim_BmwDesIninIdx = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Pim_BmwDesIninOptSetAIdx(void)
{
    extern struct __PST__g__32 BmwTunSetHndlr_Pim_BmwDesIninOptSetAIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Pim_BmwDesIninOptSetAIdx = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Pim_BmwRtIdxTi(void)
{
    extern __PST__UINT32 BmwTunSetHndlr_Pim_BmwRtIdxTi;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Pim_BmwRtIdxTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Pim_DebBmwRtIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Pim_DebBmwRtIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Pim_DebBmwRtIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Pim_LstVldIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Pim_LstVldIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Pim_LstVldIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Pim_PrevBmwRtIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Pim_PrevBmwRtIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Pim_PrevBmwRtIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_ReqResPtr(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_ReqResPtr;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_ReqResPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninIdx_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_BmwDesIninIdx_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_BmwDesIninIdx_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_ReqResPtr(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_ReqResPtr;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_ReqResPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwTunSetHndlr_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwTunSetHndlr_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cli_MotVrntRead_BmwDesIninOptSetAIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Cli_MotVrntRead_BmwDesIninOptSetAIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cli_MotVrntRead_BmwDesIninOptSetAIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cli_MotVrntWr_BmwDesIninOptSetAIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Cli_MotVrntWr_BmwDesIninOptSetAIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cli_MotVrntWr_BmwDesIninOptSetAIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cli_TunVrntRead_BmwDesIninIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Cli_TunVrntRead_BmwDesIninIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cli_TunVrntRead_BmwDesIninIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTunSetHndlr_Cli_TunVrntWr_BmwDesIninIdx(void)
{
    extern __PST__UINT8 BmwTunSetHndlr_Cli_TunVrntWr_BmwDesIninIdx;
    
    /* initialization with random value */
    {
        BmwTunSetHndlr_Cli_TunVrntWr_BmwDesIninIdx = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwTunSetHndlr_Ip_BmwRtIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Ip_BmwRtIdx();
    
    /* init for variable BmwTunSetHndlr_Ip_BmwRtIdxVld */
    _main_gen_init_sym_BmwTunSetHndlr_Ip_BmwRtIdxVld();
    
    /* init for variable BmwTunSetHndlr_Ip_TunSetHndlrEna */
    _main_gen_init_sym_BmwTunSetHndlr_Ip_TunSetHndlrEna();
    
    /* init for variable BmwTunSetHndlr_Op_DesIninIdx : useless (never read) */

    /* init for variable BmwTunSetHndlr_Op_DesIninOptSetAIdx : useless (never read) */

    /* init for variable BmwTunSetHndlr_Op_DesRtIdx : useless (never read) */

    /* init for variable BmwTunSetHndlr_Cal_BmwTunSetHndlrBmwRtIdxDebThd */
    _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrBmwRtIdxDebThd();
    
    /* init for variable BmwTunSetHndlr_Cal_BmwTunSetHndlrCptDisadOutp */
    _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrCptDisadOutp();
    
    /* init for variable BmwTunSetHndlr_Cal_BmwTunSetHndlrNrOfMotVrnt */
    _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrNrOfMotVrnt();
    
    /* init for variable BmwTunSetHndlr_Cal_BmwTunSetHndlrOvrdDesRtIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Cal_BmwTunSetHndlrOvrdDesRtIdx();
    
    /* init for variable BmwTunSetHndlr_Pim_BmwDesIninIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Pim_BmwDesIninIdx();
    
    /* init for variable BmwTunSetHndlr_Pim_BmwDesIninOptSetAIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Pim_BmwDesIninOptSetAIdx();
    
    /* init for variable BmwTunSetHndlr_Pim_BmwRtIdxTi */
    _main_gen_init_sym_BmwTunSetHndlr_Pim_BmwRtIdxTi();
    
    /* init for variable BmwTunSetHndlr_Pim_DebBmwRtIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Pim_DebBmwRtIdx();
    
    /* init for variable BmwTunSetHndlr_Pim_LstVldIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Pim_LstVldIdx();
    
    /* init for variable BmwTunSetHndlr_Pim_PrevBmwRtIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Pim_PrevBmwRtIdx();
    
    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_ReqResPtr */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_ReqResPtr();
    
    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_Return */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninIdx_GetErrorStatus_Return();
    
    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninIdx_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninIdx_SetRamBlockStatus_Return */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninIdx_SetRamBlockStatus_Return();
    
    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_ReqResPtr */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_ReqResPtr();
    
    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_Return */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_GetErrorStatus_Return();
    
    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_SetRamBlockStatus_Return */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_BmwDesIninOptSetAIdx_SetRamBlockStatus_Return();
    
    /* init for variable BmwTunSetHndlr_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwTunSetHndlr_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable BmwTunSetHndlr_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable BmwTunSetHndlr_Srv_SetNtcSts_Return */
    _main_gen_init_sym_BmwTunSetHndlr_Srv_SetNtcSts_Return();
    
    /* init for variable BmwTunSetHndlr_Cli_MotVrntRead_BmwDesIninOptSetAIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Cli_MotVrntRead_BmwDesIninOptSetAIdx();
    
    /* init for variable BmwTunSetHndlr_Cli_MotVrntRead_Return : useless (never read) */

    /* init for variable BmwTunSetHndlr_Cli_MotVrntWr_BmwDesIninOptSetAIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Cli_MotVrntWr_BmwDesIninOptSetAIdx();
    
    /* init for variable BmwTunSetHndlr_Cli_MotVrntWr_Return : useless (never read) */

    /* init for variable BmwTunSetHndlr_Cli_TunVrntRead_BmwDesIninIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Cli_TunVrntRead_BmwDesIninIdx();
    
    /* init for variable BmwTunSetHndlr_Cli_TunVrntRead_Return : useless (never read) */

    /* init for variable BmwTunSetHndlr_Cli_TunVrntWr_BmwDesIninIdx */
    _main_gen_init_sym_BmwTunSetHndlr_Cli_TunVrntWr_BmwDesIninIdx();
    
    /* init for variable BmwTunSetHndlr_Cli_TunVrntWr_Return : useless (never read) */

}
