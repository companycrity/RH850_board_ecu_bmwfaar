#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__23 _main_gen_init_g23(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SysKineAndEff_Ip_CmplncErrPinionToHw(void)
{
    extern __PST__FLOAT32 SysKineAndEff_Ip_CmplncErrPinionToHw;
    
    /* initialization with random value */
    {
        SysKineAndEff_Ip_CmplncErrPinionToHw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysKineAndEff_Ip_MotAgCumvAlgndMrf(void)
{
    extern __PST__SINT32 SysKineAndEff_Ip_MotAgCumvAlgndMrf;
    
    /* initialization with random value */
    {
        SysKineAndEff_Ip_MotAgCumvAlgndMrf = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_SysKineAndEff_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 SysKineAndEff_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        SysKineAndEff_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysKineAndEff_Ip_PinionAg(void)
{
    extern __PST__FLOAT32 SysKineAndEff_Ip_PinionAg;
    
    /* initialization with random value */
    {
        SysKineAndEff_Ip_PinionAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffCmplncErrDerivtvCutOffFrq(void)
{
    extern __PST__g__23 SysKineAndEff_Cal_SysKineAndEffCmplncErrDerivtvCutOffFrq;
    
    /* initialization with random value */
    {
        SysKineAndEff_Cal_SysKineAndEffCmplncErrDerivtvCutOffFrq = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffMotAgScaX(void)
{
    extern __PST__g__24 SysKineAndEff_Cal_SysKineAndEffMotAgScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 21; _main_gen_tmp_0_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffMotAgScaX[_main_gen_tmp_0_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffMotAgToRackPosRatScaY(void)
{
    extern __PST__g__26 SysKineAndEff_Cal_SysKineAndEffMotAgToRackPosRatScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 21; _main_gen_tmp_1_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffMotAgToRackPosRatScaY[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffMotToRackEffScaY(void)
{
    extern __PST__g__26 SysKineAndEff_Cal_SysKineAndEffMotToRackEffScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 21; _main_gen_tmp_2_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffMotToRackEffScaY[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffPinionAgToRackPosRatScaY(void)
{
    extern __PST__g__26 SysKineAndEff_Cal_SysKineAndEffPinionAgToRackPosRatScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 21; _main_gen_tmp_3_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffPinionAgToRackPosRatScaY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffPinionToRackEffScaY(void)
{
    extern __PST__g__26 SysKineAndEff_Cal_SysKineAndEffPinionToRackEffScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 21; _main_gen_tmp_4_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffPinionToRackEffScaY[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffRackPosScaY(void)
{
    extern __PST__g__24 SysKineAndEff_Cal_SysKineAndEffRackPosScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 21; _main_gen_tmp_5_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffRackPosScaY[_main_gen_tmp_5_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffRoadWhlFromRackPosScaY(void)
{
    extern __PST__g__24 SysKineAndEff_Cal_SysKineAndEffRoadWhlFromRackPosScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 21; _main_gen_tmp_6_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffRoadWhlFromRackPosScaY[_main_gen_tmp_6_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffSteerArmLenFromRackPosScaY(void)
{
    extern __PST__g__26 SysKineAndEff_Cal_SysKineAndEffSteerArmLenFromRackPosScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 21; _main_gen_tmp_7_0++)
            {
                /* base type */
                SysKineAndEff_Cal_SysKineAndEffSteerArmLenFromRackPosScaY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysKineAndEff_Pim_CmplncErrDerivtvPrev(void)
{
    extern __PST__FLOAT32 SysKineAndEff_Pim_CmplncErrDerivtvPrev;
    
    /* initialization with random value */
    {
        SysKineAndEff_Pim_CmplncErrDerivtvPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysKineAndEff_Pim_CmplncErrPinionToHwPrev(void)
{
    extern __PST__FLOAT32 SysKineAndEff_Pim_CmplncErrPinionToHwPrev;
    
    /* initialization with random value */
    {
        SysKineAndEff_Pim_CmplncErrPinionToHwPrev = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SysKineAndEff_Ip_CmplncErrPinionToHw */
    _main_gen_init_sym_SysKineAndEff_Ip_CmplncErrPinionToHw();
    
    /* init for variable SysKineAndEff_Ip_MotAgCumvAlgndMrf */
    _main_gen_init_sym_SysKineAndEff_Ip_MotAgCumvAlgndMrf();
    
    /* init for variable SysKineAndEff_Ip_MotVelCrf */
    _main_gen_init_sym_SysKineAndEff_Ip_MotVelCrf();
    
    /* init for variable SysKineAndEff_Ip_PinionAg */
    _main_gen_init_sym_SysKineAndEff_Ip_PinionAg();
    
    /* init for variable SysKineAndEff_Op_HwAg : useless (never read) */

    /* init for variable SysKineAndEff_Op_HwVel : useless (never read) */

    /* init for variable SysKineAndEff_Op_MotAgToRackPosnInstsRat : useless (never read) */

    /* init for variable SysKineAndEff_Op_MotToRackFInstsRat : useless (never read) */

    /* init for variable SysKineAndEff_Op_MotToRackInstsEff : useless (never read) */

    /* init for variable SysKineAndEff_Op_PinionAgToRackInstsEff : useless (never read) */

    /* init for variable SysKineAndEff_Op_PinionAgToRackPosnInstsRat : useless (never read) */

    /* init for variable SysKineAndEff_Op_PinionTqToRackFInstsRat : useless (never read) */

    /* init for variable SysKineAndEff_Op_PinionVel : useless (never read) */

    /* init for variable SysKineAndEff_Op_RackPosn : useless (never read) */

    /* init for variable SysKineAndEff_Op_RackVel : useless (never read) */

    /* init for variable SysKineAndEff_Op_RoadWhlAg : useless (never read) */

    /* init for variable SysKineAndEff_Op_SteerArmLen : useless (never read) */

    /* init for variable SysKineAndEff_Op_SysAssiTqRat : useless (never read) */

    /* init for variable SysKineAndEff_Op_SysKineRat : useless (never read) */

    /* init for variable SysKineAndEff_Op_SysTqRat : useless (never read) */

    /* init for variable SysKineAndEff_Cal_SysKineAndEffCmplncErrDerivtvCutOffFrq */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffCmplncErrDerivtvCutOffFrq();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffMotAgScaX */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffMotAgScaX();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffMotAgToRackPosRatScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffMotAgToRackPosRatScaY();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffMotToRackEffScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffMotToRackEffScaY();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffPinionAgToRackPosRatScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffPinionAgToRackPosRatScaY();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffPinionToRackEffScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffPinionToRackEffScaY();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffRackPosScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffRackPosScaY();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffRoadWhlFromRackPosScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffRoadWhlFromRackPosScaY();
    
    /* init for variable SysKineAndEff_Cal_SysKineAndEffSteerArmLenFromRackPosScaY */
    _main_gen_init_sym_SysKineAndEff_Cal_SysKineAndEffSteerArmLenFromRackPosScaY();
    
    /* init for variable SysKineAndEff_Pim_CmplncErrDerivtvPrev */
    _main_gen_init_sym_SysKineAndEff_Pim_CmplncErrDerivtvPrev();
    
    /* init for variable SysKineAndEff_Pim_CmplncErrPinionToHwPrev */
    _main_gen_init_sym_SysKineAndEff_Pim_CmplncErrPinionToHwPrev();
    
}
