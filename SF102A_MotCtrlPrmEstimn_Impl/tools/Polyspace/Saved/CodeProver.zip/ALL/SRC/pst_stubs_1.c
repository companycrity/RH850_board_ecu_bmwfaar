#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    x.MotBackEmfConNom = _main_gen_init_g10();
    x.MotRNom = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_DualEcuFltMtgtnEna(void)
{
    extern __PST__UINT8 MotCtrlPrmEstimn_Ip_DualEcuFltMtgtnEna;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_DualEcuFltMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 MotCtrlPrmEstimn_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotCurrDaxCmd(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Ip_MotCurrDaxCmd;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_MotCurrDaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotCurrQaxCmd(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Ip_MotCurrQaxCmd;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_MotCurrQaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotFetT(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Ip_MotFetT;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_MotFetT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotMagT(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Ip_MotMagT;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_MotMagT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotWidgT(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Ip_MotWidgT;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Ip_MotWidgT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetRNom(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetRNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetRNom = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetThermCoeff(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetThermCoeff;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetThermCoeff = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMagThermCoeff(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMagThermCoeff;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMagThermCoeff = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConHiLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConHiLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConHiLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConLoLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConLoLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConLoLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConNom(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConNom = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnScaIvtrLoaMtgtn(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnScaIvtrLoaMtgtn;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnScaIvtrLoaMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnX(void)
{
    extern __PST__g__29 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 16; _main_gen_tmp_1_0++)
            {
                /* base type */
                MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnX[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnY(void)
{
    extern __PST__g__29 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 16; _main_gen_tmp_2_0++)
            {
                /* base type */
                MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnY[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrDaxInduSatnBilnrSeln(void)
{
    extern __PST__g__31 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrDaxInduSatnBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 6; _main_gen_tmp_3_0++)
            {
                /* base type */
                MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrDaxInduSatnBilnrSeln[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrQaxInduSatnX(void)
{
    extern __PST__g__32 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrQaxInduSatnX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 7; _main_gen_tmp_4_0++)
            {
                /* base type */
                MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrQaxInduSatnX[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxHiLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxHiLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxHiLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxIvtrLoaMtgtn(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxIvtrLoaMtgtn;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxIvtrLoaMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxLoLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxLoLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxLoLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxNom(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxNom = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxSatnScaY(void)
{
    extern __PST__g__33 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxSatnScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 7; _main_gen_tmp_5_0++)
            {
                __PST__UINT32 _main_gen_tmp_5_1;
                
                for (_main_gen_tmp_5_1 = 0; _main_gen_tmp_5_1 < 6; _main_gen_tmp_5_1++)
                {
                    /* base type */
                    MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxSatnScaY[_main_gen_tmp_5_0][_main_gen_tmp_5_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxHiLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxHiLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxHiLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxIvtrLoaMtgtn(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxIvtrLoaMtgtn;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxIvtrLoaMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxLoLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxLoLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxLoLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxNom(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxNom = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxSatnScaY(void)
{
    extern __PST__g__33 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxSatnScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 7; _main_gen_tmp_6_0++)
            {
                __PST__UINT32 _main_gen_tmp_6_1;
                
                for (_main_gen_tmp_6_1 = 0; _main_gen_tmp_6_1 < 6; _main_gen_tmp_6_1++)
                {
                    /* base type */
                    MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxSatnScaY[_main_gen_tmp_6_0][_main_gen_tmp_6_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRHiLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRHiLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRHiLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRLoLim(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRLoLim;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRLoLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRNom(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRNom = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotWidgThermCoeff(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotWidgThermCoeff;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotWidgThermCoeff = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnTNom(void)
{
    extern __PST__g__28 MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnTNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnTNom = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Pim_MotPrmNom(void)
{
    extern struct __PST__g__34 MotCtrlPrmEstimn_Pim_MotPrmNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Pim_MotPrmNom = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Irv_MotBackEmfConFf(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Irv_MotBackEmfConFf;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Irv_MotBackEmfConFf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_ReqResPtr(void)
{
    extern __PST__UINT8 MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_ReqResPtr;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_ReqResPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Srv_MotPrmNom_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 MotCtrlPrmEstimn_Srv_MotPrmNom_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Srv_MotPrmNom_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotBackEmfConNom(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotBackEmfConNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotBackEmfConNom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotRNom(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotRNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotRNom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotBackEmfConNom(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotBackEmfConNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotBackEmfConNom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotRNom(void)
{
    extern __PST__FLOAT32 MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotRNom;
    
    /* initialization with random value */
    {
        MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotRNom = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotCtrlPrmEstimn_Ip_DualEcuFltMtgtnEna */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_DualEcuFltMtgtnEna();
    
    /* init for variable MotCtrlPrmEstimn_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable MotCtrlPrmEstimn_Ip_MotCurrDaxCmd */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotCurrDaxCmd();
    
    /* init for variable MotCtrlPrmEstimn_Ip_MotCurrQaxCmd */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotCurrQaxCmd();
    
    /* init for variable MotCtrlPrmEstimn_Ip_MotFetT */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotFetT();
    
    /* init for variable MotCtrlPrmEstimn_Ip_MotMagT */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotMagT();
    
    /* init for variable MotCtrlPrmEstimn_Ip_MotWidgT */
    _main_gen_init_sym_MotCtrlPrmEstimn_Ip_MotWidgT();
    
    /* init for variable MotCtrlPrmEstimn_Op_MotBackEmfConEstimd : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Op_MotInduDaxEstimd : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Op_MotInduDaxEstimdIvs : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Op_MotInduQaxEstimd : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Op_MotInduQaxEstimdIvs : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Op_MotREstimd : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetRNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetRNom();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetThermCoeff */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnFetThermCoeff();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMagThermCoeff */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMagThermCoeff();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConHiLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConHiLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConLoLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConLoLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConNom();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnScaIvtrLoaMtgtn */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnScaIvtrLoaMtgtn();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnX */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnX();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnY */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotBackEmfConSatnY();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrDaxInduSatnBilnrSeln */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrDaxInduSatnBilnrSeln();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrQaxInduSatnX */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotCurrQaxInduSatnX();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxHiLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxHiLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxIvtrLoaMtgtn */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxIvtrLoaMtgtn();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxLoLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxLoLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxNom();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxSatnScaY */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduDaxSatnScaY();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxHiLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxHiLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxIvtrLoaMtgtn */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxIvtrLoaMtgtn();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxLoLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxLoLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxNom();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxSatnScaY */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotInduQaxSatnScaY();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRHiLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRHiLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRLoLim */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRLoLim();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotRNom();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotWidgThermCoeff */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnMotWidgThermCoeff();
    
    /* init for variable MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnTNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cal_MotCtrlPrmEstimnTNom();
    
    /* init for variable MotCtrlPrmEstimn_Pim_MotPrmNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Pim_MotPrmNom();
    
    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnCtrlrREstimdPreLim : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnFetRFfEstimd : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotBackEmfConEstimdPreLim : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotBackEmfConEstimdSatnSca : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotInduEstimdPreLimDax : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotInduEstimdPreLimQax : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotInduEstimdSatnScaDax : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotInduEstimdSatnScaQax : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Pim_dMotCtrlPrmEstimnMotRFfEstimd : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Irv_MotBackEmfConFf */
    _main_gen_init_sym_MotCtrlPrmEstimn_Irv_MotBackEmfConFf();
    
    /* init for variable MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_ReqResPtr */
    _main_gen_init_sym_MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_ReqResPtr();
    
    /* init for variable MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_Return */
    _main_gen_init_sym_MotCtrlPrmEstimn_Srv_MotPrmNom_GetErrorStatus_Return();
    
    /* init for variable MotCtrlPrmEstimn_Srv_MotPrmNom_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable MotCtrlPrmEstimn_Srv_MotPrmNom_SetRamBlockStatus_Return */
    _main_gen_init_sym_MotCtrlPrmEstimn_Srv_MotPrmNom_SetRamBlockStatus_Return();
    
    /* init for variable MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotBackEmfConNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotBackEmfConNom();
    
    /* init for variable MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotRNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cli_GetMotPrmNomEol_MotRNom();
    
    /* init for variable MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotBackEmfConNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotBackEmfConNom();
    
    /* init for variable MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotRNom */
    _main_gen_init_sym_MotCtrlPrmEstimn_Cli_SetMotPrmNomEol_MotRNom();
    
}
