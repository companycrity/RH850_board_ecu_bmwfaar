#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReq(void)
{
    extern __PST__FLOAT32 BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReq;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReqVld(void)
{
    extern __PST__UINT8 BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReqVld;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReqVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReq(void)
{
    extern __PST__UINT8 BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReq;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReq = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReqVld(void)
{
    extern __PST__UINT8 BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReqVld;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReqVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 BmwTrfcJamAssiDampg_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_TrfcJamAssiCmdEna(void)
{
    extern __PST__UINT8 BmwTrfcJamAssiDampg_Ip_TrfcJamAssiCmdEna;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_TrfcJamAssiCmdEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwTrfcJamAssiDampg_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgX(void)
{
    extern __PST__g__25 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 10; _main_gen_tmp_0_0++)
            {
                /* base type */
                BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgX[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgY(void)
{
    extern __PST__g__25 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 10; _main_gen_tmp_1_0++)
            {
                /* base type */
                BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgY[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimExcddFltRefTiThd(void)
{
    extern __PST__g__26 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimExcddFltRefTiThd;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimExcddFltRefTiThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgX(void)
{
    extern __PST__g__27 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 12; _main_gen_tmp_2_0++)
            {
                /* base type */
                BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgY(void)
{
    extern __PST__g__28 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 12; _main_gen_tmp_3_0++)
            {
                __PST__UINT32 _main_gen_tmp_3_1;
                
                for (_main_gen_tmp_3_1 = 0; _main_gen_tmp_3_1 < 12; _main_gen_tmp_3_1++)
                {
                    /* base type */
                    BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgY[_main_gen_tmp_3_0][_main_gen_tmp_3_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgRatThd(void)
{
    extern __PST__g__29 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgRatThd;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgRatThd = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnActv(void)
{
    extern __PST__g__29 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnActv;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnActv = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInactv(void)
{
    extern __PST__g__29 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInactv;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInactv = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInvld(void)
{
    extern __PST__g__29 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInvld;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInvld = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateUp(void)
{
    extern __PST__g__29 BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateUp;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateUp = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__27 BmwTrfcJamAssiDampg_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 12; _main_gen_tmp_4_0++)
            {
                /* base type */
                BmwTrfcJamAssiDampg_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_BmwTrfcJamAssiDampgScaStVari(void)
{
    extern __PST__FLOAT32 BmwTrfcJamAssiDampg_Pim_BmwTrfcJamAssiDampgScaStVari;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Pim_BmwTrfcJamAssiDampgScaStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_LimExcddFltRefTi(void)
{
    extern __PST__UINT32 BmwTrfcJamAssiDampg_Pim_LimExcddFltRefTi;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Pim_LimExcddFltRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_PrevLimExcddFlt(void)
{
    extern __PST__UINT8 BmwTrfcJamAssiDampg_Pim_PrevLimExcddFlt;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Pim_PrevLimExcddFlt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_TmpBmwTrfcJamAssiDampgSt(void)
{
    extern __PST__UINT8 BmwTrfcJamAssiDampg_Pim_TmpBmwTrfcJamAssiDampgSt;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Pim_TmpBmwTrfcJamAssiDampgSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwTrfcJamAssiDampg_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTrfcJamAssiDampg_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwTrfcJamAssiDampg_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwTrfcJamAssiDampg_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReq */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReq();
    
    /* init for variable BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReqVld */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgScaReqVld();
    
    /* init for variable BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReq */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReq();
    
    /* init for variable BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReqVld */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_BmwTrfcJamAssiDampgStReqVld();
    
    /* init for variable BmwTrfcJamAssiDampg_Ip_MotVelCrf */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_MotVelCrf();
    
    /* init for variable BmwTrfcJamAssiDampg_Ip_TrfcJamAssiCmdEna */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_TrfcJamAssiCmdEna();
    
    /* init for variable BmwTrfcJamAssiDampg_Ip_VehSpd */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Ip_VehSpd();
    
    /* init for variable BmwTrfcJamAssiDampg_Op_BmwTrfcJamAssiDampgSt : useless (never read) */

    /* init for variable BmwTrfcJamAssiDampg_Op_TrfcJamAssiCmd : useless (never read) */

    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgX */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgX();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgY */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgBasDampgY();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimExcddFltRefTiThd */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimExcddFltRefTiThd();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgX */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgX();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgY */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgLimdDampgY();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgRatThd */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgRatThd();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnActv */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnActv();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInactv */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInactv();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInvld */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateDwnInvld();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateUp */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_BmwTrfcJamAssiDampgSlewRateUp();
    
    /* init for variable BmwTrfcJamAssiDampg_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable BmwTrfcJamAssiDampg_Pim_BmwTrfcJamAssiDampgScaStVari */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_BmwTrfcJamAssiDampgScaStVari();
    
    /* init for variable BmwTrfcJamAssiDampg_Pim_LimExcddFltRefTi */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_LimExcddFltRefTi();
    
    /* init for variable BmwTrfcJamAssiDampg_Pim_PrevLimExcddFlt */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_PrevLimExcddFlt();
    
    /* init for variable BmwTrfcJamAssiDampg_Pim_TmpBmwTrfcJamAssiDampgSt */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Pim_TmpBmwTrfcJamAssiDampgSt();
    
    /* init for variable BmwTrfcJamAssiDampg_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwTrfcJamAssiDampg_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwTrfcJamAssiDampg_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwTrfcJamAssiDampg_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
