#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwStReqMgr_Ip_BmwVehCdn(void)
{
    extern __PST__UINT8 BmwStReqMgr_Ip_BmwVehCdn;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_BmwVehCdn = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_BmwVehCdnVld(void)
{
    extern __PST__UINT8 BmwStReqMgr_Ip_BmwVehCdnVld;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_BmwVehCdnVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_BmwVehSpdSts(void)
{
    extern __PST__UINT8 BmwStReqMgr_Ip_BmwVehSpdSts;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_BmwVehSpdSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_DiagcStsNonRcvrlReqDiFltPrsnt(void)
{
    extern __PST__UINT8 BmwStReqMgr_Ip_DiagcStsNonRcvrlReqDiFltPrsnt;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_DiagcStsNonRcvrlReqDiFltPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_HwTq(void)
{
    extern __PST__FLOAT32 BmwStReqMgr_Ip_HwTq;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_PwrLimrRednFac(void)
{
    extern __PST__FLOAT32 BmwStReqMgr_Ip_PwrLimrRednFac;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_PwrLimrRednFac = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_SysSt(void)
{
    extern __PST__UINT8 BmwStReqMgr_Ip_SysSt;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_SysStFltOutpReqDi(void)
{
    extern __PST__UINT8 BmwStReqMgr_Ip_SysStFltOutpReqDi;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_SysStFltOutpReqDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_ThermRednFac(void)
{
    extern __PST__FLOAT32 BmwStReqMgr_Ip_ThermRednFac;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_ThermRednFac = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwStReqMgr_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrAllwToOffThd(void)
{
    extern __PST__g__27 BmwStReqMgr_Cal_BmwStReqMgrAllwToOffThd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrAllwToOffThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrDrvrActvTmrThd(void)
{
    extern __PST__g__27 BmwStReqMgr_Cal_BmwStReqMgrDrvrActvTmrThd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrDrvrActvTmrThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrHwTqThd(void)
{
    extern __PST__g__28 BmwStReqMgr_Cal_BmwStReqMgrHwTqThd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrHwTqThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrOperRampRate(void)
{
    extern __PST__g__28 BmwStReqMgr_Cal_BmwStReqMgrOperRampRate;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrOperRampRate = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrStsDrvrActvyTqChgThd(void)
{
    extern __PST__g__28 BmwStReqMgr_Cal_BmwStReqMgrStsDrvrActvyTqChgThd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrStsDrvrActvyTqChgThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrSwtOffSpdLim(void)
{
    extern __PST__g__28 BmwStReqMgr_Cal_BmwStReqMgrSwtOffSpdLim;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrSwtOffSpdLim = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrSysProtnRednFacThd(void)
{
    extern __PST__g__28 BmwStReqMgr_Cal_BmwStReqMgrSysProtnRednFacThd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrSysProtnRednFacThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrVehCdnOvrd(void)
{
    extern __PST__g__29 BmwStReqMgr_Cal_BmwStReqMgrVehCdnOvrd;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Cal_BmwStReqMgrVehCdnOvrd = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Pim_BmwVehCdnLvngDurn(void)
{
    extern __PST__UINT32 BmwStReqMgr_Pim_BmwVehCdnLvngDurn;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Pim_BmwVehCdnLvngDurn = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Pim_DrvrActvRefTmr(void)
{
    extern __PST__UINT32 BmwStReqMgr_Pim_DrvrActvRefTmr;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Pim_DrvrActvRefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Pim_PrevHwTq(void)
{
    extern __PST__FLOAT32 BmwStReqMgr_Pim_PrevHwTq;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Pim_PrevHwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Pim_PrevTarEcuSt(void)
{
    extern __PST__UINT8 BmwStReqMgr_Pim_PrevTarEcuSt;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Pim_PrevTarEcuSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwStReqMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwStReqMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_PinSt(void)
{
    extern __PST__UINT8 BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_PinSt;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_Return(void)
{
    extern __PST__UINT8 BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_Return;
    
    /* initialization with random value */
    {
        BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwStReqMgr_Ip_BmwVehCdn */
    _main_gen_init_sym_BmwStReqMgr_Ip_BmwVehCdn();
    
    /* init for variable BmwStReqMgr_Ip_BmwVehCdnVld */
    _main_gen_init_sym_BmwStReqMgr_Ip_BmwVehCdnVld();
    
    /* init for variable BmwStReqMgr_Ip_BmwVehSpdSts */
    _main_gen_init_sym_BmwStReqMgr_Ip_BmwVehSpdSts();
    
    /* init for variable BmwStReqMgr_Ip_DiagcStsNonRcvrlReqDiFltPrsnt */
    _main_gen_init_sym_BmwStReqMgr_Ip_DiagcStsNonRcvrlReqDiFltPrsnt();
    
    /* init for variable BmwStReqMgr_Ip_HwTq */
    _main_gen_init_sym_BmwStReqMgr_Ip_HwTq();
    
    /* init for variable BmwStReqMgr_Ip_PwrLimrRednFac */
    _main_gen_init_sym_BmwStReqMgr_Ip_PwrLimrRednFac();
    
    /* init for variable BmwStReqMgr_Ip_SysSt */
    _main_gen_init_sym_BmwStReqMgr_Ip_SysSt();
    
    /* init for variable BmwStReqMgr_Ip_SysStFltOutpReqDi */
    _main_gen_init_sym_BmwStReqMgr_Ip_SysStFltOutpReqDi();
    
    /* init for variable BmwStReqMgr_Ip_ThermRednFac */
    _main_gen_init_sym_BmwStReqMgr_Ip_ThermRednFac();
    
    /* init for variable BmwStReqMgr_Ip_VehSpd */
    _main_gen_init_sym_BmwStReqMgr_Ip_VehSpd();
    
    /* init for variable BmwStReqMgr_Op_BmwEpsFctSts : useless (never read) */

    /* init for variable BmwStReqMgr_Op_PwrSplyEnaReq : useless (never read) */

    /* init for variable BmwStReqMgr_Op_StsDrvrActvy : useless (never read) */

    /* init for variable BmwStReqMgr_Op_StsSteerAssi : useless (never read) */

    /* init for variable BmwStReqMgr_Op_SysOperMotTqCmdSca : useless (never read) */

    /* init for variable BmwStReqMgr_Op_SysOperRampRate : useless (never read) */

    /* init for variable BmwStReqMgr_Op_SysStReqEna : useless (never read) */

    /* init for variable BmwStReqMgr_Op_TarEcuSt : useless (never read) */

    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrAllwToOffThd */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrAllwToOffThd();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrDrvrActvTmrThd */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrDrvrActvTmrThd();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrHwTqThd */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrHwTqThd();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrOperRampRate */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrOperRampRate();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrStsDrvrActvyTqChgThd */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrStsDrvrActvyTqChgThd();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrSwtOffSpdLim */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrSwtOffSpdLim();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrSysProtnRednFacThd */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrSysProtnRednFacThd();
    
    /* init for variable BmwStReqMgr_Cal_BmwStReqMgrVehCdnOvrd */
    _main_gen_init_sym_BmwStReqMgr_Cal_BmwStReqMgrVehCdnOvrd();
    
    /* init for variable BmwStReqMgr_Pim_BmwVehCdnLvngDurn */
    _main_gen_init_sym_BmwStReqMgr_Pim_BmwVehCdnLvngDurn();
    
    /* init for variable BmwStReqMgr_Pim_DrvrActvRefTmr */
    _main_gen_init_sym_BmwStReqMgr_Pim_DrvrActvRefTmr();
    
    /* init for variable BmwStReqMgr_Pim_PrevHwTq */
    _main_gen_init_sym_BmwStReqMgr_Pim_PrevHwTq();
    
    /* init for variable BmwStReqMgr_Pim_PrevTarEcuSt */
    _main_gen_init_sym_BmwStReqMgr_Pim_PrevTarEcuSt();
    
    /* init for variable BmwStReqMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwStReqMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwStReqMgr_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwStReqMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwStReqMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_PinSt */
    _main_gen_init_sym_BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_PinSt();
    
    /* init for variable BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_Return */
    _main_gen_init_sym_BmwStReqMgr_Srv_IoHwAb_GetGpioMcuEna_Return();
    
}
