/* Contract file for CM340A */

#define  MCUDIAGCERRINJ         STD_OFF

extern void ClrErrInjReg_Oper(void);
extern void ReadErrInjReg_Oper(uint32* ErrId);
extern void StrtErrInjCntr_Oper(void);

#if (MCUDIAGCERRINJ == STD_ON)

#define MCUERRINJ_NTC0032BIT03ANDBIT01CASE01_CNT_U32                                    0x00320A01U
#define MCUERRINJ_NTC0032BIT03ANDBIT02ANDBIT01CASE01_CNT_U32                    0x00320E01U
#define MCUERRINJ_NTC0032BIT03ANDBIT02CASE01_CNT_U32                                    0x00320C01U
#define MCUERRINJ_NTC0032BIT03CASE01_CNT_U32                                                    0x00320801U
#define MCUERRINJ_NTC0032BIT04ANDBIT01CASE01_CNT_U32                                    0x00321201U
#define MCUERRINJ_NTC0032BIT04ANDBIT01CASE02_CNT_U32                                    0x00321202U
#define MCUERRINJ_NTC0032BIT04ANDBIT02ANDBIT01CASE01_CNT_U32                    0x00321601U
#define MCUERRINJ_NTC0032BIT04ANDBIT02ANDBIT01CASE02_CNT_U32                    0x00321602U
#define MCUERRINJ_NTC0032BIT04ANDBIT02CASE01_CNT_U32                                    0x00321401U
#define MCUERRINJ_NTC0032BIT04ANDBIT02CASE02_CNT_U32                                    0x00321402U
#define MCUERRINJ_NTC0032BIT04ANDBIT02CASE03_CNT_U32                                    0x00321403U
#define MCUERRINJ_NTC0032BIT04ANDBIT03ANDBIT01CASE01_CNT_U32                    0x00321A01U
#define MCUERRINJ_NTC0032BIT04ANDBIT03ANDBIT02ANDBIT01CASE01_CNT_U32    0x00321E01U
#define MCUERRINJ_NTC0032BIT04ANDBIT03ANDBIT02CASE01_CNT_U32                    0x00321C01U
#define MCUERRINJ_NTC0032BIT05CASE01_CNT_U32                                                    0x00322001U
#define MCUERRINJ_NTC0032BIT06CASE01_CNT_U32                                                    0x00324001U
#define MCUERRINJ_NTC0033BIT05CASE01_CNT_U32                                                    0x00332001U
#define MCUERRINJ_NTC0033BIT06CASE01_CNT_U32                                                    0x00334001U


extern FUNC(void, CDD_AdcDiagc_CODE) InjAdcErr(void);
#endif

