#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__298 _main_gen_init_g298(void);

extern union __PST__g__238 _main_gen_init_g238(void);

extern union __PST__g__226 _main_gen_init_g226(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__226 _main_gen_init_g226(void)
{
    static union __PST__g__226 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__238 _main_gen_init_g238(void)
{
    static union __PST__g__238 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* struct/union type */
    x.ECR = _main_gen_init_g226();
    x.PER = _main_gen_init_g238();
    return x;
}

__PST__g__298 _main_gen_init_g298(void)
{
    __PST__g__298 x;
    /* struct/union type */
    x.ECR = _main_gen_init_g226();
    x.PER = _main_gen_init_g238();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup2Ref0(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0ScanGroup2Ref0;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0ScanGroup2Ref0 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup2Ref1(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0ScanGroup2Ref1;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0ScanGroup2Ref1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup3Ref0(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0ScanGroup3Ref0;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0ScanGroup3Ref0 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup3Ref1(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0ScanGroup3Ref1;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0ScanGroup3Ref1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0SelfDiag0(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0SelfDiag0;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0SelfDiag0 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0SelfDiag2(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0SelfDiag2;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0SelfDiag2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc0SelfDiag4(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc0SelfDiag4;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc0SelfDiag4 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup2Ref0(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1ScanGroup2Ref0;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1ScanGroup2Ref0 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup2Ref1(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1ScanGroup2Ref1;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1ScanGroup2Ref1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup3Ref0(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1ScanGroup3Ref0;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1ScanGroup3Ref0 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup3Ref1(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1ScanGroup3Ref1;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1ScanGroup3Ref1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1SelfDiag0(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1SelfDiag0;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1SelfDiag0 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1SelfDiag2(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1SelfDiag2;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1SelfDiag2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Ip_Adc1SelfDiag4(void)
{
    extern __PST__FLOAT32 AdcDiagc_Ip_Adc1SelfDiag4;
    
    /* initialization with random value */
    {
        AdcDiagc_Ip_Adc1SelfDiag4 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x032FailStep(void)
{
    extern __PST__g__28 AdcDiagc_Cal_AdcDiagcNtc0x032FailStep;
    
    /* initialization with random value */
    {
        AdcDiagc_Cal_AdcDiagcNtc0x032FailStep = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x032PassStep(void)
{
    extern __PST__g__28 AdcDiagc_Cal_AdcDiagcNtc0x032PassStep;
    
    /* initialization with random value */
    {
        AdcDiagc_Cal_AdcDiagcNtc0x032PassStep = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x033FailStep(void)
{
    extern __PST__g__28 AdcDiagc_Cal_AdcDiagcNtc0x033FailStep;
    
    /* initialization with random value */
    {
        AdcDiagc_Cal_AdcDiagcNtc0x033FailStep = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x033PassStep(void)
{
    extern __PST__g__28 AdcDiagc_Cal_AdcDiagcNtc0x033PassStep;
    
    /* initialization with random value */
    {
        AdcDiagc_Cal_AdcDiagcNtc0x033PassStep = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt0(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc0FltCntSt0;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc0FltCntSt0 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt2(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc0FltCntSt2;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc0FltCntSt2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt4(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc0FltCntSt4;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc0FltCntSt4 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt6(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc0FltCntSt6;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc0FltCntSt6 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc0ScanGroup2RefFltCntSt(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc0ScanGroup2RefFltCntSt;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc0ScanGroup2RefFltCntSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc0ScanGroup3RefFltCntSt(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc0ScanGroup3RefFltCntSt;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc0ScanGroup3RefFltCntSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt0(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc1FltCntSt0;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc1FltCntSt0 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt2(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc1FltCntSt2;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc1FltCntSt2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt4(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc1FltCntSt4;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc1FltCntSt4 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt6(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc1FltCntSt6;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc1FltCntSt6 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc1ScanGroup2RefFltCntSt(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc1ScanGroup2RefFltCntSt;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc1ScanGroup2RefFltCntSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_Adc1ScanGroup3RefFltCntSt(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_Adc1ScanGroup3RefFltCntSt;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_Adc1ScanGroup3RefFltCntSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_AdcDiagcEndPtr(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_AdcDiagcEndPtr;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_AdcDiagcEndPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_AdcDiagcSt(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_AdcDiagcSt;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_AdcDiagcSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Pim_AdcDiagcStrtPtr(void)
{
    extern __PST__UINT8 AdcDiagc_Pim_AdcDiagcStrtPtr;
    
    /* initialization with random value */
    {
        AdcDiagc_Pim_AdcDiagcStrtPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ADCD0(void)
{
    extern __PST__g__29 ADCD0;
    
    /* initialization with random value */
    {
        ADCD0 = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_ADCD1(void)
{
    extern __PST__g__298 ADCD1;
    
    /* initialization with random value */
    {
        ADCD1 = _main_gen_init_g298();
    }
}

static void _main_gen_init_sym_AdcDiagc_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 AdcDiagc_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        AdcDiagc_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 AdcDiagc_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        AdcDiagc_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AdcDiagc_Srv_ReadErrInjReg_ErrId(void)
{
    extern __PST__UINT32 AdcDiagc_Srv_ReadErrInjReg_ErrId;
    
    /* initialization with random value */
    {
        AdcDiagc_Srv_ReadErrInjReg_ErrId = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_AdcDiagc_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 AdcDiagc_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        AdcDiagc_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable AdcDiagc_Ip_Adc0ScanGroup2Ref0 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup2Ref0();
    
    /* init for variable AdcDiagc_Ip_Adc0ScanGroup2Ref1 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup2Ref1();
    
    /* init for variable AdcDiagc_Ip_Adc0ScanGroup3Ref0 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup3Ref0();
    
    /* init for variable AdcDiagc_Ip_Adc0ScanGroup3Ref1 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0ScanGroup3Ref1();
    
    /* init for variable AdcDiagc_Ip_Adc0SelfDiag0 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0SelfDiag0();
    
    /* init for variable AdcDiagc_Ip_Adc0SelfDiag2 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0SelfDiag2();
    
    /* init for variable AdcDiagc_Ip_Adc0SelfDiag4 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc0SelfDiag4();
    
    /* init for variable AdcDiagc_Ip_Adc1ScanGroup2Ref0 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup2Ref0();
    
    /* init for variable AdcDiagc_Ip_Adc1ScanGroup2Ref1 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup2Ref1();
    
    /* init for variable AdcDiagc_Ip_Adc1ScanGroup3Ref0 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup3Ref0();
    
    /* init for variable AdcDiagc_Ip_Adc1ScanGroup3Ref1 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1ScanGroup3Ref1();
    
    /* init for variable AdcDiagc_Ip_Adc1SelfDiag0 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1SelfDiag0();
    
    /* init for variable AdcDiagc_Ip_Adc1SelfDiag2 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1SelfDiag2();
    
    /* init for variable AdcDiagc_Ip_Adc1SelfDiag4 */
    _main_gen_init_sym_AdcDiagc_Ip_Adc1SelfDiag4();
    
    /* init for variable AdcDiagc_Op_Adc0Faild : useless (never read) */

    /* init for variable AdcDiagc_Op_Adc1Faild : useless (never read) */

    /* init for variable AdcDiagc_Op_AdcDiagcEndPtrOutp : useless (never read) */

    /* init for variable AdcDiagc_Op_AdcDiagcStrtPtrOutp : useless (never read) */

    /* init for variable AdcDiagc_Cal_AdcDiagcNtc0x032FailStep */
    _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x032FailStep();
    
    /* init for variable AdcDiagc_Cal_AdcDiagcNtc0x032PassStep */
    _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x032PassStep();
    
    /* init for variable AdcDiagc_Cal_AdcDiagcNtc0x033FailStep */
    _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x033FailStep();
    
    /* init for variable AdcDiagc_Cal_AdcDiagcNtc0x033PassStep */
    _main_gen_init_sym_AdcDiagc_Cal_AdcDiagcNtc0x033PassStep();
    
    /* init for variable AdcDiagc_Pim_Adc0FltCntSt0 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt0();
    
    /* init for variable AdcDiagc_Pim_Adc0FltCntSt2 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt2();
    
    /* init for variable AdcDiagc_Pim_Adc0FltCntSt4 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt4();
    
    /* init for variable AdcDiagc_Pim_Adc0FltCntSt6 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc0FltCntSt6();
    
    /* init for variable AdcDiagc_Pim_Adc0ScanGroup2RefFltCntSt */
    _main_gen_init_sym_AdcDiagc_Pim_Adc0ScanGroup2RefFltCntSt();
    
    /* init for variable AdcDiagc_Pim_Adc0ScanGroup3RefFltCntSt */
    _main_gen_init_sym_AdcDiagc_Pim_Adc0ScanGroup3RefFltCntSt();
    
    /* init for variable AdcDiagc_Pim_Adc1FltCntSt0 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt0();
    
    /* init for variable AdcDiagc_Pim_Adc1FltCntSt2 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt2();
    
    /* init for variable AdcDiagc_Pim_Adc1FltCntSt4 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt4();
    
    /* init for variable AdcDiagc_Pim_Adc1FltCntSt6 */
    _main_gen_init_sym_AdcDiagc_Pim_Adc1FltCntSt6();
    
    /* init for variable AdcDiagc_Pim_Adc1ScanGroup2RefFltCntSt */
    _main_gen_init_sym_AdcDiagc_Pim_Adc1ScanGroup2RefFltCntSt();
    
    /* init for variable AdcDiagc_Pim_Adc1ScanGroup3RefFltCntSt */
    _main_gen_init_sym_AdcDiagc_Pim_Adc1ScanGroup3RefFltCntSt();
    
    /* init for variable AdcDiagc_Pim_AdcDiagcEndPtr */
    _main_gen_init_sym_AdcDiagc_Pim_AdcDiagcEndPtr();
    
    /* init for variable AdcDiagc_Pim_AdcDiagcSt */
    _main_gen_init_sym_AdcDiagc_Pim_AdcDiagcSt();
    
    /* init for variable AdcDiagc_Pim_AdcDiagcStrtPtr */
    _main_gen_init_sym_AdcDiagc_Pim_AdcDiagcStrtPtr();
    
    /* init for variable ADCD0 */
    _main_gen_init_sym_ADCD0();
    
    /* init for variable ADCD1 */
    _main_gen_init_sym_ADCD1();
    
    /* init for variable AdcDiagc_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable AdcDiagc_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_AdcDiagc_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable AdcDiagc_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_AdcDiagc_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable AdcDiagc_Srv_ReadErrInjReg_ErrId */
    _main_gen_init_sym_AdcDiagc_Srv_ReadErrInjReg_ErrId();
    
    /* init for variable AdcDiagc_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable AdcDiagc_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable AdcDiagc_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable AdcDiagc_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable AdcDiagc_Srv_SetNtcSts_Return */
    _main_gen_init_sym_AdcDiagc_Srv_SetNtcSts_Return();
    
}
