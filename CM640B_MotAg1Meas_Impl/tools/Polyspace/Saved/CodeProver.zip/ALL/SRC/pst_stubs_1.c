#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT32 pst_random_g_4;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT32 _main_gen_init_g4(void);

extern struct __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__104 _main_gen_init_g104(void);

extern union __PST__g__95 _main_gen_init_g95(void);

extern union __PST__g__84 _main_gen_init_g84(void);

extern union __PST__g__81 _main_gen_init_g81(void);

extern union __PST__g__69 _main_gen_init_g69(void);

extern union __PST__g__63 _main_gen_init_g63(void);

extern union __PST__g__60 _main_gen_init_g60(void);

extern union __PST__g__57 _main_gen_init_g57(void);

extern union __PST__g__53 _main_gen_init_g53(void);

extern struct __PST__g__42 _main_gen_init_g42(void);

extern union __PST__g__41 _main_gen_init_g41(void);

extern __PST__g__39 _main_gen_init_g39(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__42 _main_gen_init_g42(void)
{
    static struct __PST__g__42 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PWR = bitf;
    }
    return x;
}

union __PST__g__41 _main_gen_init_g41(void)
{
    static union __PST__g__41 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g42();
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__53 _main_gen_init_g53(void)
{
    static union __PST__g__53 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__57 _main_gen_init_g57(void)
{
    static union __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__60 _main_gen_init_g60(void)
{
    static union __PST__g__60 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__63 _main_gen_init_g63(void)
{
    static union __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__69 _main_gen_init_g69(void)
{
    static union __PST__g__69 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__84 _main_gen_init_g84(void)
{
    static union __PST__g__84 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__95 _main_gen_init_g95(void)
{
    static union __PST__g__95 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__105 _main_gen_init_g105(void)
{
    static struct __PST__g__105 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 4095);
        x.BRS = bitf;
    }
    return x;
}

union __PST__g__104 _main_gen_init_g104(void)
{
    static union __PST__g__104 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g105();
    return x;
}

__PST__g__39 _main_gen_init_g39(void)
{
    __PST__g__39 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g41();
    x.STCR0 = _main_gen_init_g53();
    x.CTL1 = _main_gen_init_g57();
    x.CTL2 = _main_gen_init_g60();
    x.MCTL1 = _main_gen_init_g63();
    x.TX0W = _main_gen_init_g69();
    x.MRWP0 = _main_gen_init_g81();
    x.MCTL0 = _main_gen_init_g84();
    x.CFG4 = _main_gen_init_g95();
    x.BRS0 = _main_gen_init_g104();
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1ErrReg(void)
{
    extern __PST__UINT32 MotAg1Meas_Ip_MotAg1ErrReg;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1ErrReg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1ParFltCnt(void)
{
    extern __PST__UINT16 MotAg1Meas_Ip_MotAg1ParFltCnt;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1ParFltCnt = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1Polarity(void)
{
    extern __PST__SINT8 MotAg1Meas_Ip_MotAg1Polarity;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1SpiMecl(void)
{
    extern __PST__UINT16 MotAg1Meas_Ip_MotAg1SpiMecl;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1SpiMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1TurnCntrReg(void)
{
    extern __PST__UINT32 MotAg1Meas_Ip_MotAg1TurnCntrReg;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1TurnCntrReg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1VltgFltCnt(void)
{
    extern __PST__UINT16 MotAg1Meas_Ip_MotAg1VltgFltCnt;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1VltgFltCnt = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg1WarnReg(void)
{
    extern __PST__UINT32 MotAg1Meas_Ip_MotAg1WarnReg;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg1WarnReg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Ip_MotAg4Mecl(void)
{
    extern __PST__UINT16 MotAg1Meas_Ip_MotAg4Mecl;
    
    /* initialization with random value */
    {
        MotAg1Meas_Ip_MotAg4Mecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Cal_MotAg1MeasSnsrIfErrNtcMask(void)
{
    extern __PST__g__36 MotAg1Meas_Cal_MotAg1MeasSnsrIfErrNtcMask;
    
    /* initialization with random value */
    {
        MotAg1Meas_Cal_MotAg1MeasSnsrIfErrNtcMask = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1CoeffTbl(void)
{
    extern __PST__g__37 MotAg1Meas_Pim_MotAg1CoeffTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 26; _main_gen_tmp_0_0++)
            {
                /* base type */
                MotAg1Meas_Pim_MotAg1CoeffTbl[_main_gen_tmp_0_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1CorrnTbl(void)
{
    extern __PST__g__38 MotAg1Meas_Pim_MotAg1CorrnTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 128; _main_gen_tmp_1_0++)
            {
                /* base type */
                MotAg1Meas_Pim_MotAg1CorrnTbl[_main_gen_tmp_1_0] = pst_random_g_2;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1ParFltCntNtcPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1ParFltCntNtcPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1ParFltCntNtcPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1PrevSpiMecl(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1PrevSpiMecl;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1PrevSpiMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1PrevTCUpd(void)
{
    extern __PST__SINT16 MotAg1Meas_Pim_MotAg1PrevTCUpd;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1PrevTCUpd = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1QepFaildCntr(void)
{
    extern __PST__UINT32 MotAg1Meas_Pim_MotAg1QepFaildCntr;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1QepFaildCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1QepFaildPrev(void)
{
    extern __PST__UINT8 MotAg1Meas_Pim_MotAg1QepFaildPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1QepFaildPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrParFltCntNtcPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1TurnCntrParFltCntNtcPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1TurnCntrParFltCntNtcPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrParFltCntPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1TurnCntrParFltCntPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1TurnCntrParFltCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrPrev(void)
{
    extern __PST__SINT16 MotAg1Meas_Pim_MotAg1TurnCntrPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1TurnCntrPrev = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrRollgCntrPrev(void)
{
    extern __PST__UINT8 MotAg1Meas_Pim_MotAg1TurnCntrRollgCntrPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1TurnCntrRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1VltgFltCntNtcPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1VltgFltCntNtcPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1VltgFltCntNtcPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAgMecl1Polarity(void)
{
    extern __PST__SINT8 MotAg1Meas_Pim_MotAgMecl1Polarity;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAgMecl1Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_CSIH3(void)
{
    extern __PST__g__39 CSIH3;
    
    /* initialization with random value */
    {
        CSIH3 = _main_gen_init_g39();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Cal_MotAg1MeasOffs(void)
{
    extern __PST__g__36 MotAg1Meas_Cal_MotAg1MeasOffs;
    
    /* initialization with random value */
    {
        MotAg1Meas_Cal_MotAg1MeasOffs = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1InitOffs(void)
{
    extern __PST__SINT32 MotAg1Meas_Pim_MotAg1InitOffs;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1InitOffs = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1InitOffsCntr(void)
{
    extern __PST__UINT8 MotAg1Meas_Pim_MotAg1InitOffsCntr;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1InitOffsCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1MeclRollgCntrPrev(void)
{
    extern __PST__UINT8 MotAg1Meas_Pim_MotAg1MeclRollgCntrPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1MeclRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1ParFltCntPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1ParFltCntPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1ParFltCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1RawMeclPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1RawMeclPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1RawMeclPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Pim_MotAg1VltgFltCntPrev(void)
{
    extern __PST__UINT16 MotAg1Meas_Pim_MotAg1VltgFltCntPrev;
    
    /* initialization with random value */
    {
        MotAg1Meas_Pim_MotAg1VltgFltCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1QepFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg1QepFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg1QepFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes(void)
{
    extern __PST__g__109 MOTCTRLMGR_MotCtrlMotAg1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 5; _main_gen_tmp_2_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg1RawRes[_main_gen_tmp_2_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 MotAg1Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 MotAg1Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Clk_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Clk_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Clk_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Cs_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Cs_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Cs_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Mosi_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Mosi_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Mosi_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Clk_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Clk_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Clk_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Cs_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Cs_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Cs_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Mosi_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Mosi_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Mosi_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_MotAg1CoeffTbl_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_MotAg1CoeffTbl_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_MotAg1CoeffTbl_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 MotAg1Meas_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        MotAg1Meas_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg1Meas_Cli_MotAg1CoeffTblRead_MotAgCoeffTbl(void)
{
    extern __PST__g__37 MotAg1Meas_Cli_MotAg1CoeffTblRead_MotAgCoeffTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 26; _main_gen_tmp_3_0++)
            {
                /* base type */
                MotAg1Meas_Cli_MotAg1CoeffTblRead_MotAgCoeffTbl[_main_gen_tmp_3_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotAg1Meas_Cli_MotAg1CoeffTblWr_MotAgCoeffTbl(void)
{
    extern __PST__g__37 MotAg1Meas_Cli_MotAg1CoeffTblWr_MotAgCoeffTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 26; _main_gen_tmp_4_0++)
            {
                /* base type */
                MotAg1Meas_Cli_MotAg1CoeffTblWr_MotAgCoeffTbl[_main_gen_tmp_4_0] = pst_random_g_10;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotAg1Meas_Ip_MotAg1ErrReg */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1ErrReg();
    
    /* init for variable MotAg1Meas_Ip_MotAg1ParFltCnt */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1ParFltCnt();
    
    /* init for variable MotAg1Meas_Ip_MotAg1Polarity */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1Polarity();
    
    /* init for variable MotAg1Meas_Ip_MotAg1SpiMecl */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1SpiMecl();
    
    /* init for variable MotAg1Meas_Ip_MotAg1TurnCntrReg */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1TurnCntrReg();
    
    /* init for variable MotAg1Meas_Ip_MotAg1VltgFltCnt */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1VltgFltCnt();
    
    /* init for variable MotAg1Meas_Ip_MotAg1WarnReg */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg1WarnReg();
    
    /* init for variable MotAg1Meas_Ip_MotAg4Mecl */
    _main_gen_init_sym_MotAg1Meas_Ip_MotAg4Mecl();
    
    /* init for variable MotAg1Meas_Op_MotAg1MeclQlfr : useless (never read) */

    /* init for variable MotAg1Meas_Op_MotAg1QepFaild : useless (never read) */

    /* init for variable MotAg1Meas_Op_MotAg1TurnCntr : useless (never read) */

    /* init for variable MotAg1Meas_Op_MotAg1TurnCntrQlfr : useless (never read) */

    /* init for variable MotAg1Meas_Op_MotAg1TurnCntrRollgCntr : useless (never read) */

    /* init for variable MotAg1Meas_Cal_MotAg1MeasSnsrIfErrNtcMask */
    _main_gen_init_sym_MotAg1Meas_Cal_MotAg1MeasSnsrIfErrNtcMask();
    
    /* init for variable MotAg1Meas_Pim_MotAg1CoeffTbl */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1CoeffTbl();
    
    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1Delta : useless (never read) */

    /* init for variable MotAg1Meas_Pim_dMotAg1MeasPwrRstStsLtch : useless (never read) */

    /* init for variable MotAg1Meas_Pim_MotAg1CorrnTbl */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1CorrnTbl();
    
    /* init for variable MotAg1Meas_Pim_MotAg1ParFltCntNtcPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1ParFltCntNtcPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1PrevSpiMecl */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1PrevSpiMecl();
    
    /* init for variable MotAg1Meas_Pim_MotAg1PrevTCUpd */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1PrevTCUpd();
    
    /* init for variable MotAg1Meas_Pim_MotAg1QepFaildCntr */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1QepFaildCntr();
    
    /* init for variable MotAg1Meas_Pim_MotAg1QepFaildPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1QepFaildPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1TurnCntrParFltCntNtcPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrParFltCntNtcPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1TurnCntrParFltCntPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrParFltCntPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1TurnCntrPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1TurnCntrRollgCntrPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1TurnCntrRollgCntrPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1VltgFltCntNtcPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1VltgFltCntNtcPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAgMecl1Polarity */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAgMecl1Polarity();
    
    /* init for variable CSIH3 */
    _main_gen_init_sym_CSIH3();
    
    /* init for variable MotAg1Meas_Cal_MotAg1MeasOffs */
    _main_gen_init_sym_MotAg1Meas_Cal_MotAg1MeasOffs();
    
    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1RawAgReg : useless (never read) */

    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1RawErrReg : useless (never read) */

    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1RawStsReg : useless (never read) */

    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1RawTurnCntrReg : useless (never read) */

    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1RawWarnReg : useless (never read) */

    /* init for variable MotAg1Meas_Pim_dMotAg1MeasMotAg1RtOffs : useless (never read) */

    /* init for variable MotAg1Meas_Pim_MotAg1InitOffs */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1InitOffs();
    
    /* init for variable MotAg1Meas_Pim_MotAg1InitOffsCntr */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1InitOffsCntr();
    
    /* init for variable MotAg1Meas_Pim_MotAg1MeclRollgCntrPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1MeclRollgCntrPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1ParFltCntPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1ParFltCntPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1RawMeclPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1RawMeclPrev();
    
    /* init for variable MotAg1Meas_Pim_MotAg1VltgFltCntPrev */
    _main_gen_init_sym_MotAg1Meas_Pim_MotAg1VltgFltCntPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1QepFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1QepFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1ErrReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1Mecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1MeclRollgCntr : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1ParFltCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1SpiMecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1TurnCntrReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1VltgFltCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1WarnReg : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg4Mecl : useless (never read) */

    /* init for variable MotAg1Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd */
    _main_gen_init_sym_MotAg1Meas_Srv_CnvSnpshtData_s16_SnpshtDataCnvd();
    
    /* init for variable MotAg1Meas_Srv_CnvSnpshtData_s16_SnpshtData : useless (never read) */

    /* init for variable MotAg1Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd */
    _main_gen_init_sym_MotAg1Meas_Srv_CnvSnpshtData_u16_SnpshtDataCnvd();
    
    /* init for variable MotAg1Meas_Srv_CnvSnpshtData_u16_SnpshtData : useless (never read) */

    /* init for variable MotAg1Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable MotAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_MotAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable MotAg1Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Clk_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Clk_Return();
    
    /* init for variable MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Cs_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Cs_Return();
    
    /* init for variable MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Mosi_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetFctGpioMotAg1Mosi_Return();
    
    /* init for variable MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Clk_PinSt : useless (never read) */

    /* init for variable MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Clk_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Clk_Return();
    
    /* init for variable MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Cs_PinSt : useless (never read) */

    /* init for variable MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Cs_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Cs_Return();
    
    /* init for variable MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Mosi_PinSt : useless (never read) */

    /* init for variable MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Mosi_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_IoHwAb_SetGpioMotAg1Mosi_Return();
    
    /* init for variable MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_RequestResultPtr();
    
    /* init for variable MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_MotAg1CoeffTbl_GetErrorStatus_Return();
    
    /* init for variable MotAg1Meas_Srv_MotAg1CoeffTbl_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable MotAg1Meas_Srv_MotAg1CoeffTbl_SetRamBlockStatus_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_MotAg1CoeffTbl_SetRamBlockStatus_Return();
    
    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable MotAg1Meas_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_MotAg1Meas_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable MotAg1Meas_Cli_MotAg1CoeffTblRead_MotAgCoeffTbl */
    _main_gen_init_sym_MotAg1Meas_Cli_MotAg1CoeffTblRead_MotAgCoeffTbl();
    
    /* init for variable MotAg1Meas_Cli_MotAg1CoeffTblWr_MotAgCoeffTbl */
    _main_gen_init_sym_MotAg1Meas_Cli_MotAg1CoeffTblWr_MotAgCoeffTbl();
    
}
