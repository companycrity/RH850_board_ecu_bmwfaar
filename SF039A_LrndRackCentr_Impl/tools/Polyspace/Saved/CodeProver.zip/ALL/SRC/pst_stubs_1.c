#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__32 _main_gen_init_g32(void);

extern struct Rte_CDS_LrndRackCentr _main_gen_init_g28(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.TotRackTrvl = _main_gen_init_g10();
    x.RackCentrMotDeg = _main_gen_init_g10();
    x.RackCentrMotRev = _main_gen_init_g3();
    x.LongTermRackCentrCmpl = _main_gen_init_g6();
    x.MotAgVld = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_LrndRackCentr _main_gen_init_g28(void)
{
    static struct Rte_CDS_LrndRackCentr x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g32();
        }
        x.Pim_LrndRackCentr = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__30 _main_gen_init_g30(void)
{
    static struct __PST__g__30 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_LrndRackCentr(void)
{
    extern __PST__g__25 Rte_Inst_LrndRackCentr;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_LrndRackCentr _main_gen_tmp_2[ARRAY_NBELEM(struct Rte_CDS_LrndRackCentr)];
            __PST__UINT32 _i_main_gen_tmp_3;
            for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct Rte_CDS_LrndRackCentr); _i_main_gen_tmp_3++)
            {
                _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g28();
            }
            Rte_Inst_LrndRackCentr = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct Rte_CDS_LrndRackCentr) / 2];
        }
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_HwAg(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Ip_HwAg;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_MotTqCmd(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Ip_MotTqCmd;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_MotTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnEna(void)
{
    extern __PST__UINT8 LrndRackCentr_Ip_PinionCentrLrnEna;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_PinionCentrLrnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnHwCentr(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Ip_PinionCentrLrnHwCentr;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_PinionCentrLrnHwCentr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnHwTrvl(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Ip_PinionCentrLrnHwTrvl;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_PinionCentrLrnHwTrvl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnSt(void)
{
    extern __PST__UINT8 LrndRackCentr_Ip_PinionCentrLrnSt;
    
    /* initialization with random value */
    {
        LrndRackCentr_Ip_PinionCentrLrnSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrAllwManIniLrng(void)
{
    extern __PST__g__35 LrndRackCentr_Cal_LrndRackCentrAllwManIniLrng;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrAllwManIniLrng = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrConfTrvlThd(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_LrndRackCentrConfTrvlThd;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrConfTrvlThd = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrHwAgFilFrq(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_LrndRackCentrHwAgFilFrq;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrHwAgFilFrq = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrMinMaxAdjmtFac(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_LrndRackCentrMinMaxAdjmtFac;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrMinMaxAdjmtFac = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrMotTqThd(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_LrndRackCentrMotTqThd;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrMotTqThd = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrMotVelThd(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_LrndRackCentrMotVelThd;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrMotVelThd = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrRackCentrPosnChgAllwd(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_LrndRackCentrRackCentrPosnChgAllwd;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrRackCentrPosnChgAllwd = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrTiThd(void)
{
    extern __PST__g__37 LrndRackCentr_Cal_LrndRackCentrTiThd;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_LrndRackCentrTiThd = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__36 LrndRackCentr_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        LrndRackCentr_Cal_SysGlbPrmSysKineRat = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_HwAgFil(void)
{
    extern struct __PST__g__30 LrndRackCentr_Pim_HwAgFil;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_HwAgFil = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrNegEot(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Pim_ManLrndRackCentrNegEot;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_ManLrndRackCentrNegEot = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrNegEotVld(void)
{
    extern __PST__UINT8 LrndRackCentr_Pim_ManLrndRackCentrNegEotVld;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_ManLrndRackCentrNegEotVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrPosEot(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Pim_ManLrndRackCentrPosEot;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_ManLrndRackCentrPosEot = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrPosEotVld(void)
{
    extern __PST__UINT8 LrndRackCentr_Pim_ManLrndRackCentrPosEotVld;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_ManLrndRackCentrPosEotVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_RackCentrMaxTmr(void)
{
    extern __PST__UINT32 LrndRackCentr_Pim_RackCentrMaxTmr;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_RackCentrMaxTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_RackCentrMinTmr(void)
{
    extern __PST__UINT32 LrndRackCentr_Pim_RackCentrMinTmr;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_RackCentrMinTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Pim_RackCentrPinionAgPrev(void)
{
    extern __PST__FLOAT32 LrndRackCentr_Pim_RackCentrPinionAgPrev;
    
    /* initialization with random value */
    {
        LrndRackCentr_Pim_RackCentrPinionAgPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 LrndRackCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        LrndRackCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrndRackCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 LrndRackCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        LrndRackCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_LrndRackCentr */
    _main_gen_init_sym_Rte_Inst_LrndRackCentr();
    
    /* init for variable LrndRackCentr_Ip_HwAg */
    _main_gen_init_sym_LrndRackCentr_Ip_HwAg();
    
    /* init for variable LrndRackCentr_Ip_MotTqCmd */
    _main_gen_init_sym_LrndRackCentr_Ip_MotTqCmd();
    
    /* init for variable LrndRackCentr_Ip_MotVelCrf */
    _main_gen_init_sym_LrndRackCentr_Ip_MotVelCrf();
    
    /* init for variable LrndRackCentr_Ip_PinionCentrLrnEna */
    _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnEna();
    
    /* init for variable LrndRackCentr_Ip_PinionCentrLrnHwCentr */
    _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnHwCentr();
    
    /* init for variable LrndRackCentr_Ip_PinionCentrLrnHwTrvl */
    _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnHwTrvl();
    
    /* init for variable LrndRackCentr_Ip_PinionCentrLrnSt */
    _main_gen_init_sym_LrndRackCentr_Ip_PinionCentrLrnSt();
    
    /* init for variable LrndRackCentr_Op_LongTermRackCentrCmpl : useless (never read) */

    /* init for variable LrndRackCentr_Op_RackCentrCmpl : useless (never read) */

    /* init for variable LrndRackCentr_Op_RackCentrMotAgErrPrsnt : useless (never read) */

    /* init for variable LrndRackCentr_Op_RackCentrMotAgVld : useless (never read) */

    /* init for variable LrndRackCentr_Op_RackCentrPinionAg : useless (never read) */

    /* init for variable LrndRackCentr_Op_TotRackTrvl : useless (never read) */

    /* init for variable LrndRackCentr_Cal_LrndRackCentrAllwManIniLrng */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrAllwManIniLrng();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrConfTrvlThd */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrConfTrvlThd();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrHwAgFilFrq */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrHwAgFilFrq();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrMinMaxAdjmtFac */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrMinMaxAdjmtFac();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrMotTqThd */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrMotTqThd();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrMotVelThd */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrMotVelThd();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrRackCentrPosnChgAllwd */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrRackCentrPosnChgAllwd();
    
    /* init for variable LrndRackCentr_Cal_LrndRackCentrTiThd */
    _main_gen_init_sym_LrndRackCentr_Cal_LrndRackCentrTiThd();
    
    /* init for variable LrndRackCentr_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_LrndRackCentr_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable LrndRackCentr_Pim_HwAgFil */
    _main_gen_init_sym_LrndRackCentr_Pim_HwAgFil();
    
    /* init for variable LrndRackCentr_Pim_ManLrndRackCentrNegEot */
    _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrNegEot();
    
    /* init for variable LrndRackCentr_Pim_ManLrndRackCentrNegEotVld */
    _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrNegEotVld();
    
    /* init for variable LrndRackCentr_Pim_ManLrndRackCentrPosEot */
    _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrPosEot();
    
    /* init for variable LrndRackCentr_Pim_ManLrndRackCentrPosEotVld */
    _main_gen_init_sym_LrndRackCentr_Pim_ManLrndRackCentrPosEotVld();
    
    /* init for variable LrndRackCentr_Pim_RackCentrMaxTmr */
    _main_gen_init_sym_LrndRackCentr_Pim_RackCentrMaxTmr();
    
    /* init for variable LrndRackCentr_Pim_RackCentrMinTmr */
    _main_gen_init_sym_LrndRackCentr_Pim_RackCentrMinTmr();
    
    /* init for variable LrndRackCentr_Pim_RackCentrPinionAgPrev */
    _main_gen_init_sym_LrndRackCentr_Pim_RackCentrPinionAgPrev();
    
    /* init for variable LrndRackCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_LrndRackCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable LrndRackCentr_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable LrndRackCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_LrndRackCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
