/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  LrndRackCentr.c
 *        Config:  C:/_Synergy_Projects/Working/SF039A_LrndRackCentr_Impl/tools/Component.dpa
 *     SW-C Type:  LrndRackCentr
 *  Generated at:  Tue Nov  7 18:31:39 2017
 *
 *     Generator:  MICROSAR RTE Generator Version 4.13.0
 *                 RTE Core Version 1.13.0
 *       License:  Unlimited license CBD1400351 for Nexteer Automotive Corporation
 *
 *   Description:  C-Code implementation template for SW-C <LrndRackCentr>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
/**********************************************************************************************************************
* Copyright 2017 Nexteer 
* Nexteer Confidential
*
* Module File Name  : LrndRackCentr.c
* Module Description: Implementation of Learned Rack Center FDD (SF039A)
* Project           : CBD 
* Author            : Matthew Leser
***********************************************************************************************************************
* Version Control:
* %version          : 1 %
* %derived_by       : nz2796 %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 09/01/17  1        ML       Initial Version                                                                 EA4#14383                                                               
**********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_LrndRackCentr.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "ArchGlbPrm.h"
#include "NxtrMath.h"
#include "NxtrFil.h"

/* MISRA-C:2004 Rule 16.10 [NXTRDEV 16.10.1]: There is no appropriate action to take on the return value Rte_Read, Rte_Write,
                                              SetRamBlockStatus, GetErrorStatus */ 
/* MISRA-C:2004 Rule 16.10 [NXTRDEV 16.10.2]: Server runnable is a void functon; Rte generation adds standard return type 
                                              but no error information is returned for GetTiSpan100MicroSec32bit and
                                              GetRefTmr100MicroSec32bit */
/* MISRA-C:2004 Rule 19.1 [NXTRDEV 19.1.1]: AUTOSAR requires deviation from this rule for Memory Mapping include statements */ 
 
#define AGFULLREV_MOTDEG_F32            (360.0F)
#define AGHALFREV_MOTDEG_F32            (180.0F)
#define AVGDEN_CNT_U08                  2U
#define LRNPINIONCENTRSTDONE_CNT_U08    6U 
#define MILLICNV100MICRO_ULS_U16        10U
#define RACKCENTRPINIONAGMAX_HWDEG_F32  (1440.0F) 
#define RACKCENTRPINIONAGMIN_HWDEG_F32  (-1440.0F) 
#define TOTRACKTRVLMAX_HWDEG_F32        (2880.0F)
#define TOTRACKTRVLMIN_HWDEG_F32        (-2880.0F)
 
static FUNC(void, GMOVRLSTMGR_CODE) ManLrnRackCentr(VAR(float32, AUTOMATIC) HwAg_HwDeg_T_f32,
                                                    VAR(float32, AUTOMATIC) MotVelCrf_MotRadPerSec_T_f32,
                                                    VAR(float32, AUTOMATIC) MotTqCmd_MotNwtMtr_T_f32);
                                                    
static FUNC(void, GMOVRLSTMGR_CODE) ChkRackCentr(VAR(boolean, AUTOMATIC) ManIniLrng_Cnt_T_logl,
                                                 VAR(float32, AUTOMATIC) HwTrvl_HwDeg_T_f32,
                                                 VAR(float32, AUTOMATIC) RackCentr_HwDeg_T_f32,
                                                 P2VAR(boolean, AUTOMATIC, LrndRackCentr_VAR) RackCentrMotAgVld_Cnt_T_logl,
                                                 P2VAR(boolean, AUTOMATIC, LrndRackCentr_VAR) RackCentrCmpl_Cnt_T_logl);

                                                 
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * Boolean: Boolean
 * boolean: Boolean (standard type)
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * NvM_RequestResultType: Enumeration of integer in interval [0...255] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Record Types:
 * =============
 * FilLpRec1: Record with elements
 *   FilSt of type float32
 *   FilGain of type float32
 * LrndRackCentrNvmRec1: Record with elements
 *   TotRackTrvl of type float32
 *   RackCentrMotDeg of type float32
 *   RackCentrMotRev of type sint16
 *   LongTermRackCentrCmpl of type boolean
 *   MotAgVld of type boolean
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   float32 *Rte_Pim_ManLrndRackCentrNegEot(void)
 *   float32 *Rte_Pim_ManLrndRackCentrPosEot(void)
 *   float32 *Rte_Pim_RackCentrPinionAgPrev(void)
 *   uint32 *Rte_Pim_RackCentrMaxTmr(void)
 *   uint32 *Rte_Pim_RackCentrMinTmr(void)
 *   boolean *Rte_Pim_ManLrndRackCentrNegEotVld(void)
 *   boolean *Rte_Pim_ManLrndRackCentrPosEotVld(void)
 *   FilLpRec1 *Rte_Pim_HwAgFil(void)
 *   LrndRackCentrNvmRec1 *Rte_Pim_LrndRackCentr(void)
 *
 * Calibration Parameters:
 * =======================
 *   Calibration Component Calibration Parameters:
 *   ---------------------------------------------
 *   float32 Rte_Prm_LrndRackCentrConfTrvlThd_Val(void)
 *   float32 Rte_Prm_LrndRackCentrHwAgFilFrq_Val(void)
 *   float32 Rte_Prm_LrndRackCentrMinMaxAdjmtFac_Val(void)
 *   float32 Rte_Prm_LrndRackCentrMotTqThd_Val(void)
 *   float32 Rte_Prm_LrndRackCentrMotVelThd_Val(void)
 *   float32 Rte_Prm_LrndRackCentrRackCentrPosnChgAllwd_Val(void)
 *   float32 Rte_Prm_SysGlbPrmSysKineRat_Val(void)
 *   uint16 Rte_Prm_LrndRackCentrTiThd_Val(void)
 *   boolean Rte_Prm_LrndRackCentrAllwManIniLrng_Logl(void)
 *
 *********************************************************************************************************************/


#define LrndRackCentr_START_SEC_CODE
#include "LrndRackCentr_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: LrndRackCentrInit1
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_HwAg_Val(float32 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_LongTermRackCentrCmpl_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrCmpl_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrMotAgErrPrsnt_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrMotAgVld_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrPinionAg_Val(float32 data)
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_LrndRackCentrNvm_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: LrndRackCentrInit1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, LrndRackCentr_CODE) LrndRackCentrInit1(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: LrndRackCentrInit1
 *********************************************************************************************************************/

    VAR(NvM_RequestResultType, AUTOMATIC) LrndRackCentrErrSts_Cnt_T_enum;
    VAR(float32, AUTOMATIC) RackCentrPinionAg_HwDeg_T_f32;
    VAR(float32, AUTOMATIC) HwAg_HwDeg_T_f32;
    VAR(uint32, AUTOMATIC)  Tmr_Cnt_T_u32;
    
    (void)Rte_Read_HwAg_Val(&HwAg_HwDeg_T_f32);
    (void)Rte_Call_LrndRackCentrNvm_GetErrorStatus(&LrndRackCentrErrSts_Cnt_T_enum);
    
    if(LrndRackCentrErrSts_Cnt_T_enum != NVM_REQ_OK)
    {
        (void)Rte_Write_RackCentrMotAgVld_Logl(FALSE);
        (void)Rte_Write_RackCentrMotAgErrPrsnt_Logl(TRUE);
        
        Rte_Pim_LrndRackCentr()->TotRackTrvl = 0.0F;
        Rte_Pim_LrndRackCentr()->RackCentrMotDeg = 0.0F;
        Rte_Pim_LrndRackCentr()->RackCentrMotRev = 0;
        Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl = FALSE;
        Rte_Pim_LrndRackCentr()->MotAgVld = FALSE;
    }
    else
    {
        (void)Rte_Write_RackCentrMotAgVld_Logl(Rte_Pim_LrndRackCentr()->MotAgVld);
        (void)Rte_Write_RackCentrMotAgErrPrsnt_Logl(FALSE);
    }
    
    FilLpInit(0.0F, Rte_Prm_LrndRackCentrHwAgFilFrq_Val(), ARCHGLBPRM_2MILLISEC_SEC_F32, Rte_Pim_HwAgFil());
    RackCentrPinionAg_HwDeg_T_f32 = (((float32)Rte_Pim_LrndRackCentr()->RackCentrMotRev * AGFULLREV_MOTDEG_F32) + Rte_Pim_LrndRackCentr()->RackCentrMotDeg) /
                                      Rte_Prm_SysGlbPrmSysKineRat_Val();
    (void)Rte_Write_LongTermRackCentrCmpl_Logl(FALSE);
    (void)Rte_Write_RackCentrCmpl_Logl(FALSE);
    
    *Rte_Pim_ManLrndRackCentrPosEotVld() = FALSE;
    *Rte_Pim_ManLrndRackCentrNegEotVld() = FALSE;
    *Rte_Pim_ManLrndRackCentrPosEot() = HwAg_HwDeg_T_f32;
    *Rte_Pim_ManLrndRackCentrNegEot() = HwAg_HwDeg_T_f32;
    
    (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(&Tmr_Cnt_T_u32);
    
    *Rte_Pim_RackCentrMinTmr() = Tmr_Cnt_T_u32;
    *Rte_Pim_RackCentrMaxTmr() = Tmr_Cnt_T_u32;
    
    (void)Rte_Write_RackCentrPinionAg_Val(Lim_f32(RackCentrPinionAg_HwDeg_T_f32, RACKCENTRPINIONAGMIN_HWDEG_F32, RACKCENTRPINIONAGMAX_HWDEG_F32));
 
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: LrndRackCentrPer1
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 4ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_HwAg_Val(float32 *data)
 *   Std_ReturnType Rte_Read_MotTqCmd_Val(float32 *data)
 *   Std_ReturnType Rte_Read_MotVelCrf_Val(float32 *data)
 *   Std_ReturnType Rte_Read_PinionCentrLrnEna_Logl(boolean *data)
 *   Std_ReturnType Rte_Read_PinionCentrLrnHwCentr_Val(float32 *data)
 *   Std_ReturnType Rte_Read_PinionCentrLrnHwTrvl_Val(float32 *data)
 *   Std_ReturnType Rte_Read_PinionCentrLrnSt_Val(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_LongTermRackCentrCmpl_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrCmpl_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrMotAgVld_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrPinionAg_Val(float32 data)
 *   Std_ReturnType Rte_Write_TotRackTrvl_Val(float32 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_GetRefTmr100MicroSec32bit_Oper(uint32 *RefTmr_Arg)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_GetTiSpan100MicroSec32bit_Oper(uint32 RefTmr_Arg, uint32 *TiSpan_Arg)
 *     Synchronous Server Invocation. Timeout: None
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(Boolean RamBlockStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: LrndRackCentrPer1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, LrndRackCentr_CODE) LrndRackCentrPer1(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: LrndRackCentrPer1
 *********************************************************************************************************************/

    /*** Inputs ***/
    VAR(float32, AUTOMATIC) HwAg_HwDeg_T_f32;
    VAR(float32, AUTOMATIC) MotTqCmd_MotNwtMtr_T_f32;
    VAR(float32, AUTOMATIC) MotVelCrf_MotRadPerSec_T_f32;
    VAR(float32, AUTOMATIC) PinionCentrLrnHwCentr_HwDeg_T_f32;
    VAR(float32, AUTOMATIC) PinionCentrLrnHwTrvl_HwDeg_T_f32;
    VAR(boolean, AUTOMATIC) PinionCentrLrnEna_Cnt_T_logl;
    VAR(uint8,   AUTOMATIC) PinionCentrLrnSt_Cnt_T_u08;
    
    /*** Outputs ***/
    VAR(boolean, AUTOMATIC) LongTermRackCentrCmpl_Cnt_T_logl;
    VAR(boolean, AUTOMATIC) RackCentrCmpl_Cnt_T_logl;
    VAR(boolean, AUTOMATIC) RackCentrMotAgVld_Cnt_T_logl;
    VAR(float32, AUTOMATIC) RackCentrPinionAg_HwDeg_T_f32;
    VAR(float32, AUTOMATIC) TotRackTrvl_HwDeg_T_f32;
    
    /*** Temporary Variables ***/
    VAR(float32, AUTOMATIC) ManLrndTotRackTrvl_HwDeg_T_f32;
    VAR(float32, AUTOMATIC) ManLrndRackCentr_HwDeg_T_f32;
    
    (void)Rte_Read_HwAg_Val(&HwAg_HwDeg_T_f32);
    (void)Rte_Read_MotTqCmd_Val(&MotTqCmd_MotNwtMtr_T_f32);
    (void)Rte_Read_MotVelCrf_Val(&MotVelCrf_MotRadPerSec_T_f32);
    (void)Rte_Read_PinionCentrLrnHwCentr_Val(&PinionCentrLrnHwCentr_HwDeg_T_f32);
    (void)Rte_Read_PinionCentrLrnHwTrvl_Val(&PinionCentrLrnHwTrvl_HwDeg_T_f32);
    (void)Rte_Read_PinionCentrLrnEna_Logl(&PinionCentrLrnEna_Cnt_T_logl);
    (void)Rte_Read_PinionCentrLrnSt_Val(&PinionCentrLrnSt_Cnt_T_u08);
    
    if(Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl == FALSE)
    {
        /*** MANUAL LEARN RACK CENTER ***/
        ManLrnRackCentr(HwAg_HwDeg_T_f32,
                        MotVelCrf_MotRadPerSec_T_f32,
                        MotTqCmd_MotNwtMtr_T_f32);
                        
        ManLrndTotRackTrvl_HwDeg_T_f32 = *Rte_Pim_ManLrndRackCentrPosEot() - *Rte_Pim_ManLrndRackCentrNegEot();
        ManLrndRackCentr_HwDeg_T_f32 = (*Rte_Pim_ManLrndRackCentrPosEot() + *Rte_Pim_ManLrndRackCentrNegEot()) /
                                        (float32)AVGDEN_CNT_U08;
    
        /*** CHECK RACK CENTER FOUND ***/
                    
        if((PinionCentrLrnSt_Cnt_T_u08 == LRNPINIONCENTRSTDONE_CNT_U08) && 
           (PinionCentrLrnHwTrvl_HwDeg_T_f32 >= Rte_Prm_LrndRackCentrConfTrvlThd_Val()))
        {
            ChkRackCentr(TRUE,
                         PinionCentrLrnHwTrvl_HwDeg_T_f32,
                         PinionCentrLrnHwCentr_HwDeg_T_f32,
                         &RackCentrMotAgVld_Cnt_T_logl,
                         &RackCentrCmpl_Cnt_T_logl);
        }
        else if(((PinionCentrLrnEna_Cnt_T_logl == FALSE) && (*Rte_Pim_ManLrndRackCentrNegEotVld() == TRUE) && (*Rte_Pim_ManLrndRackCentrPosEotVld() == TRUE)) &&
                (ManLrndTotRackTrvl_HwDeg_T_f32 >= Rte_Prm_LrndRackCentrConfTrvlThd_Val()))
        {
            ChkRackCentr(Rte_Prm_LrndRackCentrAllwManIniLrng_Logl(),
                         ManLrndTotRackTrvl_HwDeg_T_f32,
                         ManLrndRackCentr_HwDeg_T_f32,
                         &RackCentrMotAgVld_Cnt_T_logl,
                         &RackCentrCmpl_Cnt_T_logl);        
        }
        else
        {
            RackCentrMotAgVld_Cnt_T_logl = Rte_Pim_LrndRackCentr()->MotAgVld;
            RackCentrCmpl_Cnt_T_logl = Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl;
        }
        
        RackCentrPinionAg_HwDeg_T_f32 = *Rte_Pim_RackCentrPinionAgPrev();
        LongTermRackCentrCmpl_Cnt_T_logl = Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl;
                        
    }
    else
    {
        RackCentrMotAgVld_Cnt_T_logl = Rte_Pim_LrndRackCentr()->MotAgVld;
        RackCentrPinionAg_HwDeg_T_f32 = *Rte_Pim_RackCentrPinionAgPrev();
        RackCentrCmpl_Cnt_T_logl = Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl;
        LongTermRackCentrCmpl_Cnt_T_logl = Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl;
    }
    
    TotRackTrvl_HwDeg_T_f32 = Lim_f32(Rte_Pim_LrndRackCentr()->TotRackTrvl, TOTRACKTRVLMIN_HWDEG_F32, TOTRACKTRVLMAX_HWDEG_F32);
 
    (void)Rte_Write_RackCentrMotAgVld_Logl(RackCentrMotAgVld_Cnt_T_logl);
    (void)Rte_Write_RackCentrPinionAg_Val(Lim_f32(RackCentrPinionAg_HwDeg_T_f32, RACKCENTRPINIONAGMIN_HWDEG_F32, RACKCENTRPINIONAGMAX_HWDEG_F32));
    (void)Rte_Write_RackCentrCmpl_Logl(RackCentrCmpl_Cnt_T_logl);
    (void)Rte_Write_LongTermRackCentrCmpl_Logl(LongTermRackCentrCmpl_Cnt_T_logl);
    (void)Rte_Write_TotRackTrvl_Val(TotRackTrvl_HwDeg_T_f32);
 
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: RstRackCentrMotAg_Oper
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Oper> of PortPrototype <RstRackCentrMotAg>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_RackCentrMotAgVld_Logl(boolean data)
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(Boolean RamBlockStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void RstRackCentrMotAg_Oper(void)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: RstRackCentrMotAg_Oper_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, LrndRackCentr_CODE) RstRackCentrMotAg_Oper(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: RstRackCentrMotAg_Oper
 *********************************************************************************************************************/
 
 Rte_Pim_LrndRackCentr()->MotAgVld = FALSE;
 Rte_Pim_LrndRackCentr()->TotRackTrvl = 0.0F;
 Rte_Pim_LrndRackCentr()->RackCentrMotDeg = 0.0F;
 
 (void)Rte_Write_RackCentrMotAgVld_Logl(FALSE);
 
 (void)Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(TRUE);

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: RstRackCentrMotRev_Oper
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Oper> of PortPrototype <RstRackCentrMotRev>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_HwAg_Val(float32 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_LongTermRackCentrCmpl_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrCmpl_Logl(boolean data)
 *   Std_ReturnType Rte_Write_RackCentrPinionAg_Val(float32 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_GetRefTmr100MicroSec32bit_Oper(uint32 *RefTmr_Arg)
 *     Synchronous Server Invocation. Timeout: None
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(Boolean RamBlockStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void RstRackCentrMotRev_Oper(void)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: RstRackCentrMotRev_Oper_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, LrndRackCentr_CODE) RstRackCentrMotRev_Oper(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: RstRackCentrMotRev_Oper
 *********************************************************************************************************************/

    VAR(float32, AUTOMATIC) HwAg_HwDeg_T_f32;
    VAR(uint32, AUTOMATIC) Tmr_Cnt_T_u32;
    
    (void)Rte_Read_HwAg_Val(&HwAg_HwDeg_T_f32);
    
    (void)Rte_Write_RackCentrCmpl_Logl(FALSE);
    (void)Rte_Write_LongTermRackCentrCmpl_Logl(FALSE);
    (void)Rte_Write_RackCentrPinionAg_Val(0.0F);
    
    *Rte_Pim_ManLrndRackCentrPosEot() = HwAg_HwDeg_T_f32;
    *Rte_Pim_ManLrndRackCentrNegEot() = HwAg_HwDeg_T_f32;
    *Rte_Pim_ManLrndRackCentrPosEotVld() = FALSE;
    *Rte_Pim_ManLrndRackCentrNegEotVld() = FALSE;
    
    (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(&Tmr_Cnt_T_u32);
    *Rte_Pim_RackCentrMinTmr() = Tmr_Cnt_T_u32;
    *Rte_Pim_RackCentrMaxTmr() = Tmr_Cnt_T_u32;
        
    Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl = FALSE;
    Rte_Pim_LrndRackCentr()->RackCentrMotRev = 0;
    
    (void)Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(TRUE);

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define LrndRackCentr_STOP_SEC_CODE
#include "LrndRackCentr_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
/*******************************************************************************
* Name          :   ManLrnRackCentr
* Description   :   Implementation of MANUAL LEARN RACK CENTER
* Inputs        :   HwAg_HwDeg_T_f32 - RTE Input
*                   MotVelCrf_MotRadPerSec_T_f32 - RTE Input
*                   MotTqCmd_MotNwtMtr_T_f32 - RTE Input
* Outputs       :   None
* Usage Notes   :   None
*****************************************************************************/
static FUNC(void, GMOVRLSTMGR_CODE) ManLrnRackCentr(VAR(float32, AUTOMATIC) HwAg_HwDeg_T_f32,
                                                    VAR(float32, AUTOMATIC) MotVelCrf_MotRadPerSec_T_f32,
                                                    VAR(float32, AUTOMATIC) MotTqCmd_MotNwtMtr_T_f32)
{  
    VAR(uint32, AUTOMATIC) SpanTi_Cnt_T_u32;
    VAR(float32, AUTOMATIC) HwAgFild_HwDeg_T_f32;
    VAR(uint32, AUTOMATIC) Tmr_Cnt_T_u32;
                                        
    HwAgFild_HwDeg_T_f32 = FilLpUpdOutp_f32(HwAg_HwDeg_T_f32,Rte_Pim_HwAgFil());
    
    if(Abslt_f32_f32(MotVelCrf_MotRadPerSec_T_f32) > Rte_Prm_LrndRackCentrMotVelThd_Val())
    {
        (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(&Tmr_Cnt_T_u32);
        *Rte_Pim_RackCentrMinTmr() = Tmr_Cnt_T_u32;
        *Rte_Pim_RackCentrMaxTmr() = Tmr_Cnt_T_u32;
        
    }
    else if(HwAg_HwDeg_T_f32 < (*Rte_Pim_ManLrndRackCentrNegEot() - Rte_Prm_LrndRackCentrRackCentrPosnChgAllwd_Val()))
    {
        *Rte_Pim_ManLrndRackCentrNegEot() = Blnd_f32(*Rte_Pim_ManLrndRackCentrNegEot(), HwAg_HwDeg_T_f32, Rte_Prm_LrndRackCentrMinMaxAdjmtFac_Val());
        *Rte_Pim_ManLrndRackCentrNegEotVld() = FALSE;
        (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(&Tmr_Cnt_T_u32);
        *Rte_Pim_RackCentrMinTmr() = Tmr_Cnt_T_u32;
        *Rte_Pim_RackCentrMaxTmr() = Tmr_Cnt_T_u32;    
    }
    else if(HwAg_HwDeg_T_f32 > (*Rte_Pim_ManLrndRackCentrPosEot() + Rte_Prm_LrndRackCentrRackCentrPosnChgAllwd_Val()))
    {
        *Rte_Pim_ManLrndRackCentrPosEot() = Blnd_f32(*Rte_Pim_ManLrndRackCentrPosEot(), HwAg_HwDeg_T_f32, Rte_Prm_LrndRackCentrMinMaxAdjmtFac_Val());
        *Rte_Pim_ManLrndRackCentrPosEotVld() = FALSE;
        (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(&Tmr_Cnt_T_u32);
        *Rte_Pim_RackCentrMinTmr() = Tmr_Cnt_T_u32;
        *Rte_Pim_RackCentrMaxTmr() = Tmr_Cnt_T_u32;
    }
    else if(MotTqCmd_MotNwtMtr_T_f32 <= -Rte_Prm_LrndRackCentrMotTqThd_Val())
    {
        (void)Rte_Call_GetTiSpan100MicroSec32bit_Oper(*Rte_Pim_RackCentrMinTmr(), &SpanTi_Cnt_T_u32);
        if(SpanTi_Cnt_T_u32 > ((uint32)Rte_Prm_LrndRackCentrTiThd_Val() * (uint32)MILLICNV100MICRO_ULS_U16))
        {
            *Rte_Pim_ManLrndRackCentrNegEotVld() = TRUE;
        }
        
        *Rte_Pim_ManLrndRackCentrNegEot() = Min_f32(HwAgFild_HwDeg_T_f32, *Rte_Pim_ManLrndRackCentrNegEot());
        (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(Rte_Pim_RackCentrMaxTmr());
    }
    else if(MotTqCmd_MotNwtMtr_T_f32 >= Rte_Prm_LrndRackCentrMotTqThd_Val())
    {
        (void)Rte_Call_GetTiSpan100MicroSec32bit_Oper(*Rte_Pim_RackCentrMaxTmr(), &SpanTi_Cnt_T_u32);
        if(SpanTi_Cnt_T_u32 > ((uint32)Rte_Prm_LrndRackCentrTiThd_Val() * (uint32)MILLICNV100MICRO_ULS_U16))
        {
            *Rte_Pim_ManLrndRackCentrPosEotVld() = TRUE;
        }
        
        *Rte_Pim_ManLrndRackCentrPosEot() = Max_f32(HwAgFild_HwDeg_T_f32, *Rte_Pim_ManLrndRackCentrPosEot());
        (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(Rte_Pim_RackCentrMinTmr());
    }
    else
    {
        (void)Rte_Call_GetRefTmr100MicroSec32bit_Oper(&Tmr_Cnt_T_u32);
        *Rte_Pim_RackCentrMinTmr() = Tmr_Cnt_T_u32;
        *Rte_Pim_RackCentrMaxTmr() = Tmr_Cnt_T_u32;
    }
    
}

/*******************************************************************************
* Name          :   ChkRackCentr
* Description   :   Implementation of Confirm Rack Center Found
* Inputs        :   HwTrvl_HwDeg_T_f32 - RTE Input
*                   RackCentr_HwDeg_T_f32 - RTE Input
*                   *RackCentrMotAgVld_Cnt_T_logl - RTE Output
*                   *RackCentrCmpl_Cnt_T_logl - RTE Output
* Outputs       :   None
* Usage Notes   :   None
*****************************************************************************/
static FUNC(void, GMOVRLSTMGR_CODE) ChkRackCentr(VAR(boolean, AUTOMATIC) ManIniLrng_Cnt_T_logl,
                                                 VAR(float32, AUTOMATIC) HwTrvl_HwDeg_T_f32,
                                                 VAR(float32, AUTOMATIC) RackCentr_HwDeg_T_f32,
                                                 P2VAR(boolean, AUTOMATIC, LrndRackCentr_VAR) RackCentrMotAgVld_Cnt_T_logl,
                                                 P2VAR(boolean, AUTOMATIC, LrndRackCentr_VAR) RackCentrCmpl_Cnt_T_logl)
{
    VAR(float32, AUTOMATIC) TotMotRev_Uls_T_f32;
    VAR(sint16, AUTOMATIC) TotMotRevAdj_Uls_T_s16;
    VAR(float32, AUTOMATIC) RackCentrMotDeg_MotDeg_T_f32;
    

    
    TotMotRev_Uls_T_f32 = (RackCentr_HwDeg_T_f32 * Rte_Prm_SysGlbPrmSysKineRat_Val()) / AGFULLREV_MOTDEG_F32;
    
    /* This logic is done to impement Floor Function without having to add function to AR100A */
    TotMotRevAdj_Uls_T_s16 = (sint16)TotMotRev_Uls_T_f32;
    
    if(TotMotRev_Uls_T_f32 < 0.0f)
    {
        TotMotRevAdj_Uls_T_s16 = TotMotRevAdj_Uls_T_s16 - 1;
    }
    
    RackCentrMotDeg_MotDeg_T_f32 = AGFULLREV_MOTDEG_F32 * (TotMotRev_Uls_T_f32 - (float32)TotMotRevAdj_Uls_T_s16);
    
    if((Rte_Pim_LrndRackCentr()->MotAgVld == FALSE) && (ManIniLrng_Cnt_T_logl == TRUE))
    {
        *RackCentrMotAgVld_Cnt_T_logl = TRUE;
        *Rte_Pim_RackCentrPinionAgPrev() = (((float32)TotMotRevAdj_Uls_T_s16 * AGFULLREV_MOTDEG_F32) + RackCentrMotDeg_MotDeg_T_f32) /
                                           Rte_Prm_SysGlbPrmSysKineRat_Val();
        *RackCentrCmpl_Cnt_T_logl = TRUE;
        Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl = TRUE;
        Rte_Pim_LrndRackCentr()->TotRackTrvl = HwTrvl_HwDeg_T_f32;
        Rte_Pim_LrndRackCentr()->RackCentrMotDeg = RackCentrMotDeg_MotDeg_T_f32;
        Rte_Pim_LrndRackCentr()->MotAgVld = TRUE;
        Rte_Pim_LrndRackCentr()->RackCentrMotRev = TotMotRevAdj_Uls_T_s16;
        (void)Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(TRUE);
    }
    else if(Abslt_f32_f32(HwTrvl_HwDeg_T_f32 - Rte_Pim_LrndRackCentr()->TotRackTrvl) < (AGFULLREV_MOTDEG_F32 / Rte_Prm_SysGlbPrmSysKineRat_Val()))
    {
        if(RackCentrMotDeg_MotDeg_T_f32 < (Rte_Pim_LrndRackCentr()->RackCentrMotDeg - AGHALFREV_MOTDEG_F32))
        {
            TotMotRevAdj_Uls_T_s16 -= 1;  
        }
        else if(RackCentrMotDeg_MotDeg_T_f32 > (Rte_Pim_LrndRackCentr()->RackCentrMotDeg + AGHALFREV_MOTDEG_F32))
        {
            TotMotRevAdj_Uls_T_s16 += 1;
        }
        else
        {
            /* Pass on value of TotMotRevAdj_Uls_T_s16 */
        }
        
        RackCentrMotDeg_MotDeg_T_f32 = Rte_Pim_LrndRackCentr()->RackCentrMotDeg;
        
        *Rte_Pim_RackCentrPinionAgPrev() = (((float32)TotMotRevAdj_Uls_T_s16 * AGFULLREV_MOTDEG_F32) + RackCentrMotDeg_MotDeg_T_f32) /
                                           Rte_Prm_SysGlbPrmSysKineRat_Val();
        *RackCentrCmpl_Cnt_T_logl = TRUE;
        *RackCentrMotAgVld_Cnt_T_logl = TRUE;
        Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl = TRUE;
        Rte_Pim_LrndRackCentr()->RackCentrMotRev = TotMotRevAdj_Uls_T_s16;
        (void)Rte_Call_LrndRackCentrNvm_SetRamBlockStatus(TRUE);
    }
    else
    {
        *RackCentrMotAgVld_Cnt_T_logl = Rte_Pim_LrndRackCentr()->MotAgVld;
        *RackCentrCmpl_Cnt_T_logl = Rte_Pim_LrndRackCentr()->LongTermRackCentrCmpl;
        *Rte_Pim_RackCentrPinionAgPrev() = (((float32)TotMotRevAdj_Uls_T_s16 * AGFULLREV_MOTDEG_F32) + RackCentrMotDeg_MotDeg_T_f32) /
                                           Rte_Prm_SysGlbPrmSysKineRat_Val();           
    }
}


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
