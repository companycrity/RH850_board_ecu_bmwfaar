#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__23 _main_gen_init_g23(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_McuDiagc_Ip_FastLoopCntr(void)
{
    extern __PST__UINT16 McuDiagc_Ip_FastLoopCntr;
    
    /* initialization with random value */
    {
        McuDiagc_Ip_FastLoopCntr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Ip_SlowLoopCntr(void)
{
    extern __PST__UINT16 McuDiagc_Ip_SlowLoopCntr;
    
    /* initialization with random value */
    {
        McuDiagc_Ip_SlowLoopCntr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Ip_SysSt(void)
{
    extern __PST__UINT8 McuDiagc_Ip_SysSt;
    
    /* initialization with random value */
    {
        McuDiagc_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_McuDiagc_Cal_McuDiagc2MilliSecCntrCompThd(void)
{
    extern __PST__g__23 McuDiagc_Cal_McuDiagc2MilliSecCntrCompThd;
    
    /* initialization with random value */
    {
        McuDiagc_Cal_McuDiagc2MilliSecCntrCompThd = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_McuDiagc_Cal_McuDiagcFltFailStep(void)
{
    extern __PST__g__23 McuDiagc_Cal_McuDiagcFltFailStep;
    
    /* initialization with random value */
    {
        McuDiagc_Cal_McuDiagcFltFailStep = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_McuDiagc_Cal_McuDiagcFltPassStep(void)
{
    extern __PST__g__23 McuDiagc_Cal_McuDiagcFltPassStep;
    
    /* initialization with random value */
    {
        McuDiagc_Cal_McuDiagcFltPassStep = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_dMcuDiagcFastLoopCntrMax(void)
{
    extern __PST__UINT16 McuDiagc_Pim_dMcuDiagcFastLoopCntrMax;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_dMcuDiagcFastLoopCntrMax = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_dMcuDiagcFastLoopCntrMin(void)
{
    extern __PST__UINT16 McuDiagc_Pim_dMcuDiagcFastLoopCntrMin;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_dMcuDiagcFastLoopCntrMin = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_dMcuDiagcLoopCntr2MilliSecMotCtrlDif(void)
{
    extern __PST__UINT16 McuDiagc_Pim_dMcuDiagcLoopCntr2MilliSecMotCtrlDif;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_dMcuDiagcLoopCntr2MilliSecMotCtrlDif = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_FastLoopCntrDiagcCfgd(void)
{
    extern __PST__UINT8 McuDiagc_Pim_FastLoopCntrDiagcCfgd;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_FastLoopCntrDiagcCfgd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_LoopCntr2MilliSecStore(void)
{
    extern __PST__UINT16 McuDiagc_Pim_LoopCntr2MilliSecStore;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_LoopCntr2MilliSecStore = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_LoopCntrPrev(void)
{
    extern __PST__UINT16 McuDiagc_Pim_LoopCntrPrev;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_LoopCntrPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Pim_FastLoopCntrPrev(void)
{
    extern __PST__UINT16 McuDiagc_Pim_FastLoopCntrPrev;
    
    /* initialization with random value */
    {
        McuDiagc_Pim_FastLoopCntrPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlLoopCntr2MilliSec(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlLoopCntr2MilliSec;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlLoopCntr2MilliSec = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_McuDiagc_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 McuDiagc_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        McuDiagc_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable McuDiagc_Ip_FastLoopCntr */
    _main_gen_init_sym_McuDiagc_Ip_FastLoopCntr();
    
    /* init for variable McuDiagc_Ip_SlowLoopCntr */
    _main_gen_init_sym_McuDiagc_Ip_SlowLoopCntr();
    
    /* init for variable McuDiagc_Ip_SysSt */
    _main_gen_init_sym_McuDiagc_Ip_SysSt();
    
    /* init for variable McuDiagc_Op_LoopCntr2MilliSec : useless (never read) */

    /* init for variable McuDiagc_Cal_McuDiagc2MilliSecCntrCompThd */
    _main_gen_init_sym_McuDiagc_Cal_McuDiagc2MilliSecCntrCompThd();
    
    /* init for variable McuDiagc_Cal_McuDiagcFltFailStep */
    _main_gen_init_sym_McuDiagc_Cal_McuDiagcFltFailStep();
    
    /* init for variable McuDiagc_Cal_McuDiagcFltPassStep */
    _main_gen_init_sym_McuDiagc_Cal_McuDiagcFltPassStep();
    
    /* init for variable McuDiagc_Pim_dMcuDiagcFastLoopCntrMax */
    _main_gen_init_sym_McuDiagc_Pim_dMcuDiagcFastLoopCntrMax();
    
    /* init for variable McuDiagc_Pim_dMcuDiagcFastLoopCntrMin */
    _main_gen_init_sym_McuDiagc_Pim_dMcuDiagcFastLoopCntrMin();
    
    /* init for variable McuDiagc_Pim_dMcuDiagcLoopCntr2MilliSecMotCtrlDif */
    _main_gen_init_sym_McuDiagc_Pim_dMcuDiagcLoopCntr2MilliSecMotCtrlDif();
    
    /* init for variable McuDiagc_Pim_FastLoopCntrDiagcCfgd */
    _main_gen_init_sym_McuDiagc_Pim_FastLoopCntrDiagcCfgd();
    
    /* init for variable McuDiagc_Pim_LoopCntr2MilliSecStore */
    _main_gen_init_sym_McuDiagc_Pim_LoopCntr2MilliSecStore();
    
    /* init for variable McuDiagc_Pim_LoopCntrPrev */
    _main_gen_init_sym_McuDiagc_Pim_LoopCntrPrev();
    
    /* init for variable McuDiagc_Pim_FastLoopCntrPrev */
    _main_gen_init_sym_McuDiagc_Pim_FastLoopCntrPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlFastLoopCntr : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlLoopCntr2MilliSec */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlLoopCntr2MilliSec();
    
    /* init for variable MOTCTRLMGR_MotCtrlSlowLoopCntr : useless (never read) */

    /* init for variable McuDiagc_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable McuDiagc_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable McuDiagc_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable McuDiagc_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable McuDiagc_Srv_SetNtcSts_Return */
    _main_gen_init_sym_McuDiagc_Srv_SetNtcSts_Return();
    
}
