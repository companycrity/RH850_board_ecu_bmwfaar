#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__188 _main_gen_init_g188(void);

extern struct __PST__g__186 _main_gen_init_g186(void);

extern union __PST__g__184 _main_gen_init_g184(void);

extern struct __PST__g__182 _main_gen_init_g182(void);

extern union __PST__g__180 _main_gen_init_g180(void);

extern struct __PST__g__177 _main_gen_init_g177(void);

extern union __PST__g__176 _main_gen_init_g176(void);

extern __PST__g__160 _main_gen_init_g160(void);

extern union __PST__g__150 _main_gen_init_g150(void);

extern union __PST__g__137 _main_gen_init_g137(void);

extern __PST__g__135 _main_gen_init_g135(void);

extern union __PST__g__125 _main_gen_init_g125(void);

extern union __PST__g__108 _main_gen_init_g108(void);

extern __PST__g__99 _main_gen_init_g99(void);

extern union __PST__g__70 _main_gen_init_g70(void);

extern union __PST__g__68 _main_gen_init_g68(void);

extern __PST__g__47 _main_gen_init_g47(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__34 _main_gen_init_g34(void)
{
    static union __PST__g__34 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g34();
    return x;
}

union __PST__g__68 _main_gen_init_g68(void)
{
    static union __PST__g__68 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__70 _main_gen_init_g70(void)
{
    static union __PST__g__70 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__47 _main_gen_init_g47(void)
{
    __PST__g__47 x;
    /* struct/union type */
    x.ESSTC0 = _main_gen_init_g68();
    x.ESSTC1 = _main_gen_init_g70();
    return x;
}

union __PST__g__108 _main_gen_init_g108(void)
{
    static union __PST__g__108 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__125 _main_gen_init_g125(void)
{
    static union __PST__g__125 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__99 _main_gen_init_g99(void)
{
    __PST__g__99 x;
    /* struct/union type */
    x.IDSTCLR_PE1 = _main_gen_init_g108();
    x.ITSTCLR_PE1 = _main_gen_init_g125();
    return x;
}

union __PST__g__137 _main_gen_init_g137(void)
{
    static union __PST__g__137 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__150 _main_gen_init_g150(void)
{
    static union __PST__g__150 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__135 _main_gen_init_g135(void)
{
    __PST__g__135 x;
    /* struct/union type */
    x.CTL = _main_gen_init_g137();
    x.EAD0 = _main_gen_init_g150();
    return x;
}

struct __PST__g__177 _main_gen_init_g177(void)
{
    static struct __PST__g__177 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.STCLR3 = bitf;
    }
    return x;
}

union __PST__g__176 _main_gen_init_g176(void)
{
    static union __PST__g__176 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g177();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__182 _main_gen_init_g182(void)
{
    static struct __PST__g__182 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ERROVF3 = bitf;
    }
    return x;
}

union __PST__g__180 _main_gen_init_g180(void)
{
    static union __PST__g__180 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g182();
    return x;
}

struct __PST__g__186 _main_gen_init_g186(void)
{
    static struct __PST__g__186 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.SEDF3 = bitf;
    }
    return x;
}

union __PST__g__184 _main_gen_init_g184(void)
{
    static union __PST__g__184 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g186();
    return x;
}

union __PST__g__188 _main_gen_init_g188(void)
{
    static union __PST__g__188 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__160 _main_gen_init_g160(void)
{
    __PST__g__160 x;
    /* struct/union type */
    x.LRSTCLR_PE1 = _main_gen_init_g176();
    x.LROVFSTR_PE1 = _main_gen_init_g180();
    x.LR1STERSTR_PE1 = _main_gen_init_g184();
    x.LR1STEADR0_PE1 = _main_gen_init_g188();
    x.LR1STEADR1_PE1 = _main_gen_init_g188();
    x.LR1STEADR2_PE1 = _main_gen_init_g188();
    x.LR1STEADR3_PE1 = _main_gen_init_g188();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitCntr(void)
{
    extern __PST__UINT8 RamMem_Pim_LclRamEccSngBitCntr;
    
    /* initialization with random value */
    {
        RamMem_Pim_LclRamEccSngBitCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitSoftFailr(void)
{
    extern __PST__UINT8 RamMem_Pim_LclRamEccSngBitSoftFailr;
    
    /* initialization with random value */
    {
        RamMem_Pim_LclRamEccSngBitSoftFailr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__24 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ECMC(void)
{
    extern __PST__g__24 ECMC;
    
    /* initialization with random value */
    {
        ECMC = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__47 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ECCIC1(void)
{
    extern __PST__g__99 ECCIC1;
    
    /* initialization with random value */
    {
        ECCIC1 = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_ECCCSIH0(void)
{
    extern __PST__g__135 ECCCSIH0;
    
    /* initialization with random value */
    {
        ECCCSIH0 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCCSIH1(void)
{
    extern __PST__g__135 ECCCSIH1;
    
    /* initialization with random value */
    {
        ECCCSIH1 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCCSIH2(void)
{
    extern __PST__g__135 ECCCSIH2;
    
    /* initialization with random value */
    {
        ECCCSIH2 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCCSIH3(void)
{
    extern __PST__g__135 ECCCSIH3;
    
    /* initialization with random value */
    {
        ECCCSIH3 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCRCAN0(void)
{
    extern __PST__g__135 ECCRCAN0;
    
    /* initialization with random value */
    {
        ECCRCAN0 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCFLX0(void)
{
    extern __PST__g__135 ECCFLX0;
    
    /* initialization with random value */
    {
        ECCFLX0 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCFLX0T1(void)
{
    extern __PST__g__135 ECCFLX0T1;
    
    /* initialization with random value */
    {
        ECCFLX0T1 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_ECCFLX0T0(void)
{
    extern __PST__g__135 ECCFLX0T0;
    
    /* initialization with random value */
    {
        ECCFLX0T0 = _main_gen_init_g135();
    }
}

static void _main_gen_init_sym_RamMem_Pim_LclRamFailrAdr(void)
{
    extern __PST__UINT32 RamMem_Pim_LclRamFailrAdr;
    
    /* initialization with random value */
    {
        RamMem_Pim_LclRamFailrAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ECCCPU1(void)
{
    extern __PST__g__160 ECCCPU1;
    
    /* initialization with random value */
    {
        ECCCPU1 = _main_gen_init_g160();
    }
}

static void _main_gen_init_sym_RamMem_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 RamMem_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        RamMem_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable RamMem_Op_LclRamEccSngBitCntrOutp : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemCanRamDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemCanRamSngBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamSngBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamTmpBufADblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamTmpBufBDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi0RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi1RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi2RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi3RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpiRamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_LclRamEccSngBitCntr */
    _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitCntr();
    
    /* init for variable RamMem_Pim_LclRamEccSngBitSoftFailr */
    _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitSoftFailr();
    
    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECMC */
    _main_gen_init_sym_ECMC();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable ECCIC1 */
    _main_gen_init_sym_ECCIC1();
    
    /* init for variable ECCCSIH0 */
    _main_gen_init_sym_ECCCSIH0();
    
    /* init for variable ECCCSIH1 */
    _main_gen_init_sym_ECCCSIH1();
    
    /* init for variable ECCCSIH2 */
    _main_gen_init_sym_ECCCSIH2();
    
    /* init for variable ECCCSIH3 */
    _main_gen_init_sym_ECCCSIH3();
    
    /* init for variable ECCRCAN0 */
    _main_gen_init_sym_ECCRCAN0();
    
    /* init for variable ECCFLX0 */
    _main_gen_init_sym_ECCFLX0();
    
    /* init for variable ECCFLX0T1 */
    _main_gen_init_sym_ECCFLX0T1();
    
    /* init for variable ECCFLX0T0 */
    _main_gen_init_sym_ECCFLX0T0();
    
    /* init for variable RamMem_Pim_LclRamFailrAdr */
    _main_gen_init_sym_RamMem_Pim_LclRamFailrAdr();
    
    /* init for variable RamMem_Pim_LclRamWordLineRead : useless (never read) */

    /* init for variable ECCCPU1 */
    _main_gen_init_sym_ECCCPU1();
    
    /* init for variable RamMem_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_Return */
    _main_gen_init_sym_RamMem_Srv_SetNtcSts_Return();
    
}
