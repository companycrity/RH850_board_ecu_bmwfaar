typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__UINT8 __PST__g__16(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
struct STag_Spi_ConfigType
  {
    __PST__UINT32 __pst_unused_field_0;
  };
typedef __PST__FLOAT64 __PST__g__19(void);
typedef __PST__g__11 *__PST__g__20;
typedef volatile __PST__FLOAT64 __PST__g__21;
typedef __PST__SINT8 *__PST__g__23;
typedef volatile __PST__g__23 __PST__g__22;
typedef __PST__SINT8 __PST__g__256[1];
typedef __PST__SINT8 __PST__g__98[3];
typedef __PST__SINT32 __PST__g__258[1];
union __PST__g__34
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__34 __PST__g__33;
typedef __PST__SINT8 __PST__g__257[4];
struct __PST__g__25
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__g__98 __pst_unused_field_1;
    __PST__g__256 __pst_unused_field_2;
    __PST__g__98 __pst_unused_field_3;
    __PST__g__33 ESSTR0;
    __PST__g__257 __pst_unused_field_5;
    __PST__g__257 __pst_unused_field_6;
  };
typedef volatile struct __PST__g__25 __PST__g__24;
union __PST__g__26
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__27
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__30[3];
union __PST__g__31
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__32
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__36
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    const __PST__UINT32 __pst_unused_field_28 : 1;
    const __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
  };
typedef const struct __PST__g__36 __PST__g__35;
union __PST__g__40
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__40 __PST__g__39;
struct __PST__g__42
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
  };
typedef const struct __PST__g__42 __PST__g__41;
union __PST__g__44
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__45
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
union __PST__g__68
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__70
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const __PST__UINT16 __PST__g__85;
typedef __PST__SINT8 __PST__g__259[2];
typedef __PST__SINT8 __PST__g__260[4008];
struct __PST__g__48
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__g__98 __pst_unused_field_1;
    __PST__g__257 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
    __PST__g__257 __pst_unused_field_4;
    __PST__g__257 __pst_unused_field_5;
    __PST__g__257 __pst_unused_field_6;
    __PST__g__257 __pst_unused_field_7;
    __PST__g__257 __pst_unused_field_8;
    __PST__g__257 __pst_unused_field_9;
    union __PST__g__68 ESSTC0;
    union __PST__g__70 ESSTC1;
    __PST__g__257 __pst_unused_field_12;
    __PST__g__256 __pst_unused_field_13;
    __PST__g__98 __pst_unused_field_14;
    __PST__g__257 __pst_unused_field_15;
    __PST__g__257 __pst_unused_field_16;
    __PST__g__256 __pst_unused_field_17;
    __PST__g__98 __pst_unused_field_18;
    __PST__g__85 __pst_unused_field_19;
    __PST__g__259 __pst_unused_field_20;
    __PST__UINT16 __pst_unused_field_21;
    __PST__g__259 __pst_unused_field_22;
    __PST__g__257 __pst_unused_field_23;
    __PST__g__257 __pst_unused_field_24;
    __PST__g__257 __pst_unused_field_25;
    __PST__g__257 __pst_unused_field_26;
    __PST__g__260 __pst_unused_field_27;
    __PST__g__256 __pst_unused_field_28;
    __PST__g__98 __pst_unused_field___pstfiller;
  };
typedef volatile struct __PST__g__48 __PST__g__47;
union __PST__g__49
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__50
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__51
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__52
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__53
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__54
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__56
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__57
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__58
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__59
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__60
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__61
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__62
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__63
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
union __PST__g__64
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__65
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__66
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__67
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__69
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
struct __PST__g__71
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
  };
union __PST__g__72
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__73
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
union __PST__g__75
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__75 __PST__g__74;
struct __PST__g__77
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__77 __PST__g__76;
union __PST__g__78
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__79
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__80
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__81
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
union __PST__g__82
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__83
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__86[2];
union __PST__g__87
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__88
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__89
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__90
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__91
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__92
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__93
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__94
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
typedef __PST__UINT8 __PST__g__95[4008];
union __PST__g__96
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__97
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__SINT16 __PST__g__262[2];
union __PST__g__108
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__257 __pst_unused_field_3;
  };
typedef __PST__SINT8 __PST__g__261[60];
union __PST__g__125
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__257 __pst_unused_field_3;
  };
struct __PST__g__100
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__257 __pst_unused_field_1;
    union __PST__g__108 IDSTCLR_PE1;
    __PST__g__257 __pst_unused_field_3;
    __PST__g__257 __pst_unused_field_4;
    __PST__g__261 __pst_unused_field_5;
    __PST__g__257 __pst_unused_field_6;
    __PST__g__257 __pst_unused_field_7;
    __PST__g__260 __pst_unused_field_8;
    __PST__g__257 __pst_unused_field_9;
    __PST__g__257 __pst_unused_field_10;
    union __PST__g__125 ITSTCLR_PE1;
    __PST__g__257 __pst_unused_field_12;
    __PST__g__257 __pst_unused_field_13;
    __PST__g__261 __pst_unused_field_14;
    __PST__g__257 __pst_unused_field_15;
  };
typedef volatile struct __PST__g__100 __PST__g__99;
union __PST__g__101
  {
    __PST__g__262 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
  };
struct __PST__g__102
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 13;
    __PST__UINT16 __pst_unused_field_2 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 16;
  };
typedef __PST__UINT16 __PST__g__104[2];
union __PST__g__105
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
struct __PST__g__106
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef __PST__UINT8 __PST__g__107[4];
struct __PST__g__109
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
union __PST__g__111
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__111 __PST__g__110;
struct __PST__g__113
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef const struct __PST__g__113 __PST__g__112;
union __PST__g__115
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__115 __PST__g__114;
struct __PST__g__117
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    const __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 6;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef const struct __PST__g__117 __PST__g__116;
typedef __PST__UINT8 __PST__g__118[60];
union __PST__g__120
  {
    __PST__g__262 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__120 __PST__g__119;
struct __PST__g__122
  {
    const __PST__UINT16 __pst_unused_field_0 : 9;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
  };
typedef const struct __PST__g__122 __PST__g__121;
struct __PST__g__126
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
union __PST__g__128
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__128 __PST__g__127;
struct __PST__g__130
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef const struct __PST__g__130 __PST__g__129;
union __PST__g__132
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__132 __PST__g__131;
struct __PST__g__134
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef const struct __PST__g__134 __PST__g__133;
union __PST__g__137
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__257 __pst_unused_field_3;
  };
union __PST__g__150
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__150 __PST__g__149;
typedef __PST__SINT8 __PST__g__263[44];
struct __PST__g__136
  {
    union __PST__g__137 CTL;
    __PST__g__259 __pst_unused_field_1;
    __PST__g__259 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
    __PST__g__257 __pst_unused_field_4;
    __PST__g__149 EAD0;
    __PST__g__263 __pst_unused_field_6;
  };
typedef volatile struct __PST__g__136 __PST__g__135;
struct __PST__g__138
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT8 __pst_unused_field_9 : 1;
    __PST__UINT8 __pst_unused_field_10 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 3;
    __PST__UINT8 __pst_unused_field_12 : 2;
    const __PST__UINT8 __pst_unused_field_13 : 1;
    const __PST__UINT8 __pst_unused_field_14 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 6;
    __PST__UINT8 __pst_unused_field_pstnonamef5 : 8;
  };
union __PST__g__140
  {
    __PST__g__259 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__259 __pst_unused_field_2;
  };
struct __PST__g__141
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 6;
    __PST__UINT8 __pst_unused_field_8 : 2;
  };
union __PST__g__142
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__257 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
struct __PST__g__143
  {
    __PST__UINT8 __pst_unused_field_0 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT8 __pst_unused_field_4 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 1;
    const __PST__UINT8 __pst_unused_field_6 : 7;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 1;
  };
struct __PST__g__145
  {
    __PST__g__256 __pst_unused_field_0;
    __PST__g__256 __pst_unused_field_1;
    __PST__g__256 __pst_unused_field_2;
    __PST__g__256 __pst_unused_field_3;
  };
union __PST__g__146
  {
    __PST__UINT8 __pst_unused_field_0;
  };
union __PST__g__147
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__148
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
struct __PST__g__152
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__152 __PST__g__151;
typedef const __PST__UINT32 __PST__g__153;
typedef __PST__UINT8 __PST__g__154[44];
typedef __PST__VOID __PST__g__155(__PST__SINT32);
typedef volatile __PST__UINT32 __PST__g__158;
typedef __PST__g__158 *__PST__g__157;
typedef __PST__VOID __PST__g__156(__PST__UINT32, __PST__g__157);
typedef __PST__VOID __PST__g__159(__PST__UINT32, __PST__UINT32);
typedef __PST__SINT8 __PST__g__264[1008];
struct __PST__g__177
  {
    __PST__UINT8 STCLR0 : 1;
    __PST__UINT8 STCLR1 : 1;
    __PST__UINT8 STCLR2 : 1;
    __PST__UINT8 STCLR3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
union __PST__g__176
  {
    struct __PST__g__177 BIT;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__257 __pst_unused_field_3;
  };
struct __PST__g__182
  {
    const __PST__UINT8 ERROVF0 : 1;
    const __PST__UINT8 ERROVF1 : 1;
    const __PST__UINT8 ERROVF2 : 1;
    const __PST__UINT8 ERROVF3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 8;
  };
typedef const struct __PST__g__182 __PST__g__181;
union __PST__g__180
  {
    __PST__g__181 BIT;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__180 __PST__g__179;
struct __PST__g__186
  {
    const __PST__UINT8 SEDF0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
    const __PST__UINT8 SEDF1 : 1;
    const __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 6;
    const __PST__UINT8 SEDF2 : 1;
    const __PST__UINT8 __pst_unused_field_7 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 6;
    const __PST__UINT8 SEDF3 : 1;
    const __PST__UINT8 __pst_unused_field_10 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef4 : 6;
  };
typedef const struct __PST__g__186 __PST__g__185;
union __PST__g__184
  {
    __PST__g__185 BIT;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__184 __PST__g__183;
union __PST__g__188
  {
    __PST__g__262 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 UINT32;
    __PST__g__257 __pst_unused_field_3;
  };
typedef const union __PST__g__188 __PST__g__187;
struct __PST__g__161
  {
    __PST__g__257 __pst_unused_field_0;
    __PST__g__257 __pst_unused_field_1;
    __PST__g__257 __pst_unused_field_2;
    __PST__g__264 __pst_unused_field_3;
    __PST__g__257 __pst_unused_field_4;
    __PST__g__257 __pst_unused_field_5;
    union __PST__g__176 LRSTCLR_PE1;
    __PST__g__179 LROVFSTR_PE1;
    __PST__g__183 LR1STERSTR_PE1;
    __PST__g__261 __pst_unused_field_9;
    __PST__g__187 LR1STEADR0_PE1;
    __PST__g__187 LR1STEADR1_PE1;
    __PST__g__187 LR1STEADR2_PE1;
    __PST__g__187 LR1STEADR3_PE1;
  };
typedef volatile struct __PST__g__161 __PST__g__160;
union __PST__g__162
  {
    __PST__g__262 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
  };
struct __PST__g__163
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 12;
    __PST__UINT16 __pst_unused_field_3 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 16;
  };
union __PST__g__166
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__166 __PST__g__165;
struct __PST__g__168
  {
    const __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 9;
    const __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 9;
  };
typedef const struct __PST__g__168 __PST__g__167;
union __PST__g__170
  {
    __PST__g__258 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__170 __PST__g__169;
struct __PST__g__172
  {
    const __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 9;
    const __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 9;
  };
typedef const struct __PST__g__172 __PST__g__171;
typedef __PST__UINT8 __PST__g__173[1008];
union __PST__g__174
  {
    __PST__g__262 __pst_unused_field_0;
    __PST__g__262 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
  };
struct __PST__g__175
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 12;
    __PST__UINT16 __pst_unused_field_3 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 16;
  };
struct __PST__g__190
  {
    const __PST__UINT16 __pst_unused_field_0 : 15;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 8;
  };
typedef const struct __PST__g__190 __PST__g__189;
typedef __PST__UINT8 __PST__g__193(__PST__UINT8, __PST__UINT8, __PST__UINT8);
typedef __PST__g__16 *__PST__g__194;
typedef __PST__g__15 *__PST__g__195;
typedef __PST__g__193 *__PST__g__196;
typedef __PST__g__156 *__PST__g__197;
typedef __PST__g__47 *__PST__g__198;
typedef volatile union __PST__g__68 __PST__g__199;
typedef __PST__g__199 *__PST__g__200;
typedef __PST__g__99 *__PST__g__201;
typedef volatile union __PST__g__108 __PST__g__202;
typedef __PST__g__202 *__PST__g__203;
typedef volatile union __PST__g__125 __PST__g__204;
typedef __PST__g__204 *__PST__g__205;
typedef __PST__g__24 *__PST__g__206;
typedef volatile __PST__g__33 __PST__g__207;
typedef __PST__g__207 *__PST__g__208;
typedef volatile __PST__g__153 __PST__g__209;
typedef __PST__g__209 *__PST__g__210;
typedef __PST__g__135 *__PST__g__211;
typedef volatile __PST__g__149 __PST__g__212;
typedef __PST__g__212 *__PST__g__213;
typedef volatile union __PST__g__70 __PST__g__214;
typedef __PST__g__214 *__PST__g__215;
typedef volatile union __PST__g__137 __PST__g__216;
typedef __PST__g__216 *__PST__g__217;
typedef __PST__VOID __PST__g__218(__PST__UINT32);
typedef __PST__UINT32 *__PST__g__219;
typedef __PST__g__160 *__PST__g__220;
typedef volatile __PST__g__187 __PST__g__221;
typedef __PST__g__221 *__PST__g__222;
typedef __PST__g__218 *__PST__g__223;
typedef __PST__g__159 *__PST__g__224;
typedef volatile union __PST__g__176 __PST__g__225;
typedef __PST__g__225 *__PST__g__226;
typedef volatile struct __PST__g__177 __PST__g__227;
typedef __PST__g__227 *__PST__g__228;
typedef __PST__VOID __PST__g__231(__PST__UINT32, __PST__UINT32, __PST__UINT32);
typedef __PST__g__231 *__PST__g__232;
typedef volatile __PST__g__183 __PST__g__233;
typedef __PST__g__233 *__PST__g__234;
typedef volatile __PST__g__185 __PST__g__235;
typedef __PST__g__235 *__PST__g__236;
typedef volatile __PST__g__179 __PST__g__239;
typedef __PST__g__239 *__PST__g__240;
typedef volatile __PST__g__181 __PST__g__241;
typedef __PST__g__241 *__PST__g__242;
typedef __PST__g__155 *__PST__g__243;
typedef volatile __PST__SINT32 __PST__g__244;
typedef __PST__SINT8 __PST__g__250(void);
typedef volatile __PST__SINT8 __PST__g__251;
typedef __PST__UINT8 __PST__g__252(void);
typedef volatile __PST__UINT8 __PST__g__253;
typedef __PST__SINT32 __PST__g__254(void);
typedef __PST__UINT32 __PST__g__255(void);
