/**********************************************************************************************************************
local include for CM103A */
#ifndef CDD_EXCPNHNDLG_H
#define CDD_EXCPNHNDLG_H

typedef uint32 McuDiagc1;

#define         MCUDIAGC_LCLRAMECCSNGBITHARDFAILR (4277928195U)   /* 0xFEFC0103 */

#endif
