
#ifndef FLTINJ_H
#define FLTINJ_H

#define FLTINJ_IDPTSIG_HWTQCORRLN               (27U)

#endif
