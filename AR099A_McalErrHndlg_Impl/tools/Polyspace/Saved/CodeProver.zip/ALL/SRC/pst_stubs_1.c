#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__81 _main_gen_init_g81(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__28 _main_gen_init_g28(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__28 _main_gen_init_g28(void)
{
    static union __PST__g__28 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* struct/union type */
    x.DAT0 = _main_gen_init_g28();
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.RESFC = _main_gen_init_g81();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_McalErrHndlg_Pim_CritErrCod(void)
{
    extern __PST__UINT8 McalErrHndlg_Pim_CritErrCod;
    
    /* initialization with random value */
    {
        McalErrHndlg_Pim_CritErrCod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_McalErrHndlg_Pim_NonCritErrCod(void)
{
    extern __PST__UINT8 McalErrHndlg_Pim_NonCritErrCod;
    
    /* initialization with random value */
    {
        McalErrHndlg_Pim_NonCritErrCod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BRAM(void)
{
    extern __PST__g__26 BRAM;
    
    /* initialization with random value */
    {
        BRAM = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__36 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_McalErrHndlg_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 McalErrHndlg_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        McalErrHndlg_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable McalErrHndlg_Pim_CritErrCod */
    _main_gen_init_sym_McalErrHndlg_Pim_CritErrCod();
    
    /* init for variable McalErrHndlg_Pim_NonCritErrCod */
    _main_gen_init_sym_McalErrHndlg_Pim_NonCritErrCod();
    
    /* init for variable BRAM */
    _main_gen_init_sym_BRAM();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable McalErrHndlg_Srv_MCalReadVrfyFailFltInfo_PrphlId : useless (never read) */

    /* init for variable McalErrHndlg_Srv_MCalReadVrfyFailFltInfo_ErrId : useless (never read) */

    /* init for variable McalErrHndlg_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable McalErrHndlg_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable McalErrHndlg_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable McalErrHndlg_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable McalErrHndlg_Srv_SetNtcSts_Return */
    _main_gen_init_sym_McalErrHndlg_Srv_SetNtcSts_Return();
    
}
