#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__44 _main_gen_init_g44(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__44 _main_gen_init_g44(void)
{
    static struct __PST__g__44 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_CtrldVelRtn_Ip_AssiMechPolarity(void)
{
    extern __PST__SINT8 CtrldVelRtn_Ip_AssiMechPolarity;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_AssiMechPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_HwAg(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_HwAg;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_HwAgAuthy(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_HwAgAuthy;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_HwAgAuthy = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_HwAgRtnOffs(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_HwAgRtnOffs;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_HwAgRtnOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_HwTq;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_HwVel(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_HwVel;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_MotTqCmdPwrLimd(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_MotTqCmdPwrLimd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_MotTqCmdPwrLimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdDi(void)
{
    extern __PST__UINT8 CtrldVelRtn_Ip_RtnCmdDi;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_RtnCmdDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdDiagcDi(void)
{
    extern __PST__UINT8 CtrldVelRtn_Ip_RtnCmdDiagcDi;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_RtnCmdDiagcDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdSca(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_RtnCmdSca;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_RtnCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdScaServo(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_RtnCmdScaServo;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_RtnCmdScaServo = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnAntiWdup(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnAntiWdup;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnAntiWdup = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgEna(void)
{
    extern __PST__g__25 CtrldVelRtn_Cal_CtrldVelRtnDampgEna;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnDampgEna = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgScaEna(void)
{
    extern __PST__g__25 CtrldVelRtn_Cal_CtrldVelRtnDampgScaEna;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnDampgScaEna = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgX(void)
{
    extern __PST__g__26 CtrldVelRtn_Cal_CtrldVelRtnDampgX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 9; _main_gen_tmp_2_0++)
            {
                __PST__UINT32 _main_gen_tmp_2_1;
                
                for (_main_gen_tmp_2_1 = 0; _main_gen_tmp_2_1 < 8; _main_gen_tmp_2_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDampgX[_main_gen_tmp_2_0][_main_gen_tmp_2_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgY(void)
{
    extern __PST__g__26 CtrldVelRtn_Cal_CtrldVelRtnDampgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 9; _main_gen_tmp_3_0++)
            {
                __PST__UINT32 _main_gen_tmp_3_1;
                
                for (_main_gen_tmp_3_1 = 0; _main_gen_tmp_3_1 < 8; _main_gen_tmp_3_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDampgY[_main_gen_tmp_3_0][_main_gen_tmp_3_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelLpFilFrq(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnDesVelLpFilFrq;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnDesVelLpFilFrq = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelScaX(void)
{
    extern __PST__g__29 CtrldVelRtn_Cal_CtrldVelRtnDesVelScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 8; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 5; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDesVelScaX[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelScaY(void)
{
    extern __PST__g__29 CtrldVelRtn_Cal_CtrldVelRtnDesVelScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 8; _main_gen_tmp_5_0++)
            {
                __PST__UINT32 _main_gen_tmp_5_1;
                
                for (_main_gen_tmp_5_1 = 0; _main_gen_tmp_5_1 < 5; _main_gen_tmp_5_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDesVelScaY[_main_gen_tmp_5_0][_main_gen_tmp_5_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelX(void)
{
    extern __PST__g__31 CtrldVelRtn_Cal_CtrldVelRtnDesVelX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 12; _main_gen_tmp_6_0++)
            {
                __PST__UINT32 _main_gen_tmp_6_1;
                
                for (_main_gen_tmp_6_1 = 0; _main_gen_tmp_6_1 < 8; _main_gen_tmp_6_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDesVelX[_main_gen_tmp_6_0][_main_gen_tmp_6_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelY(void)
{
    extern __PST__g__31 CtrldVelRtn_Cal_CtrldVelRtnDesVelY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 12; _main_gen_tmp_7_0++)
            {
                __PST__UINT32 _main_gen_tmp_7_1;
                
                for (_main_gen_tmp_7_1 = 0; _main_gen_tmp_7_1 < 8; _main_gen_tmp_7_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDesVelY[_main_gen_tmp_7_0][_main_gen_tmp_7_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqEna(void)
{
    extern __PST__g__25 CtrldVelRtn_Cal_CtrldVelRtnDrvrTqEna;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnDrvrTqEna = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxA(void)
{
    extern __PST__g__32 CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxA;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 5; _main_gen_tmp_8_0++)
            {
                __PST__UINT32 _main_gen_tmp_8_1;
                
                for (_main_gen_tmp_8_1 = 0; _main_gen_tmp_8_1 < 5; _main_gen_tmp_8_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxA[_main_gen_tmp_8_0][_main_gen_tmp_8_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxB(void)
{
    extern __PST__g__34 CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxB;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 4; _main_gen_tmp_9_0++)
            {
                __PST__UINT32 _main_gen_tmp_9_1;
                
                for (_main_gen_tmp_9_1 = 0; _main_gen_tmp_9_1 < 5; _main_gen_tmp_9_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxB[_main_gen_tmp_9_0][_main_gen_tmp_9_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxC(void)
{
    extern __PST__g__33 CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxC;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 5; _main_gen_tmp_10_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxC[_main_gen_tmp_10_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxD(void)
{
    extern __PST__g__35 CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxD;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 4; _main_gen_tmp_11_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxD[_main_gen_tmp_11_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaX(void)
{
    extern __PST__g__36 CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 4; _main_gen_tmp_12_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaX[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaY(void)
{
    extern __PST__g__36 CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 4; _main_gen_tmp_13_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaY[_main_gen_tmp_13_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwAuthySlewThd(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnHwAuthySlewThd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnHwAuthySlewThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwPosnScaX(void)
{
    extern __PST__g__37 CtrldVelRtn_Cal_CtrldVelRtnHwPosnScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 9; _main_gen_tmp_14_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnHwPosnScaX[_main_gen_tmp_14_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqLpFilFrq(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnHwTqLpFilFrq;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnHwTqLpFilFrq = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1X(void)
{
    extern __PST__g__38 CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1X;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 10; _main_gen_tmp_15_0++)
            {
                __PST__UINT32 _main_gen_tmp_15_1;
                
                for (_main_gen_tmp_15_1 = 0; _main_gen_tmp_15_1 < 5; _main_gen_tmp_15_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1X[_main_gen_tmp_15_0][_main_gen_tmp_15_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1Y(void)
{
    extern __PST__g__38 CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1Y;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 10; _main_gen_tmp_16_0++)
            {
                __PST__UINT32 _main_gen_tmp_16_1;
                
                for (_main_gen_tmp_16_1 = 0; _main_gen_tmp_16_1 < 5; _main_gen_tmp_16_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1Y[_main_gen_tmp_16_0][_main_gen_tmp_16_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2X(void)
{
    extern __PST__g__38 CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2X;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 10; _main_gen_tmp_17_0++)
            {
                __PST__UINT32 _main_gen_tmp_17_1;
                
                for (_main_gen_tmp_17_1 = 0; _main_gen_tmp_17_1 < 5; _main_gen_tmp_17_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2X[_main_gen_tmp_17_0][_main_gen_tmp_17_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2Y(void)
{
    extern __PST__g__38 CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2Y;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 10; _main_gen_tmp_18_0++)
            {
                __PST__UINT32 _main_gen_tmp_18_1;
                
                for (_main_gen_tmp_18_1 = 0; _main_gen_tmp_18_1 < 5; _main_gen_tmp_18_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2Y[_main_gen_tmp_18_0][_main_gen_tmp_18_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewHiLim(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewHiLim;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewHiLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewLoLim(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewLoLim;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewLoLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnTqThd(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnTqThd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnTqThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnVelThd(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnVelThd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnVelThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnIntglGain(void)
{
    extern __PST__g__27 CtrldVelRtn_Cal_CtrldVelRtnIntglGain;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 8; _main_gen_tmp_19_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnIntglGain[_main_gen_tmp_19_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnIntgrLimY(void)
{
    extern __PST__g__39 CtrldVelRtn_Cal_CtrldVelRtnIntgrLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 9; _main_gen_tmp_20_0++)
            {
                __PST__UINT32 _main_gen_tmp_20_1;
                
                for (_main_gen_tmp_20_1 = 0; _main_gen_tmp_20_1 < 5; _main_gen_tmp_20_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnIntgrLimY[_main_gen_tmp_20_0][_main_gen_tmp_20_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnOffsSlewThd(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnOffsSlewThd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnOffsSlewThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnOffsThd(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnOffsThd;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnOffsThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaX(void)
{
    extern __PST__g__29 CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_21_0;
            
            for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 8; _main_gen_tmp_21_0++)
            {
                __PST__UINT32 _main_gen_tmp_21_1;
                
                for (_main_gen_tmp_21_1 = 0; _main_gen_tmp_21_1 < 5; _main_gen_tmp_21_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaX[_main_gen_tmp_21_0][_main_gen_tmp_21_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaY(void)
{
    extern __PST__g__29 CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 8; _main_gen_tmp_22_0++)
            {
                __PST__UINT32 _main_gen_tmp_22_1;
                
                for (_main_gen_tmp_22_1 = 0; _main_gen_tmp_22_1 < 5; _main_gen_tmp_22_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaY[_main_gen_tmp_22_0][_main_gen_tmp_22_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnPropGain(void)
{
    extern __PST__g__27 CtrldVelRtn_Cal_CtrldVelRtnPropGain;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_23_0;
            
            for (_main_gen_tmp_23_0 = 0; _main_gen_tmp_23_0 < 8; _main_gen_tmp_23_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnPropGain[_main_gen_tmp_23_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnRtnCmdLimY(void)
{
    extern __PST__g__27 CtrldVelRtn_Cal_CtrldVelRtnRtnCmdLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_24_0;
            
            for (_main_gen_tmp_24_0 = 0; _main_gen_tmp_24_0 < 8; _main_gen_tmp_24_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnRtnCmdLimY[_main_gen_tmp_24_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnScaLpFilFrq(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_CtrldVelRtnScaLpFilFrq;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnScaLpFilFrq = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaEna(void)
{
    extern __PST__g__25 CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaEna;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaEna = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaX(void)
{
    extern __PST__g__29 CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_25_0;
            
            for (_main_gen_tmp_25_0 = 0; _main_gen_tmp_25_0 < 8; _main_gen_tmp_25_0++)
            {
                __PST__UINT32 _main_gen_tmp_25_1;
                
                for (_main_gen_tmp_25_1 = 0; _main_gen_tmp_25_1 < 5; _main_gen_tmp_25_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaX[_main_gen_tmp_25_0][_main_gen_tmp_25_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaY(void)
{
    extern __PST__g__29 CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_26_0;
            
            for (_main_gen_tmp_26_0 = 0; _main_gen_tmp_26_0 < 8; _main_gen_tmp_26_0++)
            {
                __PST__UINT32 _main_gen_tmp_26_1;
                
                for (_main_gen_tmp_26_1 = 0; _main_gen_tmp_26_1 < 5; _main_gen_tmp_26_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaY[_main_gen_tmp_26_0][_main_gen_tmp_26_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVehSpdScaBilnrSeln(void)
{
    extern __PST__g__30 CtrldVelRtn_Cal_CtrldVelRtnVehSpdScaBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_27_0;
            
            for (_main_gen_tmp_27_0 = 0; _main_gen_tmp_27_0 < 5; _main_gen_tmp_27_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnVehSpdScaBilnrSeln[_main_gen_tmp_27_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaBilnrSeln(void)
{
    extern __PST__g__40 CtrldVelRtn_Cal_CtrldVelRtnVelErrScaBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_28_0;
            
            for (_main_gen_tmp_28_0 = 0; _main_gen_tmp_28_0 < 7; _main_gen_tmp_28_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnVelErrScaBilnrSeln[_main_gen_tmp_28_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaEna(void)
{
    extern __PST__g__25 CtrldVelRtn_Cal_CtrldVelRtnVelErrScaEna;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_CtrldVelRtnVelErrScaEna = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaX(void)
{
    extern __PST__g__41 CtrldVelRtn_Cal_CtrldVelRtnVelErrScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_29_0;
            
            for (_main_gen_tmp_29_0 = 0; _main_gen_tmp_29_0 < 8; _main_gen_tmp_29_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnVelErrScaX[_main_gen_tmp_29_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaY(void)
{
    extern __PST__g__43 CtrldVelRtn_Cal_CtrldVelRtnVelErrScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_30_0;
            
            for (_main_gen_tmp_30_0 = 0; _main_gen_tmp_30_0 < 8; _main_gen_tmp_30_0++)
            {
                __PST__UINT32 _main_gen_tmp_30_1;
                
                for (_main_gen_tmp_30_1 = 0; _main_gen_tmp_30_1 < 7; _main_gen_tmp_30_1++)
                {
                    /* base type */
                    CtrldVelRtn_Cal_CtrldVelRtnVelErrScaY[_main_gen_tmp_30_0][_main_gen_tmp_30_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrVehSpdScaY(void)
{
    extern __PST__g__30 CtrldVelRtn_Cal_CtrldVelRtnVelErrVehSpdScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_31_0;
            
            for (_main_gen_tmp_31_0 = 0; _main_gen_tmp_31_0 < 5; _main_gen_tmp_31_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnVelErrVehSpdScaY[_main_gen_tmp_31_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelSpdTbl(void)
{
    extern __PST__g__27 CtrldVelRtn_Cal_CtrldVelRtnVelSpdTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_32_0;
            
            for (_main_gen_tmp_32_0 = 0; _main_gen_tmp_32_0 < 8; _main_gen_tmp_32_0++)
            {
                /* base type */
                CtrldVelRtn_Cal_CtrldVelRtnVelSpdTbl[_main_gen_tmp_32_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Cal_SysGlbPrmSysTqRat(void)
{
    extern __PST__g__24 CtrldVelRtn_Cal_SysGlbPrmSysTqRat;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Cal_SysGlbPrmSysTqRat = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_CtrlScaLpFil(void)
{
    extern struct __PST__g__44 CtrldVelRtn_Pim_CtrlScaLpFil;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_CtrlScaLpFil = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_DesVelLpFil(void)
{
    extern struct __PST__g__44 CtrldVelRtn_Pim_DesVelLpFil;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_DesVelLpFil = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_DesVelScaLpFil(void)
{
    extern struct __PST__g__44 CtrldVelRtn_Pim_DesVelScaLpFil;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_DesVelScaLpFil = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_DrvrTqLpFil(void)
{
    extern struct __PST__g__44 CtrldVelRtn_Pim_DrvrTqLpFil;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_DrvrTqLpFil = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PinionTqLpFil(void)
{
    extern struct __PST__g__44 CtrldVelRtn_Pim_PinionTqLpFil;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PinionTqLpFil = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDesVel(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDesVel;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDesVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildA(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDrvrTqFildA;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDrvrTqFildA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildB(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDrvrTqFildB;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDrvrTqFildB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildC(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDrvrTqFildC;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDrvrTqFildC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildD(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDrvrTqFildD;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDrvrTqFildD = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildE(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDrvrTqFildE;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDrvrTqFildE = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildF(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevDrvrTqFildF;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevDrvrTqFildF = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqMtrx(void)
{
    extern __PST__g__17 CtrldVelRtn_Pim_PrevDrvrTqMtrx;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_33_0;
            
            for (_main_gen_tmp_33_0 = 0; _main_gen_tmp_33_0 < 5; _main_gen_tmp_33_0++)
            {
                /* base type */
                CtrldVelRtn_Pim_PrevDrvrTqMtrx[_main_gen_tmp_33_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevHwAuthySca(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevHwAuthySca;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevHwAuthySca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevHwTqSeln(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevHwTqSeln;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevHwTqSeln = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevIntglTermA(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevIntglTermA;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevIntglTermA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevIntglTermB(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevIntglTermB;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevIntglTermB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevIntglTermC(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevIntglTermC;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevIntglTermC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CtrldVelRtn_Pim_PrevRtnOffs(void)
{
    extern __PST__FLOAT32 CtrldVelRtn_Pim_PrevRtnOffs;
    
    /* initialization with random value */
    {
        CtrldVelRtn_Pim_PrevRtnOffs = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable CtrldVelRtn_Ip_AssiMechPolarity */
    _main_gen_init_sym_CtrldVelRtn_Ip_AssiMechPolarity();
    
    /* init for variable CtrldVelRtn_Ip_HwAg */
    _main_gen_init_sym_CtrldVelRtn_Ip_HwAg();
    
    /* init for variable CtrldVelRtn_Ip_HwAgAuthy */
    _main_gen_init_sym_CtrldVelRtn_Ip_HwAgAuthy();
    
    /* init for variable CtrldVelRtn_Ip_HwAgRtnOffs */
    _main_gen_init_sym_CtrldVelRtn_Ip_HwAgRtnOffs();
    
    /* init for variable CtrldVelRtn_Ip_HwTq */
    _main_gen_init_sym_CtrldVelRtn_Ip_HwTq();
    
    /* init for variable CtrldVelRtn_Ip_HwVel */
    _main_gen_init_sym_CtrldVelRtn_Ip_HwVel();
    
    /* init for variable CtrldVelRtn_Ip_MotTqCmdPwrLimd */
    _main_gen_init_sym_CtrldVelRtn_Ip_MotTqCmdPwrLimd();
    
    /* init for variable CtrldVelRtn_Ip_RtnCmdDi */
    _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdDi();
    
    /* init for variable CtrldVelRtn_Ip_RtnCmdDiagcDi */
    _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdDiagcDi();
    
    /* init for variable CtrldVelRtn_Ip_RtnCmdSca */
    _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdSca();
    
    /* init for variable CtrldVelRtn_Ip_RtnCmdScaServo */
    _main_gen_init_sym_CtrldVelRtn_Ip_RtnCmdScaServo();
    
    /* init for variable CtrldVelRtn_Ip_VehSpd */
    _main_gen_init_sym_CtrldVelRtn_Ip_VehSpd();
    
    /* init for variable CtrldVelRtn_Op_CtrldVelRtnCmd : useless (never read) */

    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnAntiWdup */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnAntiWdup();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDampgEna */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgEna();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDampgScaEna */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgScaEna();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDampgX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDampgY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDampgY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDesVelLpFilFrq */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelLpFilFrq();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDesVelScaX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelScaX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDesVelScaY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelScaY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDesVelX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDesVelY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDesVelY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDrvrTqEna */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqEna();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxA */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxA();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxB */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxB();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxC */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxC();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxD */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnDrvrTqMtrxD();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwAuthyScaY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwAuthySlewThd */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwAuthySlewThd();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwPosnScaX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwPosnScaX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqLpFilFrq */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqLpFilFrq();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1X */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1X();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1Y */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca1Y();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2X */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2X();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2Y */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqSca2Y();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewHiLim */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewHiLim();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewLoLim */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnSlewLoLim();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnTqThd */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnTqThd();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnVelThd */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnHwTqScaSelnVelThd();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnIntglGain */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnIntglGain();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnIntgrLimY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnIntgrLimY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnOffsSlewThd */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnOffsSlewThd();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnOffsThd */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnOffsThd();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnPinionTqScaY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnPropGain */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnPropGain();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnRtnCmdLimY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnRtnCmdLimY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnScaLpFilFrq */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnScaLpFilFrq();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaEna */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaEna();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnTqGrdtScaY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVehSpdScaBilnrSeln */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVehSpdScaBilnrSeln();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVelErrScaBilnrSeln */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaBilnrSeln();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVelErrScaEna */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaEna();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVelErrScaX */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaX();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVelErrScaY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrScaY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVelErrVehSpdScaY */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelErrVehSpdScaY();
    
    /* init for variable CtrldVelRtn_Cal_CtrldVelRtnVelSpdTbl */
    _main_gen_init_sym_CtrldVelRtn_Cal_CtrldVelRtnVelSpdTbl();
    
    /* init for variable CtrldVelRtn_Cal_SysGlbPrmSysTqRat */
    _main_gen_init_sym_CtrldVelRtn_Cal_SysGlbPrmSysTqRat();
    
    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnCtrlSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnCtrlScaPreFild : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnDampgCmd : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnDesVel : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnDesVelSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnDesVelScaPreFild : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnDrvrTqEstimd : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnDrvrTqFild : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnHwAgCmp : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnHwAuthySca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnHwPosnSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnHwTqSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnHwTqScaSeln : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnIntglTermCmd : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnIntgrLim : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnPinionTqSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnPropTermCmd : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnRtnCmd : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnRtnCmdPreLim : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnTqGrdt : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnTqGrdtSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_dCtrldVelRtnVelErrSca : useless (never read) */

    /* init for variable CtrldVelRtn_Pim_CtrlScaLpFil */
    _main_gen_init_sym_CtrldVelRtn_Pim_CtrlScaLpFil();
    
    /* init for variable CtrldVelRtn_Pim_DesVelLpFil */
    _main_gen_init_sym_CtrldVelRtn_Pim_DesVelLpFil();
    
    /* init for variable CtrldVelRtn_Pim_DesVelScaLpFil */
    _main_gen_init_sym_CtrldVelRtn_Pim_DesVelScaLpFil();
    
    /* init for variable CtrldVelRtn_Pim_DrvrTqLpFil */
    _main_gen_init_sym_CtrldVelRtn_Pim_DrvrTqLpFil();
    
    /* init for variable CtrldVelRtn_Pim_PinionTqLpFil */
    _main_gen_init_sym_CtrldVelRtn_Pim_PinionTqLpFil();
    
    /* init for variable CtrldVelRtn_Pim_PrevDesVel */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDesVel();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqFildA */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildA();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqFildB */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildB();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqFildC */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildC();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqFildD */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildD();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqFildE */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildE();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqFildF */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqFildF();
    
    /* init for variable CtrldVelRtn_Pim_PrevDrvrTqMtrx */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevDrvrTqMtrx();
    
    /* init for variable CtrldVelRtn_Pim_PrevHwAuthySca */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevHwAuthySca();
    
    /* init for variable CtrldVelRtn_Pim_PrevHwTqSeln */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevHwTqSeln();
    
    /* init for variable CtrldVelRtn_Pim_PrevIntglTermA */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevIntglTermA();
    
    /* init for variable CtrldVelRtn_Pim_PrevIntglTermB */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevIntglTermB();
    
    /* init for variable CtrldVelRtn_Pim_PrevIntglTermC */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevIntglTermC();
    
    /* init for variable CtrldVelRtn_Pim_PrevRtnOffs */
    _main_gen_init_sym_CtrldVelRtn_Pim_PrevRtnOffs();
    
}
