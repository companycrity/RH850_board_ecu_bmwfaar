typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT16 *__PST__g__16;
typedef __PST__VOID __PST__g__15(__PST__g__16);
typedef __PST__VOID __PST__g__17(void);
typedef __PST__FLOAT64 __PST__g__18(void);
typedef __PST__g__11 *__PST__g__20;
typedef volatile __PST__FLOAT64 __PST__g__21;
typedef __PST__SINT8 *__PST__g__23;
typedef volatile __PST__g__23 __PST__g__22;
typedef __PST__SINT8 __PST__g__85[2];
typedef __PST__SINT8 __PST__g__86[1];
typedef __PST__SINT8 __PST__g__87[3];
union __PST__g__43
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
union __PST__g__45
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__88[31];
typedef __PST__SINT16 __PST__g__90[1];
union __PST__g__52
  {
    __PST__g__90 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
union __PST__g__54
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__89[4027];
struct __PST__g__25
  {
    __PST__UINT16 __pst_unused_field_0;
    __PST__g__85 __pst_unused_field_1;
    __PST__UINT16 __pst_unused_field_2;
    __PST__g__85 __pst_unused_field_3;
    __PST__UINT16 CNT;
    __PST__g__85 __pst_unused_field_5;
    __PST__g__86 __pst_unused_field_6;
    __PST__g__87 __pst_unused_field_7;
    __PST__g__86 __pst_unused_field_8;
    __PST__g__87 __pst_unused_field_9;
    __PST__g__86 __pst_unused_field_10;
    __PST__g__87 __pst_unused_field_11;
    union __PST__g__43 TS;
    __PST__g__87 __pst_unused_field_13;
    union __PST__g__45 TT;
    __PST__g__87 __pst_unused_field_15;
    __PST__g__86 __pst_unused_field_16;
    __PST__g__88 __pst_unused_field_17;
    union __PST__g__52 CTL;
    __PST__g__85 __pst_unused_field_19;
    union __PST__g__54 IOC1;
    __PST__g__89 __pst_unused_field_21;
  };
typedef volatile struct __PST__g__25 __PST__g__24;
typedef __PST__UINT8 __PST__g__26[2];
union __PST__g__28
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__28 __PST__g__27;
struct __PST__g__30
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 5;
  };
typedef const struct __PST__g__30 __PST__g__29;
typedef __PST__UINT8 __PST__g__34[3];
union __PST__g__35
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__36
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
union __PST__g__39
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__39 __PST__g__38;
struct __PST__g__41
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__41 __PST__g__40;
struct __PST__g__44
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__46
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__47
  {
    __PST__g__86 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__48
  {
    __PST__UINT8 __pst_unused_field_0 : 2;
    __PST__UINT8 __pst_unused_field_1 : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef __PST__UINT8 __PST__g__51[31];
struct __PST__g__53
  {
    __PST__UINT16 __pst_unused_field_0 : 2;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_10 : 1;
  };
struct __PST__g__55
  {
    __PST__UINT8 __pst_unused_field_0 : 2;
    __PST__UINT8 __pst_unused_field_1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
  };
typedef __PST__UINT8 __PST__g__56[4027];
typedef __PST__VOID __PST__g__57(__PST__SINT32);
typedef __PST__g__24 *__PST__g__58;
typedef volatile __PST__UINT16 __PST__g__59;
typedef __PST__g__59 *__PST__g__60;
typedef volatile union __PST__g__45 __PST__g__61;
typedef __PST__g__61 *__PST__g__62;
typedef volatile __PST__UINT8 __PST__g__63;
typedef __PST__g__63 *__PST__g__64;
typedef volatile union __PST__g__52 __PST__g__65;
typedef __PST__g__65 *__PST__g__66;
typedef volatile union __PST__g__54 __PST__g__67;
typedef __PST__g__67 *__PST__g__68;
typedef volatile union __PST__g__43 __PST__g__69;
typedef __PST__g__69 *__PST__g__70;
typedef __PST__g__17 *__PST__g__71;
typedef __PST__g__15 *__PST__g__72;
typedef volatile __PST__SINT32 __PST__g__73;
typedef __PST__SINT8 __PST__g__79(void);
typedef volatile __PST__SINT8 __PST__g__80;
typedef __PST__UINT8 __PST__g__81(void);
typedef __PST__SINT32 __PST__g__82(void);
typedef __PST__UINT32 __PST__g__83(void);
typedef volatile __PST__UINT32 __PST__g__84;
