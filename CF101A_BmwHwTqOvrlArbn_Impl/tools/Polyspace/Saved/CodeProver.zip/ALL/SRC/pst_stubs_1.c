#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_BmwDrvgDynErrIfActv(void)
{
    extern __PST__UINT8 BmwHwTqOvrlArbn_Ip_BmwDrvgDynErrIfActv;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Ip_BmwDrvgDynErrIfActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrl(void)
{
    extern __PST__FLOAT32 BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrl;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrlQlfr(void)
{
    extern __PST__UINT8 BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrlQlfr;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrlQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_DrvgDynIfSt(void)
{
    extern __PST__UINT8 BmwHwTqOvrlArbn_Ip_DrvgDynIfSt;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Ip_DrvgDynIfSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_HwTqOvrlCmdEna(void)
{
    extern __PST__UINT8 BmwHwTqOvrlArbn_Ip_HwTqOvrlCmdEna;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Ip_HwTqOvrlCmdEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwHwTqOvrlArbn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnCmdErrThd(void)
{
    extern __PST__g__25 BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnCmdErrThd;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnCmdErrThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnHwTqThdY(void)
{
    extern __PST__g__26 BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnHwTqThdY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 6; _main_gen_tmp_0_0++)
            {
                /* base type */
                BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnHwTqThdY[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnOutpTqCmdLim(void)
{
    extern __PST__g__25 BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnOutpTqCmdLim;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnOutpTqCmdLim = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRampRate(void)
{
    extern __PST__g__25 BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRampRate;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRampRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRefTiThd(void)
{
    extern __PST__g__27 BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRefTiThd;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRefTiThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnVehSpdX(void)
{
    extern __PST__g__26 BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnVehSpdX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 6; _main_gen_tmp_1_0++)
            {
                /* base type */
                BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnVehSpdX[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_ArbdHwTqOvrlLtch(void)
{
    extern __PST__FLOAT32 BmwHwTqOvrlArbn_Pim_ArbdHwTqOvrlLtch;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Pim_ArbdHwTqOvrlLtch = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_FctlErrActv(void)
{
    extern __PST__UINT8 BmwHwTqOvrlArbn_Pim_FctlErrActv;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Pim_FctlErrActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_FctlErrTmr(void)
{
    extern __PST__UINT32 BmwHwTqOvrlArbn_Pim_FctlErrTmr;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Pim_FctlErrTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_HwTqOvrlScaFacStVari(void)
{
    extern __PST__FLOAT32 BmwHwTqOvrlArbn_Pim_HwTqOvrlScaFacStVari;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Pim_HwTqOvrlScaFacStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_PrevArbdHwTqOvrl(void)
{
    extern __PST__FLOAT32 BmwHwTqOvrlArbn_Pim_PrevArbdHwTqOvrl;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Pim_PrevArbdHwTqOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_PrevFctlErr(void)
{
    extern __PST__UINT8 BmwHwTqOvrlArbn_Pim_PrevFctlErr;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Pim_PrevFctlErr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwHwTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwHwTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwHwTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwHwTqOvrlArbn_Ip_BmwDrvgDynErrIfActv */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_BmwDrvgDynErrIfActv();
    
    /* init for variable BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrl */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrl();
    
    /* init for variable BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrlQlfr */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_BmwTarHwTqOvrlQlfr();
    
    /* init for variable BmwHwTqOvrlArbn_Ip_DrvgDynIfSt */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_DrvgDynIfSt();
    
    /* init for variable BmwHwTqOvrlArbn_Ip_HwTqOvrlCmdEna */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_HwTqOvrlCmdEna();
    
    /* init for variable BmwHwTqOvrlArbn_Ip_VehSpd */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Ip_VehSpd();
    
    /* init for variable BmwHwTqOvrlArbn_Op_HwTqCmdOvrl : useless (never read) */

    /* init for variable BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnCmdErrThd */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnCmdErrThd();
    
    /* init for variable BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnHwTqThdY */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnHwTqThdY();
    
    /* init for variable BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnOutpTqCmdLim */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnOutpTqCmdLim();
    
    /* init for variable BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRampRate */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRampRate();
    
    /* init for variable BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRefTiThd */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnRefTiThd();
    
    /* init for variable BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnVehSpdX */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Cal_BmwHwTqOvrlArbnVehSpdX();
    
    /* init for variable BmwHwTqOvrlArbn_Pim_ArbdHwTqOvrlLtch */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_ArbdHwTqOvrlLtch();
    
    /* init for variable BmwHwTqOvrlArbn_Pim_FctlErrActv */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_FctlErrActv();
    
    /* init for variable BmwHwTqOvrlArbn_Pim_FctlErrTmr */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_FctlErrTmr();
    
    /* init for variable BmwHwTqOvrlArbn_Pim_HwTqOvrlScaFacStVari */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_HwTqOvrlScaFacStVari();
    
    /* init for variable BmwHwTqOvrlArbn_Pim_PrevArbdHwTqOvrl */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_PrevArbdHwTqOvrl();
    
    /* init for variable BmwHwTqOvrlArbn_Pim_PrevFctlErr */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Pim_PrevFctlErr();
    
    /* init for variable BmwHwTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwHwTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwHwTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwHwTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
