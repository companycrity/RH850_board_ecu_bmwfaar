#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_PwrLimr_Ip_AltFltActv(void)
{
    extern __PST__UINT8 PwrLimr_Ip_AltFltActv;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_AltFltActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_BrdgVltg(void)
{
    extern __PST__FLOAT32 PwrLimr_Ip_BrdgVltg;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_BrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_DualEcuFltMtgtnSca(void)
{
    extern __PST__FLOAT32 PwrLimr_Ip_DualEcuFltMtgtnSca;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_DualEcuFltMtgtnSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 PwrLimr_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_MotBackEmfConEstimd(void)
{
    extern __PST__FLOAT32 PwrLimr_Ip_MotBackEmfConEstimd;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_MotBackEmfConEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_MotTqCmdMrf(void)
{
    extern __PST__FLOAT32 PwrLimr_Ip_MotTqCmdMrf;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_MotTqCmdMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_MotVelMrf(void)
{
    extern __PST__FLOAT32 PwrLimr_Ip_MotVelMrf;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_MotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Ip_SplyCurrLim(void)
{
    extern __PST__FLOAT32 PwrLimr_Ip_SplyCurrLim;
    
    /* initialization with random value */
    {
        PwrLimr_Ip_SplyCurrLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrAssiRednLpFilFrq(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrAssiRednLpFilFrq;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrAssiRednLpFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrBackEmfConStdT(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrBackEmfConStdT;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrBackEmfConStdT = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrBrdgVltgAdjSlew(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrBrdgVltgAdjSlew;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrBrdgVltgAdjSlew = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrBrdgVltgAltFltAdj(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrBrdgVltgAltFltAdj;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrBrdgVltgAltFltAdj = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrFilAssiRednThd(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrFilAssiRednThd;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrFilAssiRednThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrLoVoltAssiRcvrThd(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrLoVoltAssiRcvrThd;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrLoVoltAssiRcvrThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrLoVoltAssiRcvrTi(void)
{
    extern __PST__g__27 PwrLimr_Cal_PwrLimrLoVoltAssiRcvrTi;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrLoVoltAssiRcvrTi = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrMotEnvlpX(void)
{
    extern __PST__g__28 PwrLimr_Cal_PwrLimrMotEnvlpX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 14; _main_gen_tmp_1_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrMotEnvlpX[_main_gen_tmp_1_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrMotEnvlpY(void)
{
    extern __PST__g__30 PwrLimr_Cal_PwrLimrMotEnvlpY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 14; _main_gen_tmp_2_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrMotEnvlpY[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrMotVelLpFilFrq(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrMotVelLpFilFrq;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrMotVelLpFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrSpdAdjSlewDec(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrSpdAdjSlewDec;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrSpdAdjSlewDec = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrSpdAdjSlewEna(void)
{
    extern __PST__g__31 PwrLimr_Cal_PwrLimrSpdAdjSlewEna;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrSpdAdjSlewEna = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrSpdAdjSlewInc(void)
{
    extern __PST__g__26 PwrLimr_Cal_PwrLimrSpdAdjSlewInc;
    
    /* initialization with random value */
    {
        PwrLimr_Cal_PwrLimrSpdAdjSlewInc = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrSplyCurrLimTblX(void)
{
    extern __PST__g__32 PwrLimr_Cal_PwrLimrSplyCurrLimTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 10; _main_gen_tmp_3_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrSplyCurrLimTblX[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrSplyCurrLimTblY(void)
{
    extern __PST__g__32 PwrLimr_Cal_PwrLimrSplyCurrLimTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 10; _main_gen_tmp_4_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrSplyCurrLimTblY[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrStdOperMotEnvlpX(void)
{
    extern __PST__g__33 PwrLimr_Cal_PwrLimrStdOperMotEnvlpX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 6; _main_gen_tmp_5_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrStdOperMotEnvlpX[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrStdOperMotEnvlpY(void)
{
    extern __PST__g__33 PwrLimr_Cal_PwrLimrStdOperMotEnvlpY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 6; _main_gen_tmp_6_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrStdOperMotEnvlpY[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrVltgDptMotVelOffsX(void)
{
    extern __PST__g__32 PwrLimr_Cal_PwrLimrVltgDptMotVelOffsX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 10; _main_gen_tmp_7_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrVltgDptMotVelOffsX[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Cal_PwrLimrVltgDptMotVelOffsY(void)
{
    extern __PST__g__32 PwrLimr_Cal_PwrLimrVltgDptMotVelOffsY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 10; _main_gen_tmp_8_0++)
            {
                /* base type */
                PwrLimr_Cal_PwrLimrVltgDptMotVelOffsY[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_BrdgVltgRateLim(void)
{
    extern __PST__FLOAT32 PwrLimr_Pim_BrdgVltgRateLim;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_BrdgVltgRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_LimdAssiLoVltgPrev(void)
{
    extern __PST__UINT8 PwrLimr_Pim_LimdAssiLoVltgPrev;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_LimdAssiLoVltgPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_MotVelLpFil(void)
{
    extern struct __PST__g__34 PwrLimr_Pim_MotVelLpFil;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_MotVelLpFil = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_OutpVelOffsRateLimd(void)
{
    extern __PST__FLOAT32 PwrLimr_Pim_OutpVelOffsRateLimd;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_OutpVelOffsRateLimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_RefTmr(void)
{
    extern __PST__UINT32 PwrLimr_Pim_RefTmr;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_RefTmrPrev(void)
{
    extern __PST__UINT32 PwrLimr_Pim_RefTmrPrev;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_RefTmrPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PwrLimr_Pim_TqLimLpFil(void)
{
    extern struct __PST__g__34 PwrLimr_Pim_TqLimLpFil;
    
    /* initialization with random value */
    {
        PwrLimr_Pim_TqLimLpFil = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_PwrLimr_Irv_MinStdOperLim(void)
{
    extern __PST__FLOAT32 PwrLimr_Irv_MinStdOperLim;
    
    /* initialization with random value */
    {
        PwrLimr_Irv_MinStdOperLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Irv_MotEnvlpSpd(void)
{
    extern __PST__FLOAT32 PwrLimr_Irv_MotEnvlpSpd;
    
    /* initialization with random value */
    {
        PwrLimr_Irv_MotEnvlpSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrLimr_Irv_TqEnvlpLim1(void)
{
    extern __PST__FLOAT32 PwrLimr_Irv_TqEnvlpLim1;
    
    /* initialization with random value */
    {
        PwrLimr_Irv_TqEnvlpLim1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ELECGLBPRM_IVTRCNT_CNT_U08(void)
{
    extern __PST__UINT8 ELECGLBPRM_IVTRCNT_CNT_U08;
    
    /* initialization with random value */
    {
        ELECGLBPRM_IVTRCNT_CNT_U08 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrLimr_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 PwrLimr_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        PwrLimr_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PwrLimr_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 PwrLimr_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        PwrLimr_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PwrLimr_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 PwrLimr_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        PwrLimr_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable PwrLimr_Ip_AltFltActv */
    _main_gen_init_sym_PwrLimr_Ip_AltFltActv();
    
    /* init for variable PwrLimr_Ip_BrdgVltg */
    _main_gen_init_sym_PwrLimr_Ip_BrdgVltg();
    
    /* init for variable PwrLimr_Ip_DualEcuFltMtgtnSca */
    _main_gen_init_sym_PwrLimr_Ip_DualEcuFltMtgtnSca();
    
    /* init for variable PwrLimr_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_PwrLimr_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable PwrLimr_Ip_MotBackEmfConEstimd */
    _main_gen_init_sym_PwrLimr_Ip_MotBackEmfConEstimd();
    
    /* init for variable PwrLimr_Ip_MotTqCmdMrf */
    _main_gen_init_sym_PwrLimr_Ip_MotTqCmdMrf();
    
    /* init for variable PwrLimr_Ip_MotVelMrf */
    _main_gen_init_sym_PwrLimr_Ip_MotVelMrf();
    
    /* init for variable PwrLimr_Ip_SplyCurrLim */
    _main_gen_init_sym_PwrLimr_Ip_SplyCurrLim();
    
    /* init for variable PwrLimr_Op_MotTqCmdPwrLimd : useless (never read) */

    /* init for variable PwrLimr_Op_PwrLimrRednFac : useless (never read) */

    /* init for variable PwrLimr_Cal_PwrLimrAssiRednLpFilFrq */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrAssiRednLpFilFrq();
    
    /* init for variable PwrLimr_Cal_PwrLimrBackEmfConStdT */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrBackEmfConStdT();
    
    /* init for variable PwrLimr_Cal_PwrLimrBrdgVltgAdjSlew */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrBrdgVltgAdjSlew();
    
    /* init for variable PwrLimr_Cal_PwrLimrBrdgVltgAltFltAdj */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrBrdgVltgAltFltAdj();
    
    /* init for variable PwrLimr_Cal_PwrLimrFilAssiRednThd */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrFilAssiRednThd();
    
    /* init for variable PwrLimr_Cal_PwrLimrLoVoltAssiRcvrThd */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrLoVoltAssiRcvrThd();
    
    /* init for variable PwrLimr_Cal_PwrLimrLoVoltAssiRcvrTi */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrLoVoltAssiRcvrTi();
    
    /* init for variable PwrLimr_Cal_PwrLimrMotEnvlpX */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrMotEnvlpX();
    
    /* init for variable PwrLimr_Cal_PwrLimrMotEnvlpY */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrMotEnvlpY();
    
    /* init for variable PwrLimr_Cal_PwrLimrMotVelLpFilFrq */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrMotVelLpFilFrq();
    
    /* init for variable PwrLimr_Cal_PwrLimrSpdAdjSlewDec */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrSpdAdjSlewDec();
    
    /* init for variable PwrLimr_Cal_PwrLimrSpdAdjSlewEna */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrSpdAdjSlewEna();
    
    /* init for variable PwrLimr_Cal_PwrLimrSpdAdjSlewInc */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrSpdAdjSlewInc();
    
    /* init for variable PwrLimr_Cal_PwrLimrSplyCurrLimTblX */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrSplyCurrLimTblX();
    
    /* init for variable PwrLimr_Cal_PwrLimrSplyCurrLimTblY */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrSplyCurrLimTblY();
    
    /* init for variable PwrLimr_Cal_PwrLimrStdOperMotEnvlpX */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrStdOperMotEnvlpX();
    
    /* init for variable PwrLimr_Cal_PwrLimrStdOperMotEnvlpY */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrStdOperMotEnvlpY();
    
    /* init for variable PwrLimr_Cal_PwrLimrVltgDptMotVelOffsX */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrVltgDptMotVelOffsX();
    
    /* init for variable PwrLimr_Cal_PwrLimrVltgDptMotVelOffsY */
    _main_gen_init_sym_PwrLimr_Cal_PwrLimrVltgDptMotVelOffsY();
    
    /* init for variable PwrLimr_Pim_dPwrLimrFildMotVel : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrLimDif : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrMinStdOperLim : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrMotEnvlpSpd : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrMotTqCmdIvtrLoaSca : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrOutpVelOffs : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrSpdAdj : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrSplyCurrLimOffs : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrTLimMaxCurr : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrTqEnvlpLim1 : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrTqEnvlpLim4 : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrTqLim : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrTqLim1 : useless (never read) */

    /* init for variable PwrLimr_Pim_dPwrLimrTqLim4 : useless (never read) */

    /* init for variable PwrLimr_Pim_BrdgVltgRateLim */
    _main_gen_init_sym_PwrLimr_Pim_BrdgVltgRateLim();
    
    /* init for variable PwrLimr_Pim_LimdAssiLoVltgPrev */
    _main_gen_init_sym_PwrLimr_Pim_LimdAssiLoVltgPrev();
    
    /* init for variable PwrLimr_Pim_MotVelLpFil */
    _main_gen_init_sym_PwrLimr_Pim_MotVelLpFil();
    
    /* init for variable PwrLimr_Pim_OutpVelOffsRateLimd */
    _main_gen_init_sym_PwrLimr_Pim_OutpVelOffsRateLimd();
    
    /* init for variable PwrLimr_Pim_RefTmr */
    _main_gen_init_sym_PwrLimr_Pim_RefTmr();
    
    /* init for variable PwrLimr_Pim_RefTmrPrev */
    _main_gen_init_sym_PwrLimr_Pim_RefTmrPrev();
    
    /* init for variable PwrLimr_Pim_TqLimLpFil */
    _main_gen_init_sym_PwrLimr_Pim_TqLimLpFil();
    
    /* init for variable PwrLimr_Irv_MinStdOperLim */
    _main_gen_init_sym_PwrLimr_Irv_MinStdOperLim();
    
    /* init for variable PwrLimr_Irv_MotEnvlpSpd */
    _main_gen_init_sym_PwrLimr_Irv_MotEnvlpSpd();
    
    /* init for variable PwrLimr_Irv_TqEnvlpLim1 */
    _main_gen_init_sym_PwrLimr_Irv_TqEnvlpLim1();
    
    /* init for variable ELECGLBPRM_IVTRCNT_CNT_U08 */
    _main_gen_init_sym_ELECGLBPRM_IVTRCNT_CNT_U08();
    
    /* init for variable PwrLimr_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_PwrLimr_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable PwrLimr_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable PwrLimr_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_PwrLimr_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable PwrLimr_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable PwrLimr_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable PwrLimr_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable PwrLimr_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable PwrLimr_Srv_SetNtcSts_Return */
    _main_gen_init_sym_PwrLimr_Srv_SetNtcSts_Return();
    
}
