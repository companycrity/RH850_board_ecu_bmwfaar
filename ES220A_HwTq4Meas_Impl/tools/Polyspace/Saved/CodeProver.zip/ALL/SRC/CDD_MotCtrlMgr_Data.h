/* header file for contract folder of ES220A */

#ifndef CDD_MOTCTRLMGR_DATA_H
#define CDD_MOTCTRLMGR_DATA_H

extern float32  MOTCTRLMGR_MotCtrlHwTq4RawFastAdc;
extern float32  MOTCTRLMGR_MotCtrlHwTq4RawFastAdcBuf[8];

#endif

