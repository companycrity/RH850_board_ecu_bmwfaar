#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_EpsStEstimn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 EpsStEstimn_Ip_HwTq;
    
    /* initialization with random value */
    {
        EpsStEstimn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EpsStEstimn_Ip_MotTqEstimd(void)
{
    extern __PST__FLOAT32 EpsStEstimn_Ip_MotTqEstimd;
    
    /* initialization with random value */
    {
        EpsStEstimn_Ip_MotTqEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EpsStEstimn_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 EpsStEstimn_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        EpsStEstimn_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EpsStEstimn_Ip_PinionTqToRackFInstsRat(void)
{
    extern __PST__FLOAT32 EpsStEstimn_Ip_PinionTqToRackFInstsRat;
    
    /* initialization with random value */
    {
        EpsStEstimn_Ip_PinionTqToRackFInstsRat = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EpsStEstimn_Ip_SysKineRat(void)
{
    extern __PST__FLOAT32 EpsStEstimn_Ip_SysKineRat;
    
    /* initialization with random value */
    {
        EpsStEstimn_Ip_SysKineRat = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EpsStEstimn_Ip_SysTqRat(void)
{
    extern __PST__FLOAT32 EpsStEstimn_Ip_SysTqRat;
    
    /* initialization with random value */
    {
        EpsStEstimn_Ip_SysTqRat = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxA(void)
{
    extern __PST__g__24 EpsStEstimn_Cal_EpsStEstimnMtrxA;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 5; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 5; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    EpsStEstimn_Cal_EpsStEstimnMtrxA[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxB(void)
{
    extern __PST__g__27 EpsStEstimn_Cal_EpsStEstimnMtrxB;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 3; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 5; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    EpsStEstimn_Cal_EpsStEstimnMtrxB[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxC(void)
{
    extern __PST__g__24 EpsStEstimn_Cal_EpsStEstimnMtrxC;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 5; _main_gen_tmp_2_0++)
            {
                __PST__UINT32 _main_gen_tmp_2_1;
                
                for (_main_gen_tmp_2_1 = 0; _main_gen_tmp_2_1 < 5; _main_gen_tmp_2_1++)
                {
                    /* base type */
                    EpsStEstimn_Cal_EpsStEstimnMtrxC[_main_gen_tmp_2_0][_main_gen_tmp_2_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxD(void)
{
    extern __PST__g__27 EpsStEstimn_Cal_EpsStEstimnMtrxD;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 3; _main_gen_tmp_3_0++)
            {
                __PST__UINT32 _main_gen_tmp_3_1;
                
                for (_main_gen_tmp_3_1 = 0; _main_gen_tmp_3_1 < 5; _main_gen_tmp_3_1++)
                {
                    /* base type */
                    EpsStEstimn_Cal_EpsStEstimnMtrxD[_main_gen_tmp_3_0][_main_gen_tmp_3_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EpsStEstimn_Pim_StEstimrStPrev(void)
{
    extern __PST__g__17 EpsStEstimn_Pim_StEstimrStPrev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 5; _main_gen_tmp_4_0++)
            {
                /* base type */
                EpsStEstimn_Pim_StEstimrStPrev[_main_gen_tmp_4_0] = pst_random_g_10;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable EpsStEstimn_Ip_HwTq */
    _main_gen_init_sym_EpsStEstimn_Ip_HwTq();
    
    /* init for variable EpsStEstimn_Ip_MotTqEstimd */
    _main_gen_init_sym_EpsStEstimn_Ip_MotTqEstimd();
    
    /* init for variable EpsStEstimn_Ip_MotVelCrf */
    _main_gen_init_sym_EpsStEstimn_Ip_MotVelCrf();
    
    /* init for variable EpsStEstimn_Ip_PinionTqToRackFInstsRat */
    _main_gen_init_sym_EpsStEstimn_Ip_PinionTqToRackFInstsRat();
    
    /* init for variable EpsStEstimn_Ip_SysKineRat */
    _main_gen_init_sym_EpsStEstimn_Ip_SysKineRat();
    
    /* init for variable EpsStEstimn_Ip_SysTqRat */
    _main_gen_init_sym_EpsStEstimn_Ip_SysTqRat();
    
    /* init for variable EpsStEstimn_Op_RackFEstimd : useless (never read) */

    /* init for variable EpsStEstimn_Op_TorsBarStEstimd : useless (never read) */

    /* init for variable EpsStEstimn_Cal_EpsStEstimnMtrxA */
    _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxA();
    
    /* init for variable EpsStEstimn_Cal_EpsStEstimnMtrxB */
    _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxB();
    
    /* init for variable EpsStEstimn_Cal_EpsStEstimnMtrxC */
    _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxC();
    
    /* init for variable EpsStEstimn_Cal_EpsStEstimnMtrxD */
    _main_gen_init_sym_EpsStEstimn_Cal_EpsStEstimnMtrxD();
    
    /* init for variable EpsStEstimn_Pim_StEstimrStPrev */
    _main_gen_init_sym_EpsStEstimn_Pim_StEstimrStPrev();
    
}
