#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__54 _main_gen_init_g54(void);

extern __PST__g__53 _main_gen_init_g53(void);

extern __PST__g__52 _main_gen_init_g52(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__52 _main_gen_init_g52(void)
{
    __PST__g__52 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__53 _main_gen_init_g53(void)
{
    __PST__g__53 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__54 _main_gen_init_g54(void)
{
    __PST__g__54 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_PhaDiscnct_Ip_DiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 PhaDiscnct_Ip_DiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_DiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_IvtrFetFltPha(void)
{
    extern __PST__UINT8 PhaDiscnct_Ip_IvtrFetFltPha;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_IvtrFetFltPha = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_IvtrFetFltTyp(void)
{
    extern __PST__UINT8 PhaDiscnct_Ip_IvtrFetFltTyp;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_IvtrFetFltTyp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_MotCurrCorrdA(void)
{
    extern __PST__FLOAT32 PhaDiscnct_Ip_MotCurrCorrdA;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_MotCurrCorrdA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_MotCurrCorrdB(void)
{
    extern __PST__FLOAT32 PhaDiscnct_Ip_MotCurrCorrdB;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_MotCurrCorrdB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_MotCurrCorrdC(void)
{
    extern __PST__FLOAT32 PhaDiscnct_Ip_MotCurrCorrdC;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_MotCurrCorrdC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_MotCurrQlfr1(void)
{
    extern __PST__UINT8 PhaDiscnct_Ip_MotCurrQlfr1;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_MotCurrQlfr1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_StrtUpSt(void)
{
    extern __PST__UINT8 PhaDiscnct_Ip_StrtUpSt;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_StrtUpSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Ip_SysSt(void)
{
    extern __PST__UINT8 PhaDiscnct_Ip_SysSt;
    
    /* initialization with random value */
    {
        PhaDiscnct_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctClsDlyTi(void)
{
    extern __PST__g__52 PhaDiscnct_Cal_PhaDiscnctClsDlyTi;
    
    /* initialization with random value */
    {
        PhaDiscnct_Cal_PhaDiscnctClsDlyTi = _main_gen_init_g52();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctOpenDlyTi(void)
{
    extern __PST__g__52 PhaDiscnct_Cal_PhaDiscnctOpenDlyTi;
    
    /* initialization with random value */
    {
        PhaDiscnct_Cal_PhaDiscnctOpenDlyTi = _main_gen_init_g52();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestCurrTestVal(void)
{
    extern __PST__g__53 PhaDiscnct_Cal_PhaDiscnctTestCurrTestVal;
    
    /* initialization with random value */
    {
        PhaDiscnct_Cal_PhaDiscnctTestCurrTestVal = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestFailScanMax(void)
{
    extern __PST__g__54 PhaDiscnct_Cal_PhaDiscnctTestFailScanMax;
    
    /* initialization with random value */
    {
        PhaDiscnct_Cal_PhaDiscnctTestFailScanMax = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestIninScan(void)
{
    extern __PST__g__54 PhaDiscnct_Cal_PhaDiscnctTestIninScan;
    
    /* initialization with random value */
    {
        PhaDiscnct_Cal_PhaDiscnctTestIninScan = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestScanCnt(void)
{
    extern __PST__g__54 PhaDiscnct_Cal_PhaDiscnctTestScanCnt;
    
    /* initialization with random value */
    {
        PhaDiscnct_Cal_PhaDiscnctTestScanCnt = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctClsTmr(void)
{
    extern __PST__UINT32 PhaDiscnct_Pim_DiscnctClsTmr;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctClsTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagCurrComp(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctDiagCurrComp;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctDiagCurrComp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagFailScan(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctDiagFailScan;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctDiagFailScan = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagFltSts(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctDiagFltSts;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctDiagFltSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagItrn(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctDiagItrn;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctDiagItrn = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagSt(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctDiagSt;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctDiagSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagTestScan(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctDiagTestScan;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctDiagTestScan = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctFltPrm(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctFltPrm;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctFltPrm = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctOpenTmr(void)
{
    extern __PST__UINT32 PhaDiscnct_Pim_DiscnctOpenTmr;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctOpenTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_DiscnctSt(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_DiscnctSt;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_DiscnctSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_PrevDiscnctCmd(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_PrevDiscnctCmd;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_PrevDiscnctCmd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Pim_WrmIninTestCmpl(void)
{
    extern __PST__UINT8 PhaDiscnct_Pim_WrmIninTestCmpl;
    
    /* initialization with random value */
    {
        PhaDiscnct_Pim_WrmIninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NXTRMATH_SINCNVNCONTBL_ULS_U16(void)
{
    extern __PST__g__55 NXTRMATH_SINCNVNCONTBL_ULS_U16;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 513; _main_gen_tmp_11_0++)
            {
                /* base type */
                NXTRMATH_SINCNVNCONTBL_ULS_U16[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PhaDiscnct_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 PhaDiscnct_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        PhaDiscnct_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_Return(void)
{
    extern __PST__UINT8 PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_Return;
    
    /* initialization with random value */
    {
        PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PhaDiscnct_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 PhaDiscnct_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        PhaDiscnct_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable PhaDiscnct_Ip_DiagcStsIvtr1Inactv */
    _main_gen_init_sym_PhaDiscnct_Ip_DiagcStsIvtr1Inactv();
    
    /* init for variable PhaDiscnct_Ip_IvtrFetFltPha */
    _main_gen_init_sym_PhaDiscnct_Ip_IvtrFetFltPha();
    
    /* init for variable PhaDiscnct_Ip_IvtrFetFltTyp */
    _main_gen_init_sym_PhaDiscnct_Ip_IvtrFetFltTyp();
    
    /* init for variable PhaDiscnct_Ip_MotCurrCorrdA */
    _main_gen_init_sym_PhaDiscnct_Ip_MotCurrCorrdA();
    
    /* init for variable PhaDiscnct_Ip_MotCurrCorrdB */
    _main_gen_init_sym_PhaDiscnct_Ip_MotCurrCorrdB();
    
    /* init for variable PhaDiscnct_Ip_MotCurrCorrdC */
    _main_gen_init_sym_PhaDiscnct_Ip_MotCurrCorrdC();
    
    /* init for variable PhaDiscnct_Ip_MotCurrQlfr1 */
    _main_gen_init_sym_PhaDiscnct_Ip_MotCurrQlfr1();
    
    /* init for variable PhaDiscnct_Ip_StrtUpSt */
    _main_gen_init_sym_PhaDiscnct_Ip_StrtUpSt();
    
    /* init for variable PhaDiscnct_Ip_SysSt */
    _main_gen_init_sym_PhaDiscnct_Ip_SysSt();
    
    /* init for variable PhaDiscnct_Op_PhaDiscnctDiagcActv : useless (never read) */

    /* init for variable PhaDiscnct_Op_PhaDiscnctDiagcPwmVect : useless (never read) */

    /* init for variable PhaDiscnct_Op_PhaDiscnctInactv : useless (never read) */

    /* init for variable PhaDiscnct_Op_PhaDiscnctWrmIninTestCmpl : useless (never read) */

    /* init for variable PhaDiscnct_Cal_PhaDiscnctClsDlyTi */
    _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctClsDlyTi();
    
    /* init for variable PhaDiscnct_Cal_PhaDiscnctOpenDlyTi */
    _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctOpenDlyTi();
    
    /* init for variable PhaDiscnct_Cal_PhaDiscnctTestCurrTestVal */
    _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestCurrTestVal();
    
    /* init for variable PhaDiscnct_Cal_PhaDiscnctTestFailScanMax */
    _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestFailScanMax();
    
    /* init for variable PhaDiscnct_Cal_PhaDiscnctTestIninScan */
    _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestIninScan();
    
    /* init for variable PhaDiscnct_Cal_PhaDiscnctTestScanCnt */
    _main_gen_init_sym_PhaDiscnct_Cal_PhaDiscnctTestScanCnt();
    
    /* init for variable PhaDiscnct_Pim_dPhaDiscnctActvd : useless (never read) */

    /* init for variable PhaDiscnct_Pim_dPhaDiscnctCmd : useless (never read) */

    /* init for variable PhaDiscnct_Pim_DiscnctClsTmr */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctClsTmr();
    
    /* init for variable PhaDiscnct_Pim_DiscnctDiagCurrComp */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagCurrComp();
    
    /* init for variable PhaDiscnct_Pim_DiscnctDiagFailScan */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagFailScan();
    
    /* init for variable PhaDiscnct_Pim_DiscnctDiagFltSts */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagFltSts();
    
    /* init for variable PhaDiscnct_Pim_DiscnctDiagItrn */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagItrn();
    
    /* init for variable PhaDiscnct_Pim_DiscnctDiagSt */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagSt();
    
    /* init for variable PhaDiscnct_Pim_DiscnctDiagTestScan */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctDiagTestScan();
    
    /* init for variable PhaDiscnct_Pim_DiscnctFltPrm */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctFltPrm();
    
    /* init for variable PhaDiscnct_Pim_DiscnctOpenTmr */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctOpenTmr();
    
    /* init for variable PhaDiscnct_Pim_DiscnctSt */
    _main_gen_init_sym_PhaDiscnct_Pim_DiscnctSt();
    
    /* init for variable PhaDiscnct_Pim_PrevDiscnctCmd */
    _main_gen_init_sym_PhaDiscnct_Pim_PrevDiscnctCmd();
    
    /* init for variable PhaDiscnct_Pim_WrmIninTestCmpl */
    _main_gen_init_sym_PhaDiscnct_Pim_WrmIninTestCmpl();
    
    /* init for variable NXTRMATH_SINCNVNCONTBL_ULS_U16 */
    _main_gen_init_sym_NXTRMATH_SINCNVNCONTBL_ULS_U16();
    
    /* init for variable PhaDiscnct_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_PhaDiscnct_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_Return */
    _main_gen_init_sym_PhaDiscnct_Srv_GetTiSpan100MicroSec32bit_Return();
    
    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable PhaDiscnct_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_PhaDiscnct_Srv_SetNtcStsAndSnpshtData_Return();
    
}
