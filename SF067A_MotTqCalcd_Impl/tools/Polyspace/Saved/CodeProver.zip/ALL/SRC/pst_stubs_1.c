#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__22 _main_gen_init_g22(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotTqCalcd_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 MotTqCalcd_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotBackEmfConEstimd(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotBackEmfConEstimd;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotBackEmfConEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotCurrDax(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotCurrDax;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotCurrDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotCurrDaxCmd(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotCurrDaxCmd;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotCurrDaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotCurrQax(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotCurrQax;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotCurrQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotCurrQaxCmd(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotCurrQaxCmd;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotCurrQaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotInduDaxEstimd(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotInduDaxEstimd;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotInduDaxEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Ip_MotInduQaxEstimd(void)
{
    extern __PST__FLOAT32 MotTqCalcd_Ip_MotInduQaxEstimd;
    
    /* initialization with random value */
    {
        MotTqCalcd_Ip_MotInduQaxEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotTqCalcd_Cal_SysGlbPrmMotPoleCnt(void)
{
    extern __PST__g__22 MotTqCalcd_Cal_SysGlbPrmMotPoleCnt;
    
    /* initialization with random value */
    {
        MotTqCalcd_Cal_SysGlbPrmMotPoleCnt = _main_gen_init_g22();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotTqCalcd_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_MotTqCalcd_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable MotTqCalcd_Ip_MotBackEmfConEstimd */
    _main_gen_init_sym_MotTqCalcd_Ip_MotBackEmfConEstimd();
    
    /* init for variable MotTqCalcd_Ip_MotCurrDax */
    _main_gen_init_sym_MotTqCalcd_Ip_MotCurrDax();
    
    /* init for variable MotTqCalcd_Ip_MotCurrDaxCmd */
    _main_gen_init_sym_MotTqCalcd_Ip_MotCurrDaxCmd();
    
    /* init for variable MotTqCalcd_Ip_MotCurrQax */
    _main_gen_init_sym_MotTqCalcd_Ip_MotCurrQax();
    
    /* init for variable MotTqCalcd_Ip_MotCurrQaxCmd */
    _main_gen_init_sym_MotTqCalcd_Ip_MotCurrQaxCmd();
    
    /* init for variable MotTqCalcd_Ip_MotInduDaxEstimd */
    _main_gen_init_sym_MotTqCalcd_Ip_MotInduDaxEstimd();
    
    /* init for variable MotTqCalcd_Ip_MotInduQaxEstimd */
    _main_gen_init_sym_MotTqCalcd_Ip_MotInduQaxEstimd();
    
    /* init for variable MotTqCalcd_Op_MotTqEstimd : useless (never read) */

    /* init for variable MotTqCalcd_Cal_SysGlbPrmMotPoleCnt */
    _main_gen_init_sym_MotTqCalcd_Cal_SysGlbPrmMotPoleCnt();
    
}
