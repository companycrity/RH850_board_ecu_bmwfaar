#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ClsdLoopDampg_Ip_DampgCmdSca(void)
{
    extern __PST__FLOAT32 ClsdLoopDampg_Ip_DampgCmdSca;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_DampgCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Ip_EotCtrlSca(void)
{
    extern __PST__FLOAT32 ClsdLoopDampg_Ip_EotCtrlSca;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_EotCtrlSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Ip_EotDeltaAg(void)
{
    extern __PST__FLOAT32 ClsdLoopDampg_Ip_EotDeltaAg;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_EotDeltaAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Ip_EotSt(void)
{
    extern __PST__UINT8 ClsdLoopDampg_Ip_EotSt;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_EotSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Ip_PinionVel(void)
{
    extern __PST__FLOAT32 ClsdLoopDampg_Ip_PinionVel;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_PinionVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Ip_RackFEstimd(void)
{
    extern __PST__FLOAT32 ClsdLoopDampg_Ip_RackFEstimd;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_RackFEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 ClsdLoopDampg_Ip_VehSpd;
    
    /* initialization with random value */
    {
        ClsdLoopDampg_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrX(void)
{
    extern __PST__g__22 ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 4; _main_gen_tmp_0_0++)
            {
                /* base type */
                ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrX[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrY(void)
{
    extern __PST__g__22 ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 4; _main_gen_tmp_1_0++)
            {
                /* base type */
                ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrY[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotExitX(void)
{
    extern __PST__g__22 ClsdLoopDampg_Cal_ClsdLoopDampgEotExitX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                ClsdLoopDampg_Cal_ClsdLoopDampgEotExitX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotExitY(void)
{
    extern __PST__g__22 ClsdLoopDampg_Cal_ClsdLoopDampgEotExitY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 4; _main_gen_tmp_3_0++)
            {
                /* base type */
                ClsdLoopDampg_Cal_ClsdLoopDampgEotExitY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelX(void)
{
    extern __PST__g__24 ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 9; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 12; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelX[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelY(void)
{
    extern __PST__g__24 ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 9; _main_gen_tmp_5_0++)
            {
                __PST__UINT32 _main_gen_tmp_5_1;
                
                for (_main_gen_tmp_5_1 = 0; _main_gen_tmp_5_1 < 12; _main_gen_tmp_5_1++)
                {
                    /* base type */
                    ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelY[_main_gen_tmp_5_0][_main_gen_tmp_5_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgRackFX(void)
{
    extern __PST__g__24 ClsdLoopDampg_Cal_ClsdLoopDampgRackFX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 9; _main_gen_tmp_6_0++)
            {
                __PST__UINT32 _main_gen_tmp_6_1;
                
                for (_main_gen_tmp_6_1 = 0; _main_gen_tmp_6_1 < 12; _main_gen_tmp_6_1++)
                {
                    /* base type */
                    ClsdLoopDampg_Cal_ClsdLoopDampgRackFX[_main_gen_tmp_6_0][_main_gen_tmp_6_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgRackFY(void)
{
    extern __PST__g__24 ClsdLoopDampg_Cal_ClsdLoopDampgRackFY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 9; _main_gen_tmp_7_0++)
            {
                __PST__UINT32 _main_gen_tmp_7_1;
                
                for (_main_gen_tmp_7_1 = 0; _main_gen_tmp_7_1 < 12; _main_gen_tmp_7_1++)
                {
                    /* base type */
                    ClsdLoopDampg_Cal_ClsdLoopDampgRackFY[_main_gen_tmp_7_0][_main_gen_tmp_7_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopDampg_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__25 ClsdLoopDampg_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 12; _main_gen_tmp_8_0++)
            {
                /* base type */
                ClsdLoopDampg_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ClsdLoopDampg_Ip_DampgCmdSca */
    _main_gen_init_sym_ClsdLoopDampg_Ip_DampgCmdSca();
    
    /* init for variable ClsdLoopDampg_Ip_EotCtrlSca */
    _main_gen_init_sym_ClsdLoopDampg_Ip_EotCtrlSca();
    
    /* init for variable ClsdLoopDampg_Ip_EotDeltaAg */
    _main_gen_init_sym_ClsdLoopDampg_Ip_EotDeltaAg();
    
    /* init for variable ClsdLoopDampg_Ip_EotSt */
    _main_gen_init_sym_ClsdLoopDampg_Ip_EotSt();
    
    /* init for variable ClsdLoopDampg_Ip_PinionVel */
    _main_gen_init_sym_ClsdLoopDampg_Ip_PinionVel();
    
    /* init for variable ClsdLoopDampg_Ip_RackFEstimd */
    _main_gen_init_sym_ClsdLoopDampg_Ip_RackFEstimd();
    
    /* init for variable ClsdLoopDampg_Ip_VehSpd */
    _main_gen_init_sym_ClsdLoopDampg_Ip_VehSpd();
    
    /* init for variable ClsdLoopDampg_Op_HwTqCmdDampg : useless (never read) */

    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrX */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrX();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrY */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotEntrY();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgEotExitX */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotExitX();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgEotExitY */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgEotExitY();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelX */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelX();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelY */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgPinionVelY();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgRackFX */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgRackFX();
    
    /* init for variable ClsdLoopDampg_Cal_ClsdLoopDampgRackFY */
    _main_gen_init_sym_ClsdLoopDampg_Cal_ClsdLoopDampgRackFY();
    
    /* init for variable ClsdLoopDampg_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_ClsdLoopDampg_Cal_SysGlbPrmVehSpdBilnrSeln();
    
}
