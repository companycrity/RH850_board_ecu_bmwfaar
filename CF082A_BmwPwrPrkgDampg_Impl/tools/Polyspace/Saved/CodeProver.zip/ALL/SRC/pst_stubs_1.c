#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwPwrPrkgDampg_Ip_DampgCmdBas(void)
{
    extern __PST__FLOAT32 BmwPwrPrkgDampg_Ip_DampgCmdBas;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Ip_DampgCmdBas = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Ip_DampgCmdPwrPrkgEna(void)
{
    extern __PST__UINT8 BmwPwrPrkgDampg_Ip_DampgCmdPwrPrkgEna;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Ip_DampgCmdPwrPrkgEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Ip_HwVel(void)
{
    extern __PST__FLOAT32 BmwPwrPrkgDampg_Ip_HwVel;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Ip_PinionAg(void)
{
    extern __PST__FLOAT32 BmwPwrPrkgDampg_Ip_PinionAg;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Ip_PinionAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Ip_PinionAgConf(void)
{
    extern __PST__FLOAT32 BmwPwrPrkgDampg_Ip_PinionAgConf;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Ip_PinionAgConf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwPwrPrkgDampg_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgBasPwrPrkgDampgY(void)
{
    extern __PST__g__22 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgBasPwrPrkgDampgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 9; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 9; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgBasPwrPrkgDampgY[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgDiScadDampg(void)
{
    extern __PST__g__25 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgDiScadDampg;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgDiScadDampg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgHwVelTblX(void)
{
    extern __PST__g__23 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgHwVelTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 9; _main_gen_tmp_1_0++)
            {
                /* base type */
                BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgHwVelTblX[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMaxRate(void)
{
    extern __PST__g__26 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMaxRate;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMaxRate = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMinPinionAgConf(void)
{
    extern __PST__g__26 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMinPinionAgConf;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMinPinionAgConf = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgPinionAgSelnTbl(void)
{
    extern __PST__g__23 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgPinionAgSelnTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 9; _main_gen_tmp_2_0++)
            {
                /* base type */
                BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgPinionAgSelnTbl[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdLnrSelnX(void)
{
    extern __PST__g__27 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdLnrSelnX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 11; _main_gen_tmp_3_0++)
            {
                /* base type */
                BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdLnrSelnX[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdScaFacY(void)
{
    extern __PST__g__27 BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdScaFacY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 11; _main_gen_tmp_4_0++)
            {
                /* base type */
                BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdScaFacY[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwPwrPrkgDampg_Pim_DampgCmdPwrPrkgStVari(void)
{
    extern __PST__FLOAT32 BmwPwrPrkgDampg_Pim_DampgCmdPwrPrkgStVari;
    
    /* initialization with random value */
    {
        BmwPwrPrkgDampg_Pim_DampgCmdPwrPrkgStVari = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwPwrPrkgDampg_Ip_DampgCmdBas */
    _main_gen_init_sym_BmwPwrPrkgDampg_Ip_DampgCmdBas();
    
    /* init for variable BmwPwrPrkgDampg_Ip_DampgCmdPwrPrkgEna */
    _main_gen_init_sym_BmwPwrPrkgDampg_Ip_DampgCmdPwrPrkgEna();
    
    /* init for variable BmwPwrPrkgDampg_Ip_HwVel */
    _main_gen_init_sym_BmwPwrPrkgDampg_Ip_HwVel();
    
    /* init for variable BmwPwrPrkgDampg_Ip_PinionAg */
    _main_gen_init_sym_BmwPwrPrkgDampg_Ip_PinionAg();
    
    /* init for variable BmwPwrPrkgDampg_Ip_PinionAgConf */
    _main_gen_init_sym_BmwPwrPrkgDampg_Ip_PinionAgConf();
    
    /* init for variable BmwPwrPrkgDampg_Ip_VehSpd */
    _main_gen_init_sym_BmwPwrPrkgDampg_Ip_VehSpd();
    
    /* init for variable BmwPwrPrkgDampg_Op_DampgCmdPwrPrkg : useless (never read) */

    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgBasPwrPrkgDampgY */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgBasPwrPrkgDampgY();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgDiScadDampg */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgDiScadDampg();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgHwVelTblX */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgHwVelTblX();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMaxRate */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMaxRate();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMinPinionAgConf */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgMinPinionAgConf();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgPinionAgSelnTbl */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgPinionAgSelnTbl();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdLnrSelnX */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdLnrSelnX();
    
    /* init for variable BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdScaFacY */
    _main_gen_init_sym_BmwPwrPrkgDampg_Cal_BmwPwrPrkgDampgVehSpdScaFacY();
    
    /* init for variable BmwPwrPrkgDampg_Pim_DampgCmdPwrPrkgStVari */
    _main_gen_init_sym_BmwPwrPrkgDampg_Pim_DampgCmdPwrPrkgStVari();
    
}
