#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJENA                                                       STD_ON
#define FLTINJ_PULLCMPACTV_PULLCMPCMD           59U


#endif
