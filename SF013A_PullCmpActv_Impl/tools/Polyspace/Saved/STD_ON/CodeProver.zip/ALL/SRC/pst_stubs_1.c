#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_PullCmpActv_Ip_HwAg(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_HwAg;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_HwTq(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_HwTq;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_HwVel(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_HwVel;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_PinionAgConf(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_PinionAgConf;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_PinionAgConf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_PullCmpActvDi(void)
{
    extern __PST__UINT8 PullCmpActv_Ip_PullCmpActvDi;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_PullCmpActvDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_PullCmpCmdDi(void)
{
    extern __PST__UINT8 PullCmpActv_Ip_PullCmpCmdDi;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_PullCmpCmdDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_PullCmpCustLrngDi(void)
{
    extern __PST__UINT8 PullCmpActv_Ip_PullCmpCustLrngDi;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_PullCmpCustLrngDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_PullCmpLrngDi(void)
{
    extern __PST__UINT8 PullCmpActv_Ip_PullCmpLrngDi;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_PullCmpLrngDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_VehLatA(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_VehLatA;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_VehLatA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_VehSpd;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_VehSpdVld(void)
{
    extern __PST__UINT8 PullCmpActv_Ip_VehSpdVld;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_VehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_VehYawRate(void)
{
    extern __PST__FLOAT32 PullCmpActv_Ip_VehYawRate;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_VehYawRate = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Ip_VehYawRateVld(void)
{
    extern __PST__UINT8 PullCmpActv_Ip_VehYawRateVld;
    
    /* initialization with random value */
    {
        PullCmpActv_Ip_VehYawRateVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpLrnTiDecShoTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpLrnTiDecShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpLrnTiDecShoTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpLrnTiIncShoTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpLrnTiIncShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpLrnTiIncShoTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpLrnTiLongTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpLrnTiLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpLrnTiLongTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwAgThd(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwAgThd;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwAgThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwTqThd(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwTqThd;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwTqThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstLatAThd(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpShoTermRstLatAThd;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpShoTermRstLatAThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstYawRateThd(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvCmpShoTermRstYawRateThd;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvCmpShoTermRstYawRateThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvEna(void)
{
    extern __PST__g__31 PullCmpActv_Cal_PullCmpActvEna;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvEna = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvHwTqFilFrqLongTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvHwTqFilFrqLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvHwTqFilFrqLongTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvHwTqFilFrqLrngEna(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvHwTqFilFrqLrngEna;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvHwTqFilFrqLrngEna = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvHwTqFilFrqShoTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvHwTqFilFrqShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvHwTqFilFrqShoTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLongTermLim(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLongTermLim;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLongTermLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaAgConfMinMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaAgConfMinMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaAgConfMinMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaHwAgMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaHwAgMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaHwAgMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaHwTqMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaHwTqMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaHwTqMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaHwVelMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaHwVelMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaHwVelMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaLatAMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaLatAMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaLatAMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaTiThd(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaTiThd;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaTiThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMinMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMinMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMinMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdRateMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdRateMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdRateMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaYawRateMaxMgn(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvLrngEnaYawRateMaxMgn;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvLrngEnaYawRateMaxMgn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvOpstSignTiShoTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvOpstSignTiShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvOpstSignTiShoTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvOutpMaxRate(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvOutpMaxRate;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvOutpMaxRate = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullCmpShoTermLim(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvPullCmpShoTermLim;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvPullCmpShoTermLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullCmpTotLim(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvPullCmpTotLim;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvPullCmpTotLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullErrLimLongTerm(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvPullErrLimLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvPullErrLimLongTerm = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullErrMgnThd(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvPullErrMgnThd;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvPullErrMgnThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullErrShoTermLim(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvPullErrShoTermLim;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvPullErrShoTermLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvShoTermRampTi(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvShoTermRampTi;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvShoTermRampTi = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvVehSpdScaTblX(void)
{
    extern __PST__g__32 PullCmpActv_Cal_PullCmpActvVehSpdScaTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                PullCmpActv_Cal_PullCmpActvVehSpdScaTblX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvVehSpdScaTblY(void)
{
    extern __PST__g__32 PullCmpActv_Cal_PullCmpActvVehSpdScaTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 4; _main_gen_tmp_3_0++)
            {
                /* base type */
                PullCmpActv_Cal_PullCmpActvVehSpdScaTblY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvYawRateFilFrq(void)
{
    extern __PST__g__30 PullCmpActv_Cal_PullCmpActvYawRateFilFrq;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_PullCmpActvYawRateFilFrq = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cal_SysGlbPrmSysTqRat(void)
{
    extern __PST__g__30 PullCmpActv_Cal_SysGlbPrmSysTqRat;
    
    /* initialization with random value */
    {
        PullCmpActv_Cal_SysGlbPrmSysTqRat = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PullCmpLongTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_PullCmpLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PullCmpLongTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_CmpLrnTiDecShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_CmpLrnTiDecShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_CmpLrnTiDecShoTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_CmpLrnTiIncShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_CmpLrnTiIncShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_CmpLrnTiIncShoTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_CmpLrnTiLongTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_CmpLrnTiLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_CmpLrnTiLongTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_HwTqLpFilLongTerm(void)
{
    extern struct __PST__g__34 PullCmpActv_Pim_HwTqLpFilLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_HwTqLpFilLongTerm = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_HwTqLpFilLrngEna(void)
{
    extern struct __PST__g__34 PullCmpActv_Pim_HwTqLpFilLrngEna;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_HwTqLpFilLrngEna = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_HwTqLpFilShoTerm(void)
{
    extern struct __PST__g__34 PullCmpActv_Pim_HwTqLpFilShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_HwTqLpFilShoTerm = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_IntgtrGainDecShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_IntgtrGainDecShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_IntgtrGainDecShoTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_IntgtrGainIncShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_IntgtrGainIncShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_IntgtrGainIncShoTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_LrngEnaPrev(void)
{
    extern __PST__UINT8 PullCmpActv_Pim_LrngEnaPrev;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_LrngEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_LrngEnad(void)
{
    extern __PST__UINT8 PullCmpActv_Pim_LrngEnad;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_LrngEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_OpstSignPrev(void)
{
    extern __PST__UINT8 PullCmpActv_Pim_OpstSignPrev;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_OpstSignPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PrevLrnTiLongTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_PrevLrnTiLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PrevLrnTiLongTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PullCmpCmdRateLimPrev(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_PullCmpCmdRateLimPrev;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PullCmpCmdRateLimPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PullCmpCmdTot(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_PullCmpCmdTot;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PullCmpCmdTot = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PullCmpLongTermRst(void)
{
    extern __PST__UINT8 PullCmpActv_Pim_PullCmpLongTermRst;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PullCmpLongTermRst = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PullCmpShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_PullCmpShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PullCmpShoTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_PullCmpShoTermRst(void)
{
    extern __PST__UINT8 PullCmpActv_Pim_PullCmpShoTermRst;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_PullCmpShoTermRst = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_RefTiEnaLrng(void)
{
    extern __PST__UINT32 PullCmpActv_Pim_RefTiEnaLrng;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_RefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_RefTiOpstSign(void)
{
    extern __PST__UINT32 PullCmpActv_Pim_RefTiOpstSign;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_RefTiOpstSign = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_VehSpdPrev(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_VehSpdPrev;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_VehSpdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_VehSpdRate(void)
{
    extern __PST__FLOAT32 PullCmpActv_Pim_VehSpdRate;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_VehSpdRate = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Pim_VehYawRateLpFil(void)
{
    extern struct __PST__g__34 PullCmpActv_Pim_VehYawRateLpFil;
    
    /* initialization with random value */
    {
        PullCmpActv_Pim_VehYawRateLpFil = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_PullCmpActv_Irv_RampDwnStepSize(void)
{
    extern __PST__FLOAT32 PullCmpActv_Irv_RampDwnStepSize;
    
    /* initialization with random value */
    {
        PullCmpActv_Irv_RampDwnStepSize = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 PullCmpActv_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        PullCmpActv_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PullCmpActv_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 PullCmpActv_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        PullCmpActv_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_PullCmpCmdTot(void)
{
    extern __PST__FLOAT32 PullCmpActv_Cli_GetPullCmpPrm_PullCmpCmdTot;
    
    /* initialization with random value */
    {
        PullCmpActv_Cli_GetPullCmpPrm_PullCmpCmdTot = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_PullCmpShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Cli_GetPullCmpPrm_PullCmpShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cli_GetPullCmpPrm_PullCmpShoTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_PullCmpLongTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Cli_GetPullCmpPrm_PullCmpLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cli_GetPullCmpPrm_PullCmpLongTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_LrngEnad(void)
{
    extern __PST__UINT8 PullCmpActv_Cli_GetPullCmpPrm_LrngEnad;
    
    /* initialization with random value */
    {
        PullCmpActv_Cli_GetPullCmpPrm_LrngEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cli_SetPullCmpLongTerm_PullCmpLongTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Cli_SetPullCmpLongTerm_PullCmpLongTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cli_SetPullCmpLongTerm_PullCmpLongTerm = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PullCmpActv_Cli_SetPullCmpShoTerm_PullCmpShoTerm(void)
{
    extern __PST__FLOAT32 PullCmpActv_Cli_SetPullCmpShoTerm_PullCmpShoTerm;
    
    /* initialization with random value */
    {
        PullCmpActv_Cli_SetPullCmpShoTerm_PullCmpShoTerm = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable PullCmpActv_Ip_HwAg */
    _main_gen_init_sym_PullCmpActv_Ip_HwAg();
    
    /* init for variable PullCmpActv_Ip_HwTq */
    _main_gen_init_sym_PullCmpActv_Ip_HwTq();
    
    /* init for variable PullCmpActv_Ip_HwVel */
    _main_gen_init_sym_PullCmpActv_Ip_HwVel();
    
    /* init for variable PullCmpActv_Ip_PinionAgConf */
    _main_gen_init_sym_PullCmpActv_Ip_PinionAgConf();
    
    /* init for variable PullCmpActv_Ip_PullCmpActvDi */
    _main_gen_init_sym_PullCmpActv_Ip_PullCmpActvDi();
    
    /* init for variable PullCmpActv_Ip_PullCmpCmdDi */
    _main_gen_init_sym_PullCmpActv_Ip_PullCmpCmdDi();
    
    /* init for variable PullCmpActv_Ip_PullCmpCustLrngDi */
    _main_gen_init_sym_PullCmpActv_Ip_PullCmpCustLrngDi();
    
    /* init for variable PullCmpActv_Ip_PullCmpLrngDi */
    _main_gen_init_sym_PullCmpActv_Ip_PullCmpLrngDi();
    
    /* init for variable PullCmpActv_Ip_VehLatA */
    _main_gen_init_sym_PullCmpActv_Ip_VehLatA();
    
    /* init for variable PullCmpActv_Ip_VehSpd */
    _main_gen_init_sym_PullCmpActv_Ip_VehSpd();
    
    /* init for variable PullCmpActv_Ip_VehSpdVld */
    _main_gen_init_sym_PullCmpActv_Ip_VehSpdVld();
    
    /* init for variable PullCmpActv_Ip_VehYawRate */
    _main_gen_init_sym_PullCmpActv_Ip_VehYawRate();
    
    /* init for variable PullCmpActv_Ip_VehYawRateVld */
    _main_gen_init_sym_PullCmpActv_Ip_VehYawRateVld();
    
    /* init for variable PullCmpActv_Op_PullCmpCmd : useless (never read) */

    /* init for variable PullCmpActv_Cal_PullCmpActvCmpLrnTiDecShoTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpLrnTiDecShoTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvCmpLrnTiIncShoTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpLrnTiIncShoTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvCmpLrnTiLongTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpLrnTiLongTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwAgThd */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwAgThd();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwTqThd */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstHwTqThd();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvCmpShoTermRstLatAThd */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstLatAThd();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvCmpShoTermRstYawRateThd */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvCmpShoTermRstYawRateThd();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvEna */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvEna();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvHwTqFilFrqLongTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvHwTqFilFrqLongTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvHwTqFilFrqLrngEna */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvHwTqFilFrqLrngEna();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvHwTqFilFrqShoTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvHwTqFilFrqShoTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLongTermLim */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLongTermLim();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaAgConfMinMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaAgConfMinMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaHwAgMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaHwAgMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaHwTqMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaHwTqMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaHwVelMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaHwVelMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaLatAMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaLatAMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaTiThd */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaTiThd();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMinMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdMinMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdRateMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaVehSpdRateMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvLrngEnaYawRateMaxMgn */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvLrngEnaYawRateMaxMgn();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvOpstSignTiShoTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvOpstSignTiShoTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvOutpMaxRate */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvOutpMaxRate();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvPullCmpShoTermLim */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullCmpShoTermLim();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvPullCmpTotLim */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullCmpTotLim();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvPullErrLimLongTerm */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullErrLimLongTerm();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvPullErrMgnThd */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullErrMgnThd();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvPullErrShoTermLim */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvPullErrShoTermLim();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvShoTermRampTi */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvShoTermRampTi();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvVehSpdScaTblX */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvVehSpdScaTblX();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvVehSpdScaTblY */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvVehSpdScaTblY();
    
    /* init for variable PullCmpActv_Cal_PullCmpActvYawRateFilFrq */
    _main_gen_init_sym_PullCmpActv_Cal_PullCmpActvYawRateFilFrq();
    
    /* init for variable PullCmpActv_Cal_SysGlbPrmSysTqRat */
    _main_gen_init_sym_PullCmpActv_Cal_SysGlbPrmSysTqRat();
    
    /* init for variable PullCmpActv_Pim_PullCmpLongTerm */
    _main_gen_init_sym_PullCmpActv_Pim_PullCmpLongTerm();
    
    /* init for variable PullCmpActv_Pim_dPullCmpActvIntgtrGainShoTerm : useless (never read) */

    /* init for variable PullCmpActv_Pim_dPullCmpActvPullErrLongTerm : useless (never read) */

    /* init for variable PullCmpActv_Pim_dPullCmpActvPullErrShoTerm : useless (never read) */

    /* init for variable PullCmpActv_Pim_dPullCmpActvShoTermRst : useless (never read) */

    /* init for variable PullCmpActv_Pim_CmpLrnTiDecShoTerm */
    _main_gen_init_sym_PullCmpActv_Pim_CmpLrnTiDecShoTerm();
    
    /* init for variable PullCmpActv_Pim_CmpLrnTiIncShoTerm */
    _main_gen_init_sym_PullCmpActv_Pim_CmpLrnTiIncShoTerm();
    
    /* init for variable PullCmpActv_Pim_CmpLrnTiLongTerm */
    _main_gen_init_sym_PullCmpActv_Pim_CmpLrnTiLongTerm();
    
    /* init for variable PullCmpActv_Pim_HwTqLpFilLongTerm */
    _main_gen_init_sym_PullCmpActv_Pim_HwTqLpFilLongTerm();
    
    /* init for variable PullCmpActv_Pim_HwTqLpFilLrngEna */
    _main_gen_init_sym_PullCmpActv_Pim_HwTqLpFilLrngEna();
    
    /* init for variable PullCmpActv_Pim_HwTqLpFilShoTerm */
    _main_gen_init_sym_PullCmpActv_Pim_HwTqLpFilShoTerm();
    
    /* init for variable PullCmpActv_Pim_IntgtrGainDecShoTerm */
    _main_gen_init_sym_PullCmpActv_Pim_IntgtrGainDecShoTerm();
    
    /* init for variable PullCmpActv_Pim_IntgtrGainIncShoTerm */
    _main_gen_init_sym_PullCmpActv_Pim_IntgtrGainIncShoTerm();
    
    /* init for variable PullCmpActv_Pim_LrngEnaPrev */
    _main_gen_init_sym_PullCmpActv_Pim_LrngEnaPrev();
    
    /* init for variable PullCmpActv_Pim_LrngEnad */
    _main_gen_init_sym_PullCmpActv_Pim_LrngEnad();
    
    /* init for variable PullCmpActv_Pim_OpstSignPrev */
    _main_gen_init_sym_PullCmpActv_Pim_OpstSignPrev();
    
    /* init for variable PullCmpActv_Pim_PrevLrnTiLongTerm */
    _main_gen_init_sym_PullCmpActv_Pim_PrevLrnTiLongTerm();
    
    /* init for variable PullCmpActv_Pim_PullCmpCmdRateLimPrev */
    _main_gen_init_sym_PullCmpActv_Pim_PullCmpCmdRateLimPrev();
    
    /* init for variable PullCmpActv_Pim_PullCmpCmdTot */
    _main_gen_init_sym_PullCmpActv_Pim_PullCmpCmdTot();
    
    /* init for variable PullCmpActv_Pim_PullCmpLongTermRst */
    _main_gen_init_sym_PullCmpActv_Pim_PullCmpLongTermRst();
    
    /* init for variable PullCmpActv_Pim_PullCmpShoTerm */
    _main_gen_init_sym_PullCmpActv_Pim_PullCmpShoTerm();
    
    /* init for variable PullCmpActv_Pim_PullCmpShoTermRst */
    _main_gen_init_sym_PullCmpActv_Pim_PullCmpShoTermRst();
    
    /* init for variable PullCmpActv_Pim_RefTiEnaLrng */
    _main_gen_init_sym_PullCmpActv_Pim_RefTiEnaLrng();
    
    /* init for variable PullCmpActv_Pim_RefTiOpstSign */
    _main_gen_init_sym_PullCmpActv_Pim_RefTiOpstSign();
    
    /* init for variable PullCmpActv_Pim_VehSpdPrev */
    _main_gen_init_sym_PullCmpActv_Pim_VehSpdPrev();
    
    /* init for variable PullCmpActv_Pim_VehSpdRate */
    _main_gen_init_sym_PullCmpActv_Pim_VehSpdRate();
    
    /* init for variable PullCmpActv_Pim_VehYawRateLpFil */
    _main_gen_init_sym_PullCmpActv_Pim_VehYawRateLpFil();
    
    /* init for variable PullCmpActv_Irv_RampDwnStepSize */
    _main_gen_init_sym_PullCmpActv_Irv_RampDwnStepSize();
    
    /* init for variable PullCmpActv_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_PullCmpActv_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable PullCmpActv_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable PullCmpActv_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_PullCmpActv_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable PullCmpActv_Srv_PullCmpLongTerm_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable PullCmpActv_Cli_GetPullCmpPrm_PullCmpCmdTot */
    _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_PullCmpCmdTot();
    
    /* init for variable PullCmpActv_Cli_GetPullCmpPrm_PullCmpShoTerm */
    _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_PullCmpShoTerm();
    
    /* init for variable PullCmpActv_Cli_GetPullCmpPrm_PullCmpLongTerm */
    _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_PullCmpLongTerm();
    
    /* init for variable PullCmpActv_Cli_GetPullCmpPrm_LrngEnad */
    _main_gen_init_sym_PullCmpActv_Cli_GetPullCmpPrm_LrngEnad();
    
    /* init for variable PullCmpActv_Cli_SetPullCmpLongTerm_PullCmpLongTerm */
    _main_gen_init_sym_PullCmpActv_Cli_SetPullCmpLongTerm_PullCmpLongTerm();
    
    /* init for variable PullCmpActv_Cli_SetPullCmpShoTerm_PullCmpShoTerm */
    _main_gen_init_sym_PullCmpActv_Cli_SetPullCmpShoTerm_PullCmpShoTerm();
    
}
