#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FalbckAssi_Ip_HwTq(void)
{
    extern __PST__FLOAT32 FalbckAssi_Ip_HwTq;
    
    /* initialization with random value */
    {
        FalbckAssi_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FalbckAssi_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 FalbckAssi_Ip_VehSpd;
    
    /* initialization with random value */
    {
        FalbckAssi_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FalbckAssi_Cal_FalbckAssiAssiX(void)
{
    extern __PST__g__22 FalbckAssi_Cal_FalbckAssiAssiX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 12; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 20; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    FalbckAssi_Cal_FalbckAssiAssiX[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_FalbckAssi_Cal_FalbckAssiAssiY(void)
{
    extern __PST__g__22 FalbckAssi_Cal_FalbckAssiAssiY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 12; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 20; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    FalbckAssi_Cal_FalbckAssiAssiY[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_FalbckAssi_Cal_FalbckAssiNotchFil(void)
{
    extern __PST__g__25 FalbckAssi_Cal_FalbckAssiNotchFil;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 1; _main_gen_tmp_2_0++)
            {
                /* struct/union type */
                FalbckAssi_Cal_FalbckAssiNotchFil[_main_gen_tmp_2_0].FilGainB0 = _main_gen_init_g10();
                FalbckAssi_Cal_FalbckAssiNotchFil[_main_gen_tmp_2_0].FilGainB1 = _main_gen_init_g10();
                FalbckAssi_Cal_FalbckAssiNotchFil[_main_gen_tmp_2_0].FilGainB2 = _main_gen_init_g10();
                FalbckAssi_Cal_FalbckAssiNotchFil[_main_gen_tmp_2_0].FilGainA1 = _main_gen_init_g10();
                FalbckAssi_Cal_FalbckAssiNotchFil[_main_gen_tmp_2_0].FilGainA2 = _main_gen_init_g10();
            }
        }
    }
}

static void _main_gen_init_sym_FalbckAssi_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__28 FalbckAssi_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 12; _main_gen_tmp_3_0++)
            {
                /* base type */
                FalbckAssi_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FalbckAssi_Pim_FalbckAssiNotchFil1(void)
{
    extern __PST__FLOAT32 FalbckAssi_Pim_FalbckAssiNotchFil1;
    
    /* initialization with random value */
    {
        FalbckAssi_Pim_FalbckAssiNotchFil1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FalbckAssi_Pim_FalbckAssiNotchFil2(void)
{
    extern __PST__FLOAT32 FalbckAssi_Pim_FalbckAssiNotchFil2;
    
    /* initialization with random value */
    {
        FalbckAssi_Pim_FalbckAssiNotchFil2 = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FalbckAssi_Ip_HwTq */
    _main_gen_init_sym_FalbckAssi_Ip_HwTq();
    
    /* init for variable FalbckAssi_Ip_VehSpd */
    _main_gen_init_sym_FalbckAssi_Ip_VehSpd();
    
    /* init for variable FalbckAssi_Op_FalbckAssiMotTqCmd : useless (never read) */

    /* init for variable FalbckAssi_Cal_FalbckAssiAssiX */
    _main_gen_init_sym_FalbckAssi_Cal_FalbckAssiAssiX();
    
    /* init for variable FalbckAssi_Cal_FalbckAssiAssiY */
    _main_gen_init_sym_FalbckAssi_Cal_FalbckAssiAssiY();
    
    /* init for variable FalbckAssi_Cal_FalbckAssiNotchFil */
    _main_gen_init_sym_FalbckAssi_Cal_FalbckAssiNotchFil();
    
    /* init for variable FalbckAssi_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_FalbckAssi_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable FalbckAssi_Pim_FalbckAssiNotchFil1 */
    _main_gen_init_sym_FalbckAssi_Pim_FalbckAssiNotchFil1();
    
    /* init for variable FalbckAssi_Pim_FalbckAssiNotchFil2 */
    _main_gen_init_sym_FalbckAssi_Pim_FalbckAssiNotchFil2();
    
}
