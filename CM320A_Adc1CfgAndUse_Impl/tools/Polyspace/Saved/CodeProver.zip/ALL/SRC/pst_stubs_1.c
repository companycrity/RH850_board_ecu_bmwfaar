#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__286 _main_gen_init_g286(void);

extern union __PST__g__274 _main_gen_init_g274(void);

extern union __PST__g__264 _main_gen_init_g264(void);

extern union __PST__g__267 _main_gen_init_g267(void);

extern union __PST__g__261 _main_gen_init_g261(void);

extern union __PST__g__259 _main_gen_init_g259(void);

extern union __PST__g__257 _main_gen_init_g257(void);

extern union __PST__g__255 _main_gen_init_g255(void);

extern union __PST__g__253 _main_gen_init_g253(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__249 _main_gen_init_g249(void);

extern union __PST__g__247 _main_gen_init_g247(void);

extern union __PST__g__245 _main_gen_init_g245(void);

extern union __PST__g__240 _main_gen_init_g240(void);

extern union __PST__g__214 _main_gen_init_g214(void);

extern union __PST__g__211 _main_gen_init_g211(void);

extern struct __PST__g__208 _main_gen_init_g208(void);

extern union __PST__g__207 _main_gen_init_g207(void);

extern struct __PST__g__203 _main_gen_init_g203(void);

extern union __PST__g__202 _main_gen_init_g202(void);

extern struct __PST__g__189 _main_gen_init_g189(void);

extern union __PST__g__188 _main_gen_init_g188(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__24 _main_gen_init_g24(void);

extern __PST__g__22 _main_gen_init_g22(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__24 _main_gen_init_g24(void)
{
    static union __PST__g__24 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__189 _main_gen_init_g189(void)
{
    static struct __PST__g__189 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x.SUSMTD = bitf;
    }
    return x;
}

union __PST__g__188 _main_gen_init_g188(void)
{
    static union __PST__g__188 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g189();
    return x;
}

struct __PST__g__203 _main_gen_init_g203(void)
{
    static struct __PST__g__203 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ADDNT = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DFMT = bitf;
    }
    return x;
}

union __PST__g__202 _main_gen_init_g202(void)
{
    static union __PST__g__202 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g203();
    return x;
}

struct __PST__g__208 _main_gen_init_g208(void)
{
    static struct __PST__g__208 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.IDEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.OWEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ULEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.RDCLRE = bitf;
    }
    return x;
}

union __PST__g__207 _main_gen_init_g207(void)
{
    static union __PST__g__207 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g208();
    return x;
}

union __PST__g__211 _main_gen_init_g211(void)
{
    static union __PST__g__211 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__214 _main_gen_init_g214(void)
{
    static union __PST__g__214 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__240 _main_gen_init_g240(void)
{
    static union __PST__g__240 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__245 _main_gen_init_g245(void)
{
    static union __PST__g__245 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__247 _main_gen_init_g247(void)
{
    static union __PST__g__247 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__249 _main_gen_init_g249(void)
{
    static union __PST__g__249 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__253 _main_gen_init_g253(void)
{
    static union __PST__g__253 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__255 _main_gen_init_g255(void)
{
    static union __PST__g__255 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__257 _main_gen_init_g257(void)
{
    static union __PST__g__257 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__259 _main_gen_init_g259(void)
{
    static union __PST__g__259 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__261 _main_gen_init_g261(void)
{
    static union __PST__g__261 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__267 _main_gen_init_g267(void)
{
    static union __PST__g__267 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__264 _main_gen_init_g264(void)
{
    static union __PST__g__264 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__274 _main_gen_init_g274(void)
{
    static union __PST__g__274 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__286 _main_gen_init_g286(void)
{
    static union __PST__g__286 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* struct/union type */
    x.VCR00 = _main_gen_init_g24();
    x.VCR01 = _main_gen_init_g24();
    x.VCR02 = _main_gen_init_g24();
    x.VCR03 = _main_gen_init_g24();
    x.VCR04 = _main_gen_init_g24();
    x.VCR05 = _main_gen_init_g24();
    x.VCR06 = _main_gen_init_g24();
    x.VCR07 = _main_gen_init_g24();
    x.VCR08 = _main_gen_init_g24();
    x.VCR09 = _main_gen_init_g24();
    x.VCR10 = _main_gen_init_g24();
    x.VCR11 = _main_gen_init_g24();
    x.VCR12 = _main_gen_init_g24();
    x.VCR13 = _main_gen_init_g24();
    x.VCR14 = _main_gen_init_g24();
    x.VCR15 = _main_gen_init_g24();
    x.VCR16 = _main_gen_init_g24();
    x.VCR17 = _main_gen_init_g24();
    x.VCR18 = _main_gen_init_g24();
    x.VCR19 = _main_gen_init_g24();
    x.VCR20 = _main_gen_init_g24();
    x.VCR21 = _main_gen_init_g24();
    x.VCR22 = _main_gen_init_g24();
    x.VCR23 = _main_gen_init_g24();
    x.ADCR1 = _main_gen_init_g188();
    x.ADCR2 = _main_gen_init_g202();
    x.SFTCR = _main_gen_init_g207();
    x.ODCR = _main_gen_init_g211();
    x.ULLMTBR0 = _main_gen_init_g214();
    x.ULLMTBR1 = _main_gen_init_g214();
    x.ULLMTBR2 = _main_gen_init_g214();
    x.THCR = _main_gen_init_g240();
    x.THACR = _main_gen_init_g245();
    x.THBCR = _main_gen_init_g245();
    x.THER = _main_gen_init_g247();
    x.THGSR = _main_gen_init_g249();
    x.SGSTCR0 = _main_gen_init_g253();
    x.SGCR0 = _main_gen_init_g255();
    x.SGVCSP0 = _main_gen_init_g257();
    x.SGVCEP0 = _main_gen_init_g259();
    x.SGMCYCR0 = _main_gen_init_g261();
    x.ULLMSR0 = _main_gen_init_g267();
    x.SGSTCR1 = _main_gen_init_g253();
    x.SGCR1 = _main_gen_init_g255();
    x.SGVCSP1 = _main_gen_init_g257();
    x.SGVCEP1 = _main_gen_init_g259();
    x.SGMCYCR1 = _main_gen_init_g261();
    x.SGSR1 = _main_gen_init_g264();
    x.ULLMSR1 = _main_gen_init_g267();
    x.SGSTCR2 = _main_gen_init_g253();
    x.SGCR2 = _main_gen_init_g255();
    x.SGVCSP2 = _main_gen_init_g257();
    x.SGVCEP2 = _main_gen_init_g259();
    x.SGMCYCR2 = _main_gen_init_g261();
    x.ULLMSR2 = _main_gen_init_g267();
    x.SGSTCR3 = _main_gen_init_g253();
    x.SGCR3 = _main_gen_init_g274();
    x.SGVCSP3 = _main_gen_init_g257();
    x.SGVCEP3 = _main_gen_init_g259();
    x.SGMCYCR3 = _main_gen_init_g261();
    x.ULLMSR3 = _main_gen_init_g267();
    x.SGSTCR4 = _main_gen_init_g253();
    x.SGCR4 = _main_gen_init_g274();
    x.SGVCSP4 = _main_gen_init_g257();
    x.SGVCEP4 = _main_gen_init_g259();
    x.SGMCYCR4 = _main_gen_init_g261();
    x.ULLMSR4 = _main_gen_init_g267();
    x.ADOPDIG1 = _main_gen_init_g286();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Adc1CfgAndUse_Ip_AdcDiagcEndPtrOutp(void)
{
    extern __PST__UINT8 Adc1CfgAndUse_Ip_AdcDiagcEndPtrOutp;
    
    /* initialization with random value */
    {
        Adc1CfgAndUse_Ip_AdcDiagcEndPtrOutp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adc1CfgAndUse_Ip_AdcDiagcStrtPtrOutp(void)
{
    extern __PST__UINT8 Adc1CfgAndUse_Ip_AdcDiagcStrtPtrOutp;
    
    /* initialization with random value */
    {
        Adc1CfgAndUse_Ip_AdcDiagcStrtPtrOutp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adc1CfgAndUse_Pim_Adc1DiagcEndPtr(void)
{
    extern __PST__UINT8 Adc1CfgAndUse_Pim_Adc1DiagcEndPtr;
    
    /* initialization with random value */
    {
        Adc1CfgAndUse_Pim_Adc1DiagcEndPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adc1CfgAndUse_Pim_Adc1DiagcStrtPtr(void)
{
    extern __PST__UINT8 Adc1CfgAndUse_Pim_Adc1DiagcStrtPtr;
    
    /* initialization with random value */
    {
        Adc1CfgAndUse_Pim_Adc1DiagcStrtPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ADCD1(void)
{
    extern __PST__g__22 ADCD1;
    
    /* initialization with random value */
    {
        ADCD1 = _main_gen_init_g22();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Adc1CfgAndUse_Ip_AdcDiagcEndPtrOutp */
    _main_gen_init_sym_Adc1CfgAndUse_Ip_AdcDiagcEndPtrOutp();
    
    /* init for variable Adc1CfgAndUse_Ip_AdcDiagcStrtPtrOutp */
    _main_gen_init_sym_Adc1CfgAndUse_Ip_AdcDiagcStrtPtrOutp();
    
    /* init for variable Adc1CfgAndUse_Pim_Adc1DiagcEndPtr */
    _main_gen_init_sym_Adc1CfgAndUse_Pim_Adc1DiagcEndPtr();
    
    /* init for variable Adc1CfgAndUse_Pim_Adc1DiagcStrtPtr */
    _main_gen_init_sym_Adc1CfgAndUse_Pim_Adc1DiagcStrtPtr();
    
    /* init for variable ADCD1 */
    _main_gen_init_sym_ADCD1();
    
}
