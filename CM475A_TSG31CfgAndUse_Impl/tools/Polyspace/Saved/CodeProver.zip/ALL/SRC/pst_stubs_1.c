#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__187 _main_gen_init_g187(void);

extern union __PST__g__186 _main_gen_init_g186(void);

extern union __PST__g__184 _main_gen_init_g184(void);

extern union __PST__g__182 _main_gen_init_g182(void);

extern union __PST__g__180 _main_gen_init_g180(void);

extern union __PST__g__178 _main_gen_init_g178(void);

extern union __PST__g__159 _main_gen_init_g159(void);

extern union __PST__g__157 _main_gen_init_g157(void);

extern union __PST__g__155 _main_gen_init_g155(void);

extern union __PST__g__141 _main_gen_init_g141(void);

extern union __PST__g__139 _main_gen_init_g139(void);

extern union __PST__g__137 _main_gen_init_g137(void);

extern union __PST__g__133 _main_gen_init_g133(void);

extern union __PST__g__131 _main_gen_init_g131(void);

extern union __PST__g__129 _main_gen_init_g129(void);

extern union __PST__g__127 _main_gen_init_g127(void);

extern union __PST__g__125 _main_gen_init_g125(void);

extern union __PST__g__123 _main_gen_init_g123(void);

extern union __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__102 _main_gen_init_g102(void);

extern union __PST__g__99 _main_gen_init_g99(void);

extern struct __PST__g__98 _main_gen_init_g98(void);

extern union __PST__g__97 _main_gen_init_g97(void);

extern struct __PST__g__94 _main_gen_init_g94(void);

extern union __PST__g__93 _main_gen_init_g93(void);

extern union __PST__g__69 _main_gen_init_g69(void);

extern struct __PST__g__65 _main_gen_init_g65(void);

extern union __PST__g__64 _main_gen_init_g64(void);

extern union __PST__g__56 _main_gen_init_g56(void);

extern struct __PST__g__44 _main_gen_init_g44(void);

extern union __PST__g__42 _main_gen_init_g42(void);

extern union __PST__g__39 _main_gen_init_g39(void);

extern union __PST__g__36 _main_gen_init_g36(void);

extern union __PST__g__32 _main_gen_init_g32(void);

extern union __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__27 _main_gen_init_g27(void)
{
    static union __PST__g__27 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__32 _main_gen_init_g32(void)
{
    static union __PST__g__32 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__36 _main_gen_init_g36(void)
{
    static union __PST__g__36 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__39 _main_gen_init_g39(void)
{
    static union __PST__g__39 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__44 _main_gen_init_g44(void)
{
    static struct __PST__g__44 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.CUF = bitf;
    }
    return x;
}

union __PST__g__42 _main_gen_init_g42(void)
{
    static union __PST__g__42 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g44();
    return x;
}

union __PST__g__56 _main_gen_init_g56(void)
{
    static union __PST__g__56 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__65 _main_gen_init_g65(void)
{
    static struct __PST__g__65 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TS = bitf;
    }
    return x;
}

union __PST__g__64 _main_gen_init_g64(void)
{
    static union __PST__g__64 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g65();
    return x;
}

union __PST__g__69 _main_gen_init_g69(void)
{
    static union __PST__g__69 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

struct __PST__g__94 _main_gen_init_g94(void)
{
    static struct __PST__g__94 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1023);
        x.DTC0 = bitf;
    }
    return x;
}

union __PST__g__93 _main_gen_init_g93(void)
{
    static union __PST__g__93 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g94();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__98 _main_gen_init_g98(void)
{
    static struct __PST__g__98 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1023);
        x.DTC1 = bitf;
    }
    return x;
}

union __PST__g__97 _main_gen_init_g97(void)
{
    static union __PST__g__97 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g98();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__99 _main_gen_init_g99(void)
{
    static union __PST__g__99 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__102 _main_gen_init_g102(void)
{
    static union __PST__g__102 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__105 _main_gen_init_g105(void)
{
    static union __PST__g__105 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__123 _main_gen_init_g123(void)
{
    static union __PST__g__123 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__125 _main_gen_init_g125(void)
{
    static union __PST__g__125 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__127 _main_gen_init_g127(void)
{
    static union __PST__g__127 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__129 _main_gen_init_g129(void)
{
    static union __PST__g__129 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__131 _main_gen_init_g131(void)
{
    static union __PST__g__131 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__133 _main_gen_init_g133(void)
{
    static union __PST__g__133 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__137 _main_gen_init_g137(void)
{
    static union __PST__g__137 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__139 _main_gen_init_g139(void)
{
    static union __PST__g__139 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__141 _main_gen_init_g141(void)
{
    static union __PST__g__141 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__155 _main_gen_init_g155(void)
{
    static union __PST__g__155 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__157 _main_gen_init_g157(void)
{
    static union __PST__g__157 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__159 _main_gen_init_g159(void)
{
    static union __PST__g__159 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__178 _main_gen_init_g178(void)
{
    static union __PST__g__178 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__180 _main_gen_init_g180(void)
{
    static union __PST__g__180 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__182 _main_gen_init_g182(void)
{
    static union __PST__g__182 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__184 _main_gen_init_g184(void)
{
    static union __PST__g__184 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__187 _main_gen_init_g187(void)
{
    static struct __PST__g__187 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.DTCM = bitf;
    }
    return x;
}

union __PST__g__186 _main_gen_init_g186(void)
{
    static union __PST__g__186 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g187();
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* struct/union type */
    x.IOC2 = _main_gen_init_g27();
    x.CTL3 = _main_gen_init_g32();
    x.CTL5 = _main_gen_init_g36();
    x.CTL6 = _main_gen_init_g39();
    x.STR0 = _main_gen_init_g42();
    x.STC = _main_gen_init_g56();
    x.TRG0 = _main_gen_init_g64();
    x.TRG2 = _main_gen_init_g69();
    x.DTC0W = _main_gen_init_g93();
    x.DTC1W = _main_gen_init_g97();
    x.IOC3 = _main_gen_init_g99();
    x.CTL2 = _main_gen_init_g102();
    x.CTL4 = _main_gen_init_g105();
    x.DCMP2E = _main_gen_init_g123();
    x.DCMP1E = _main_gen_init_g125();
    x.DCMP0E = _main_gen_init_g127();
    x.CMP0E = _main_gen_init_g129();
    x.CMP12E = _main_gen_init_g131();
    x.CMP11E = _main_gen_init_g133();
    x.CMP7E = _main_gen_init_g137();
    x.CMP4E = _main_gen_init_g139();
    x.CMP3E = _main_gen_init_g141();
    x.CMPWE = _main_gen_init_g155();
    x.CMPVE = _main_gen_init_g157();
    x.CMPUE = _main_gen_init_g159();
    x.IOC0 = _main_gen_init_g178();
    x.IOC1 = _main_gen_init_g180();
    x.CTL0 = _main_gen_init_g182();
    x.CTL1 = _main_gen_init_g184();
    x.DTPR = _main_gen_init_g186();
    x.CNT = _main_gen_init_g7();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TSG31CfgAndUse_Ip_MotCurrEolCalSt(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Ip_MotCurrEolCalSt;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Ip_MotCurrEolCalSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Ip_PhaDiscnctDiagcActv(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Ip_PhaDiscnctDiagcActv;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Ip_PhaDiscnctDiagcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Ip_SysSt(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Ip_SysSt;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvn2Offs(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvn2Offs;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvn2Offs = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseMtrAg0SPIStart(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_TSG31CfgAndUseMtrAg0SPIStart;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_TSG31CfgAndUseMtrAg0SPIStart = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUsePwmDbnd(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_TSG31CfgAndUsePwmDbnd;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_TSG31CfgAndUsePwmDbnd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdMaxCntr(void)
{
    extern __PST__UINT16 TSG31CfgAndUse_Pim_MissUpdMaxCntr;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_MissUpdMaxCntr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdMinCntr(void)
{
    extern __PST__UINT16 TSG31CfgAndUse_Pim_MissUpdMinCntr;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_MissUpdMinCntr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak(void)
{
    extern __PST__UINT32 TSG31CfgAndUse_Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUseMotAg0SPIStart(void)
{
    extern __PST__UINT32 TSG31CfgAndUse_Pim_TSG31CfgAndUseMotAg0SPIStart;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_TSG31CfgAndUseMotAg0SPIStart = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUsePhaDiscntActvdStPrev(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Pim_TSG31CfgAndUsePhaDiscntActvdStPrev;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_TSG31CfgAndUsePhaDiscntActvdStPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUseSysStEnaPrev(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Pim_TSG31CfgAndUseSysStEnaPrev;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_TSG31CfgAndUseSysStEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ELECGLBPRM_MOTCTRLINTRPTTRIGSRC_CNT_U08(void)
{
    extern __PST__UINT8 ELECGLBPRM_MOTCTRLINTRPTTRIGSRC_CNT_U08;
    
    /* initialization with random value */
    {
        ELECGLBPRM_MOTCTRLINTRPTTRIGSRC_CNT_U08 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31(void)
{
    extern __PST__g__25 TSG31;
    
    /* initialization with random value */
    {
        TSG31 = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_CurrMeasEolFixdPwmPerd(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_CurrMeasEolFixdPwmPerd;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_CurrMeasEolFixdPwmPerd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_PhaDiscnctFixdPhaOnTi(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_PhaDiscnctFixdPhaOnTi;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_PhaDiscnctFixdPhaOnTi = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Cal_PhaDiscnctFixdPwmPerd(void)
{
    extern __PST__g__24 TSG31CfgAndUse_Cal_PhaDiscnctFixdPwmPerd;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Cal_PhaDiscnctFixdPwmPerd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdCoarse(void)
{
    extern __PST__UINT16 TSG31CfgAndUse_Pim_MissUpdCoarse;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_MissUpdCoarse = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdFine(void)
{
    extern __PST__UINT16 TSG31CfgAndUse_Pim_MissUpdFine;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_MissUpdFine = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdIninCntr(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Pim_MissUpdIninCntr;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Pim_MissUpdIninCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrEolCalSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrEolCalSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrEolCalSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPwmPerd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPwmPerd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaDiscnctDiagcActv(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlPhaDiscnctDiagcActv;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaDiscnctDiagcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaDiscnctDiagcPwmVect(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlPhaDiscnctDiagcPwmVect;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaDiscnctDiagcPwmVect = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return(void)
{
    extern __PST__UINT8 TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return;
    
    /* initialization with random value */
    {
        TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TSG31CfgAndUse_Ip_MotCurrEolCalSt */
    _main_gen_init_sym_TSG31CfgAndUse_Ip_MotCurrEolCalSt();
    
    /* init for variable TSG31CfgAndUse_Ip_PhaDiscnctDiagcActv */
    _main_gen_init_sym_TSG31CfgAndUse_Ip_PhaDiscnctDiagcActv();
    
    /* init for variable TSG31CfgAndUse_Ip_SysSt */
    _main_gen_init_sym_TSG31CfgAndUse_Ip_SysSt();
    
    /* init for variable TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvn2Offs */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvn2Offs();
    
    /* init for variable TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlPeakOffs();
    
    /* init for variable TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseAdcStrtOfCnvnMotCtrlVlyOffs();
    
    /* init for variable TSG31CfgAndUse_Cal_TSG31CfgAndUseMtrAg0SPIStart */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUseMtrAg0SPIStart();
    
    /* init for variable TSG31CfgAndUse_Cal_TSG31CfgAndUsePwmDbnd */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_TSG31CfgAndUsePwmDbnd();
    
    /* init for variable TSG31CfgAndUse_Pim_MissUpdMaxCntr */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdMaxCntr();
    
    /* init for variable TSG31CfgAndUse_Pim_MissUpdMinCntr */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdMinCntr();
    
    /* init for variable TSG31CfgAndUse_Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak();
    
    /* init for variable TSG31CfgAndUse_Pim_TSG31CfgAndUseMotAg0SPIStart */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUseMotAg0SPIStart();
    
    /* init for variable TSG31CfgAndUse_Pim_TSG31CfgAndUsePhaDiscntActvdStPrev */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUsePhaDiscntActvdStPrev();
    
    /* init for variable TSG31CfgAndUse_Pim_TSG31CfgAndUseSysStEnaPrev */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_TSG31CfgAndUseSysStEnaPrev();
    
    /* init for variable ELECGLBPRM_MOTCTRLINTRPTTRIGSRC_CNT_U08 */
    _main_gen_init_sym_ELECGLBPRM_MOTCTRLINTRPTTRIGSRC_CNT_U08();
    
    /* init for variable TSG31 */
    _main_gen_init_sym_TSG31();
    
    /* init for variable TSG31CfgAndUse_Cal_CurrMeasEolFixdPwmPerd */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_CurrMeasEolFixdPwmPerd();
    
    /* init for variable TSG31CfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs();
    
    /* init for variable TSG31CfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs();
    
    /* init for variable TSG31CfgAndUse_Cal_PhaDiscnctFixdPhaOnTi */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_PhaDiscnctFixdPhaOnTi();
    
    /* init for variable TSG31CfgAndUse_Cal_PhaDiscnctFixdPwmPerd */
    _main_gen_init_sym_TSG31CfgAndUse_Cal_PhaDiscnctFixdPwmPerd();
    
    /* init for variable TSG31CfgAndUse_Pim_MissUpdCoarse */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdCoarse();
    
    /* init for variable TSG31CfgAndUse_Pim_MissUpdFine */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdFine();
    
    /* init for variable TSG31CfgAndUse_Pim_MissUpdIninCntr */
    _main_gen_init_sym_TSG31CfgAndUse_Pim_MissUpdIninCntr();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrEolCalSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrEolCalSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlPwmPerd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC();
    
    /* init for variable MOTCTRLMGR_MotCtrlTSG31DCMP0E : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPUE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPVE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPWE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMP0E : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMP12E : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlPhaDiscnctDiagcActv */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaDiscnctDiagcActv();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaDiscnctDiagcPwmVect */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaDiscnctDiagcPwmVect();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_PinSt : useless (never read) */

    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_PinSt : useless (never read) */

    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_PinSt : useless (never read) */

    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_PinSt : useless (never read) */

    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_PinSt : useless (never read) */

    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return();
    
    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_PinSt : useless (never read) */

    /* init for variable TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return */
    _main_gen_init_sym_TSG31CfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return();
    
}
