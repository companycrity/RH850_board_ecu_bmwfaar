typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT32 *__PST__g__16;
typedef __PST__UINT8 __PST__g__15(__PST__g__16, __PST__UINT16);
typedef __PST__UINT8 *__PST__g__18;
typedef __PST__UINT8 __PST__g__17(__PST__UINT16, __PST__g__18);
typedef __PST__UINT8 __PST__g__19(__PST__g__18);
typedef __PST__UINT8 __PST__g__20(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16, __PST__UINT32, __PST__UINT32, __PST__UINT32);
typedef __PST__VOID __PST__g__21(void);
typedef __PST__FLOAT64 __PST__g__22(void);
typedef __PST__g__11 *__PST__g__24;
typedef volatile __PST__FLOAT64 __PST__g__25;
typedef __PST__SINT8 *__PST__g__27;
typedef volatile __PST__g__27 __PST__g__26;
typedef __PST__VOID __PST__g__28(__PST__SINT32);
typedef const __PST__UINT16 __PST__g__31;
typedef __PST__g__31 *__PST__g__30;
typedef __PST__UINT8 __PST__g__29(__PST__UINT8, __PST__g__30);
typedef __PST__UINT16 *__PST__g__33;
typedef __PST__UINT8 __PST__g__32(__PST__UINT8, __PST__g__33);
enum ETagSpi_SeqResultType
  {
    SPI_SEQ_CANCELLED = 3,
    SPI_SEQ_FAILED = 2,
    SPI_SEQ_OK = 0,
    SPI_SEQ_PENDING = 1
  };
typedef enum ETagSpi_SeqResultType __PST__g__34(__PST__UINT8);
typedef __PST__UINT8 __PST__g__36(__PST__UINT8);
typedef __PST__g__21 *__PST__g__37;
typedef __PST__g__17 *__PST__g__38;
typedef __PST__g__19 *__PST__g__39;
typedef __PST__g__28 *__PST__g__40;
typedef __PST__g__20 *__PST__g__41;
typedef __PST__g__34 *__PST__g__42;
typedef __PST__g__29 *__PST__g__43;
typedef __PST__g__36 *__PST__g__44;
typedef __PST__g__32 *__PST__g__45;
typedef __PST__UINT8 __PST__g__46(__PST__UINT16);
typedef __PST__g__46 *__PST__g__47;
typedef __PST__g__15 *__PST__g__48;
typedef volatile __PST__SINT32 __PST__g__49;
typedef __PST__SINT8 __PST__g__55(void);
typedef volatile __PST__SINT8 __PST__g__56;
typedef __PST__UINT8 __PST__g__57(void);
typedef volatile __PST__UINT8 __PST__g__58;
typedef __PST__SINT32 __PST__g__59(void);
typedef __PST__UINT32 __PST__g__60(void);
typedef volatile __PST__UINT32 __PST__g__61;
