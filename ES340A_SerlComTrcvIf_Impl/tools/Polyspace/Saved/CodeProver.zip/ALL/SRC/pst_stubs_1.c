#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SerlComTrcvIf_Srv_CnvSnpshtData_u16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 SerlComTrcvIf_Srv_CnvSnpshtData_u16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Srv_CnvSnpshtData_u16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_PinSt(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_PinSt;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_Return(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_Return;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Pim_SerlComTrcvIfFltErrPin(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Pim_SerlComTrcvIfFltErrPin;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Pim_SerlComTrcvIfFltErrPin = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Pim_SerlComTrcvIfSpiErrCntr(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Pim_SerlComTrcvIfSpiErrCntr;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Pim_SerlComTrcvIfSpiErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SerlComTrcvIf_Pim_SerlComTrcvIfSt(void)
{
    extern __PST__UINT8 SerlComTrcvIf_Pim_SerlComTrcvIfSt;
    
    /* initialization with random value */
    {
        SerlComTrcvIf_Pim_SerlComTrcvIfSt = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SerlComTrcvIf_Srv_CnvSnpshtData_u16_SnpshtDataCnvd */
    _main_gen_init_sym_SerlComTrcvIf_Srv_CnvSnpshtData_u16_SnpshtDataCnvd();
    
    /* init for variable SerlComTrcvIf_Srv_CnvSnpshtData_u16_SnpshtData : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_SerlComTrcvIf_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable SerlComTrcvIf_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_SerlComTrcvIf_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_PinSt */
    _main_gen_init_sym_SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_PinSt();
    
    /* init for variable SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_Return */
    _main_gen_init_sym_SerlComTrcvIf_Srv_IoHwAb_GetGpioERRN_Return();
    
    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_SerlComTrcvIf_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable SerlComTrcvIf_Op_SerlComTrcvIfNoErr : useless (never read) */

    /* init for variable SerlComTrcvIf_Op_SerlComTrcvIfQlfr : useless (never read) */

    /* init for variable SerlComTrcvIf_Pim_dSerlComTrcvIfStsReg : useless (never read) */

    /* init for variable SerlComTrcvIf_Pim_SerlComTrcvIfFltErrPin */
    _main_gen_init_sym_SerlComTrcvIf_Pim_SerlComTrcvIfFltErrPin();
    
    /* init for variable SerlComTrcvIf_Pim_SerlComTrcvIfSpiErrCntr */
    _main_gen_init_sym_SerlComTrcvIf_Pim_SerlComTrcvIfSpiErrCntr();
    
    /* init for variable SerlComTrcvIf_Pim_SerlComTrcvIfSt */
    _main_gen_init_sym_SerlComTrcvIf_Pim_SerlComTrcvIfSt();
    
}
