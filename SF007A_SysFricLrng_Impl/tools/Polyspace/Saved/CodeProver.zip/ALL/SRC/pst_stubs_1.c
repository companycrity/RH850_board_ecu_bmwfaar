#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__61 _main_gen_init_g61(void);

extern struct __PST__g__59 _main_gen_init_g59(void);

extern struct __PST__g__57 _main_gen_init_g57(void);

extern __PST__g__55 _main_gen_init_g55(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__55 _main_gen_init_g55(void)
{
    __PST__g__55 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__57 _main_gen_init_g57(void)
{
    static struct __PST__g__57 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_18_0;
        
        for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 4; _main_gen_tmp_18_0++)
        {
            /* base type */
            x.BasLineFric[_main_gen_tmp_18_0] = pst_random_g_10;
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_19_0;
        
        for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 4; _main_gen_tmp_19_0++)
        {
            /* base type */
            x.VehLrndFric[_main_gen_tmp_19_0] = pst_random_g_10;
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_20_0;
        
        for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 8; _main_gen_tmp_20_0++)
        {
            __PST__UINT32 _main_gen_tmp_20_1;
            
            for (_main_gen_tmp_20_1 = 0; _main_gen_tmp_20_1 < 4; _main_gen_tmp_20_1++)
            {
                /* base type */
                x.Hys[_main_gen_tmp_20_0][_main_gen_tmp_20_1] = pst_random_g_10;
            }
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_21_0;
        
        for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 8; _main_gen_tmp_21_0++)
        {
            __PST__UINT32 _main_gen_tmp_21_1;
            
            for (_main_gen_tmp_21_1 = 0; _main_gen_tmp_21_1 < 3; _main_gen_tmp_21_1++)
            {
                /* base type */
                x.RngCntr[_main_gen_tmp_21_0][_main_gen_tmp_21_1] = pst_random_g_7;
            }
        }
    }
    x.FricOffs = _main_gen_init_g10();
    x.SysFricLrngOperMod = _main_gen_init_g6();
    return x;
}

struct __PST__g__59 _main_gen_init_g59(void)
{
    static struct __PST__g__59 x;
    /* struct/union type */
    x.EolFric = _main_gen_init_g10();
    x.EnaFricLrng = _main_gen_init_g6();
    x.EnaFricOffsOutp = _main_gen_init_g6();
    return x;
}

struct __PST__g__61 _main_gen_init_g61(void)
{
    static struct __PST__g__61 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SysFricLrng_Srv_FricLrngData_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 SysFricLrng_Srv_FricLrngData_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        SysFricLrng_Srv_FricLrngData_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Srv_FricNonLrngData_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 SysFricLrng_Srv_FricNonLrngData_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        SysFricLrng_Srv_FricNonLrngData_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 SysFricLrng_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        SysFricLrng_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 SysFricLrng_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        SysFricLrng_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 SysFricLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        SysFricLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SysFricLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 SysFricLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        SysFricLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricData_FricOffs(void)
{
    extern __PST__FLOAT32 SysFricLrng_Cli_GetFricData_FricOffs;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_GetFricData_FricOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricData_BasLineFric(void)
{
    extern __PST__g__41 SysFricLrng_Cli_GetFricData_BasLineFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 4; _main_gen_tmp_1_0++)
            {
                /* base type */
                SysFricLrng_Cli_GetFricData_BasLineFric[_main_gen_tmp_1_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricData_VehLrndFric(void)
{
    extern __PST__g__41 SysFricLrng_Cli_GetFricData_VehLrndFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                SysFricLrng_Cli_GetFricData_VehLrndFric[_main_gen_tmp_2_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricData_Hys(void)
{
    extern __PST__g__42 SysFricLrng_Cli_GetFricData_Hys;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 8; _main_gen_tmp_3_0++)
            {
                __PST__UINT32 _main_gen_tmp_3_1;
                
                for (_main_gen_tmp_3_1 = 0; _main_gen_tmp_3_1 < 4; _main_gen_tmp_3_1++)
                {
                    /* base type */
                    SysFricLrng_Cli_GetFricData_Hys[_main_gen_tmp_3_0][_main_gen_tmp_3_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricData_RngCntr(void)
{
    extern __PST__g__43 SysFricLrng_Cli_GetFricData_RngCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 8; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 3; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    SysFricLrng_Cli_GetFricData_RngCntr[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_FricLrngEna(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_GetFricLrngData_FricLrngEna;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_GetFricLrngData_FricLrngEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_FricLrngOffsOutpEna(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_GetFricLrngData_FricLrngOffsOutpEna;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_GetFricLrngData_FricLrngOffsOutpEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_FricLrngOperMod(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_GetFricLrngData_FricLrngOperMod;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_GetFricLrngData_FricLrngOperMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_EolFric(void)
{
    extern __PST__FLOAT32 SysFricLrng_Cli_GetFricLrngData_EolFric;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_GetFricLrngData_EolFric = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_GetFricOffsOutpDi_FricOffsOutpDi(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_GetFricOffsOutpDi_FricOffsOutpDi;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_GetFricOffsOutpDi_FricOffsOutpDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricData_FricOffs(void)
{
    extern __PST__FLOAT32 SysFricLrng_Cli_SetFricData_FricOffs;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_SetFricData_FricOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricData_BasLineFric(void)
{
    extern __PST__g__41 SysFricLrng_Cli_SetFricData_BasLineFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 4; _main_gen_tmp_5_0++)
            {
                /* base type */
                SysFricLrng_Cli_SetFricData_BasLineFric[_main_gen_tmp_5_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricData_VehLrndFric(void)
{
    extern __PST__g__41 SysFricLrng_Cli_SetFricData_VehLrndFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 4; _main_gen_tmp_6_0++)
            {
                /* base type */
                SysFricLrng_Cli_SetFricData_VehLrndFric[_main_gen_tmp_6_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricData_Hys(void)
{
    extern __PST__g__42 SysFricLrng_Cli_SetFricData_Hys;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 8; _main_gen_tmp_7_0++)
            {
                __PST__UINT32 _main_gen_tmp_7_1;
                
                for (_main_gen_tmp_7_1 = 0; _main_gen_tmp_7_1 < 4; _main_gen_tmp_7_1++)
                {
                    /* base type */
                    SysFricLrng_Cli_SetFricData_Hys[_main_gen_tmp_7_0][_main_gen_tmp_7_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricData_RngCntr(void)
{
    extern __PST__g__43 SysFricLrng_Cli_SetFricData_RngCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 8; _main_gen_tmp_8_0++)
            {
                __PST__UINT32 _main_gen_tmp_8_1;
                
                for (_main_gen_tmp_8_1 = 0; _main_gen_tmp_8_1 < 3; _main_gen_tmp_8_1++)
                {
                    /* base type */
                    SysFricLrng_Cli_SetFricData_RngCntr[_main_gen_tmp_8_0][_main_gen_tmp_8_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_FricLrngEna(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_SetFricLrngData_FricLrngEna;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_SetFricLrngData_FricLrngEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_FricLrngOffsOutpEna(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_SetFricLrngData_FricLrngOffsOutpEna;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_SetFricLrngData_FricLrngOffsOutpEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_FricLrngOperMod(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_SetFricLrngData_FricLrngOperMod;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_SetFricLrngData_FricLrngOperMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_EolFric(void)
{
    extern __PST__FLOAT32 SysFricLrng_Cli_SetFricLrngData_EolFric;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_SetFricLrngData_EolFric = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cli_SetFricOffsOutpDi_FricOffsOutpDi(void)
{
    extern __PST__UINT8 SysFricLrng_Cli_SetFricOffsOutpDi_FricOffsOutpDi;
    
    /* initialization with random value */
    {
        SysFricLrng_Cli_SetFricOffsOutpDi_FricOffsOutpDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_AssiMechT(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_AssiMechT;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_AssiMechT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_FricLrngCustEna(void)
{
    extern __PST__UINT8 SysFricLrng_Ip_FricLrngCustEna;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_FricLrngCustEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_FricLrngDi(void)
{
    extern __PST__UINT8 SysFricLrng_Ip_FricLrngDi;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_FricLrngDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_HwAg(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_HwAg;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_HwAgAuthy(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_HwAgAuthy;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_HwAgAuthy = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_HwTq(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_HwTq;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_HwVel(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_HwVel;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_MotTqCmdCrf(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_MotTqCmdCrf;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_MotTqCmdCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_VehLatA(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_VehLatA;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_VehLatA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 SysFricLrng_Ip_VehSpd;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Ip_VehSpdVld(void)
{
    extern __PST__UINT8 SysFricLrng_Ip_VehSpdVld;
    
    /* initialization with random value */
    {
        SysFricLrng_Ip_VehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngAvrgFricFrq(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngAvrgFricFrq;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngAvrgFricFrq = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineEolFric(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngBasLineEolFric;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngBasLineEolFric = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineFric(void)
{
    extern __PST__g__47 SysFricLrng_Cal_SysFricLrngBasLineFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 4; _main_gen_tmp_9_0++)
            {
                /* base type */
                SysFricLrng_Cal_SysFricLrngBasLineFric[_main_gen_tmp_9_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineHys(void)
{
    extern __PST__g__48 SysFricLrng_Cal_SysFricLrngBasLineHys;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 4; _main_gen_tmp_10_0++)
            {
                __PST__UINT32 _main_gen_tmp_10_1;
                
                for (_main_gen_tmp_10_1 = 0; _main_gen_tmp_10_1 < 8; _main_gen_tmp_10_1++)
                {
                    /* base type */
                    SysFricLrng_Cal_SysFricLrngBasLineHys[_main_gen_tmp_10_0][_main_gen_tmp_10_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineRngCntr(void)
{
    extern __PST__g__50 SysFricLrng_Cal_SysFricLrngBasLineRngCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 3; _main_gen_tmp_11_0++)
            {
                __PST__UINT32 _main_gen_tmp_11_1;
                
                for (_main_gen_tmp_11_1 = 0; _main_gen_tmp_11_1 < 8; _main_gen_tmp_11_1++)
                {
                    /* base type */
                    SysFricLrng_Cal_SysFricLrngBasLineRngCntr[_main_gen_tmp_11_0][_main_gen_tmp_11_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngDataPrepLpFilFrq(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngDataPrepLpFilFrq;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngDataPrepLpFilFrq = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngDebStep(void)
{
    extern __PST__g__32 SysFricLrng_Cal_SysFricLrngDebStep;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngDebStep = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngEolFricDifHiLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngEolFricDifHiLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngEolFricDifHiLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngEolFricDifLoLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngEolFricDifLoLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngEolFricDifLoLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngEolFricDifScagFac(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngEolFricDifScagFac;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngEolFricDifScagFac = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricChgWght(void)
{
    extern __PST__g__47 SysFricLrng_Cal_SysFricLrngFricChgWght;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 4; _main_gen_tmp_12_0++)
            {
                /* base type */
                SysFricLrng_Cal_SysFricLrngFricChgWght[_main_gen_tmp_12_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricDiagcThd(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngFricDiagcThd;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngFricDiagcThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricHysHwAgPt(void)
{
    extern __PST__g__47 SysFricLrng_Cal_SysFricLrngFricHysHwAgPt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 4; _main_gen_tmp_13_0++)
            {
                /* base type */
                SysFricLrng_Cal_SysFricLrngFricHysHwAgPt[_main_gen_tmp_13_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricOffsHiLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngFricOffsHiLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngFricOffsHiLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricOffsLoLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngFricOffsLoLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngFricOffsLoLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricOffsLpFilFrq(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngFricOffsLpFilFrq;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngFricOffsLpFilFrq = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngGain(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngGain;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngGain = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHiFricDebStep(void)
{
    extern __PST__g__32 SysFricLrng_Cal_SysFricLrngHiFricDebStep;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngHiFricDebStep = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHiFricDiagcThd(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngHiFricDiagcThd;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngHiFricDiagcThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwPosnAuthyThd(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngHwPosnAuthyThd;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngHwPosnAuthyThd = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwVelConstrLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngHwVelConstrLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngHwVelConstrLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwVelHiLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngHwVelHiLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngHwVelHiLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwVelLoLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngHwVelLoLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngHwVelLoLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIgnCycFricOffs(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngIgnCycFricOffs;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngIgnCycFricOffs = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIvsTrsmRatX(void)
{
    extern __PST__g__52 SysFricLrng_Cal_SysFricLrngIvsTrsmRatX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 10; _main_gen_tmp_14_0++)
            {
                /* base type */
                SysFricLrng_Cal_SysFricLrngIvsTrsmRatX[_main_gen_tmp_14_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIvsTrsmRatY(void)
{
    extern __PST__g__52 SysFricLrng_Cal_SysFricLrngIvsTrsmRatY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 10; _main_gen_tmp_15_0++)
            {
                /* base type */
                SysFricLrng_Cal_SysFricLrngIvsTrsmRatY[_main_gen_tmp_15_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngLatAHiLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngLatAHiLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngLatAHiLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngLatALoLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngLatALoLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngLatALoLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngMaskVehSpd(void)
{
    extern __PST__g__53 SysFricLrng_Cal_SysFricLrngMaskVehSpd;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 4; _main_gen_tmp_16_0++)
            {
                /* base type */
                SysFricLrng_Cal_SysFricLrngMaskVehSpd[_main_gen_tmp_16_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngRngCntrThd(void)
{
    extern __PST__g__32 SysFricLrng_Cal_SysFricLrngRngCntrThd;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngRngCntrThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngTHiLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngTHiLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngTHiLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngTLoLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngTLoLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngTLoLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngThd(void)
{
    extern __PST__g__55 SysFricLrng_Cal_SysFricLrngThd;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngThd = _main_gen_init_g55();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngVehSpd(void)
{
    extern __PST__g__56 SysFricLrng_Cal_SysFricLrngVehSpd;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 2; _main_gen_tmp_17_0++)
            {
                __PST__UINT32 _main_gen_tmp_17_1;
                
                for (_main_gen_tmp_17_1 = 0; _main_gen_tmp_17_1 < 4; _main_gen_tmp_17_1++)
                {
                    /* base type */
                    SysFricLrng_Cal_SysFricLrngVehSpd[_main_gen_tmp_17_0][_main_gen_tmp_17_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FricLrngData(void)
{
    extern struct __PST__g__57 SysFricLrng_Pim_FricLrngData;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_FricLrngData = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FricNonLrngData(void)
{
    extern struct __PST__g__59 SysFricLrng_Pim_FricNonLrngData;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_FricNonLrngData = _main_gen_init_g59();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_AssiMechTLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_AssiMechTLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_AssiMechTLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil1(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_AvrgFricLpFil1;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_AvrgFricLpFil1 = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil2(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_AvrgFricLpFil2;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_AvrgFricLpFil2 = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil3(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_AvrgFricLpFil3;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_AvrgFricLpFil3 = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil4(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_AvrgFricLpFil4;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_AvrgFricLpFil4 = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_ColTqAry(void)
{
    extern __PST__g__62 SysFricLrng_Pim_ColTqAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 12; _main_gen_tmp_22_0++)
            {
                /* base type */
                SysFricLrng_Pim_ColTqAry[_main_gen_tmp_22_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_ColTqLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_ColTqLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_ColTqLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_EstimdFric(void)
{
    extern __PST__FLOAT32 SysFricLrng_Pim_EstimdFric;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_EstimdFric = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FilAvrgFric(void)
{
    extern __PST__g__41 SysFricLrng_Pim_FilAvrgFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_23_0;
            
            for (_main_gen_tmp_23_0 = 0; _main_gen_tmp_23_0 < 4; _main_gen_tmp_23_0++)
            {
                /* base type */
                SysFricLrng_Pim_FilAvrgFric[_main_gen_tmp_23_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FricChgLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_FricChgLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_FricChgLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FricLrngOperModPrev(void)
{
    extern __PST__UINT8 SysFricLrng_Pim_FricLrngOperModPrev;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_FricLrngOperModPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FricOffs(void)
{
    extern __PST__FLOAT32 SysFricLrng_Pim_FricOffs;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_FricOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_FricOffsOutpDi(void)
{
    extern __PST__UINT8 SysFricLrng_Pim_FricOffsOutpDi;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_FricOffsOutpDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_HwAgAuthyLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_HwAgAuthyLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_HwAgAuthyLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_HwAgBuf(void)
{
    extern __PST__g__62 SysFricLrng_Pim_HwAgBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_24_0;
            
            for (_main_gen_tmp_24_0 = 0; _main_gen_tmp_24_0 < 12; _main_gen_tmp_24_0++)
            {
                /* base type */
                SysFricLrng_Pim_HwAgBuf[_main_gen_tmp_24_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_HwAgLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_HwAgLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_HwAgLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_HwVelBuf(void)
{
    extern __PST__g__62 SysFricLrng_Pim_HwVelBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_25_0;
            
            for (_main_gen_tmp_25_0 = 0; _main_gen_tmp_25_0 < 12; _main_gen_tmp_25_0++)
            {
                /* base type */
                SysFricLrng_Pim_HwVelBuf[_main_gen_tmp_25_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_HwVelLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_HwVelLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_HwVelLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_LatALpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_LatALpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_LatALpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_PrevMaxRawAvrgFric(void)
{
    extern __PST__FLOAT32 SysFricLrng_Pim_PrevMaxRawAvrgFric;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_PrevMaxRawAvrgFric = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_RawAvrgFric(void)
{
    extern __PST__g__41 SysFricLrng_Pim_RawAvrgFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_26_0;
            
            for (_main_gen_tmp_26_0 = 0; _main_gen_tmp_26_0 < 4; _main_gen_tmp_26_0++)
            {
                /* base type */
                SysFricLrng_Pim_RawAvrgFric[_main_gen_tmp_26_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_RefTmrLrngConstr(void)
{
    extern __PST__UINT32 SysFricLrng_Pim_RefTmrLrngConstr;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_RefTmrLrngConstr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_SatnAvrgFric(void)
{
    extern __PST__g__41 SysFricLrng_Pim_SatnAvrgFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_27_0;
            
            for (_main_gen_tmp_27_0 = 0; _main_gen_tmp_27_0 < 4; _main_gen_tmp_27_0++)
            {
                /* base type */
                SysFricLrng_Pim_SatnAvrgFric[_main_gen_tmp_27_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_SatnEstimdFric(void)
{
    extern __PST__FLOAT32 SysFricLrng_Pim_SatnEstimdFric;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_SatnEstimdFric = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_VehBasLineFric(void)
{
    extern __PST__g__41 SysFricLrng_Pim_VehBasLineFric;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_28_0;
            
            for (_main_gen_tmp_28_0 = 0; _main_gen_tmp_28_0 < 4; _main_gen_tmp_28_0++)
            {
                /* base type */
                SysFricLrng_Pim_VehBasLineFric[_main_gen_tmp_28_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_SysFricLrng_Pim_VehSpdLpFil(void)
{
    extern struct __PST__g__61 SysFricLrng_Pim_VehSpdLpFil;
    
    /* initialization with random value */
    {
        SysFricLrng_Pim_VehSpdLpFil = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIgnCycFricChgLim(void)
{
    extern __PST__g__30 SysFricLrng_Cal_SysFricLrngIgnCycFricChgLim;
    
    /* initialization with random value */
    {
        SysFricLrng_Cal_SysFricLrngIgnCycFricChgLim = _main_gen_init_g30();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SysFricLrng_Srv_FricLrngData_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable SysFricLrng_Srv_FricLrngData_SetRamBlockStatus_Return */
    _main_gen_init_sym_SysFricLrng_Srv_FricLrngData_SetRamBlockStatus_Return();
    
    /* init for variable SysFricLrng_Srv_FricNonLrngData_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable SysFricLrng_Srv_FricNonLrngData_SetRamBlockStatus_Return */
    _main_gen_init_sym_SysFricLrng_Srv_FricNonLrngData_SetRamBlockStatus_Return();
    
    /* init for variable SysFricLrng_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable SysFricLrng_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_SysFricLrng_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable SysFricLrng_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_SysFricLrng_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable SysFricLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_SysFricLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable SysFricLrng_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable SysFricLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_SysFricLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable SysFricLrng_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable SysFricLrng_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable SysFricLrng_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable SysFricLrng_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable SysFricLrng_Cli_GetFricData_FricOffs */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricData_FricOffs();
    
    /* init for variable SysFricLrng_Cli_GetFricData_BasLineFric */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricData_BasLineFric();
    
    /* init for variable SysFricLrng_Cli_GetFricData_VehLrndFric */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricData_VehLrndFric();
    
    /* init for variable SysFricLrng_Cli_GetFricData_Hys */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricData_Hys();
    
    /* init for variable SysFricLrng_Cli_GetFricData_RngCntr */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricData_RngCntr();
    
    /* init for variable SysFricLrng_Cli_GetFricLrngData_FricLrngEna */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_FricLrngEna();
    
    /* init for variable SysFricLrng_Cli_GetFricLrngData_FricLrngOffsOutpEna */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_FricLrngOffsOutpEna();
    
    /* init for variable SysFricLrng_Cli_GetFricLrngData_FricLrngOperMod */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_FricLrngOperMod();
    
    /* init for variable SysFricLrng_Cli_GetFricLrngData_EolFric */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricLrngData_EolFric();
    
    /* init for variable SysFricLrng_Cli_GetFricOffsOutpDi_FricOffsOutpDi */
    _main_gen_init_sym_SysFricLrng_Cli_GetFricOffsOutpDi_FricOffsOutpDi();
    
    /* init for variable SysFricLrng_Cli_SetFricData_FricOffs */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricData_FricOffs();
    
    /* init for variable SysFricLrng_Cli_SetFricData_BasLineFric */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricData_BasLineFric();
    
    /* init for variable SysFricLrng_Cli_SetFricData_VehLrndFric */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricData_VehLrndFric();
    
    /* init for variable SysFricLrng_Cli_SetFricData_Hys */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricData_Hys();
    
    /* init for variable SysFricLrng_Cli_SetFricData_RngCntr */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricData_RngCntr();
    
    /* init for variable SysFricLrng_Cli_SetFricLrngData_FricLrngEna */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_FricLrngEna();
    
    /* init for variable SysFricLrng_Cli_SetFricLrngData_FricLrngOffsOutpEna */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_FricLrngOffsOutpEna();
    
    /* init for variable SysFricLrng_Cli_SetFricLrngData_FricLrngOperMod */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_FricLrngOperMod();
    
    /* init for variable SysFricLrng_Cli_SetFricLrngData_EolFric */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricLrngData_EolFric();
    
    /* init for variable SysFricLrng_Cli_SetFricOffsOutpDi_FricOffsOutpDi */
    _main_gen_init_sym_SysFricLrng_Cli_SetFricOffsOutpDi_FricOffsOutpDi();
    
    /* init for variable SysFricLrng_Ip_AssiMechT */
    _main_gen_init_sym_SysFricLrng_Ip_AssiMechT();
    
    /* init for variable SysFricLrng_Ip_FricLrngCustEna */
    _main_gen_init_sym_SysFricLrng_Ip_FricLrngCustEna();
    
    /* init for variable SysFricLrng_Ip_FricLrngDi */
    _main_gen_init_sym_SysFricLrng_Ip_FricLrngDi();
    
    /* init for variable SysFricLrng_Ip_HwAg */
    _main_gen_init_sym_SysFricLrng_Ip_HwAg();
    
    /* init for variable SysFricLrng_Ip_HwAgAuthy */
    _main_gen_init_sym_SysFricLrng_Ip_HwAgAuthy();
    
    /* init for variable SysFricLrng_Ip_HwTq */
    _main_gen_init_sym_SysFricLrng_Ip_HwTq();
    
    /* init for variable SysFricLrng_Ip_HwVel */
    _main_gen_init_sym_SysFricLrng_Ip_HwVel();
    
    /* init for variable SysFricLrng_Ip_MotTqCmdCrf */
    _main_gen_init_sym_SysFricLrng_Ip_MotTqCmdCrf();
    
    /* init for variable SysFricLrng_Ip_VehLatA */
    _main_gen_init_sym_SysFricLrng_Ip_VehLatA();
    
    /* init for variable SysFricLrng_Ip_VehSpd */
    _main_gen_init_sym_SysFricLrng_Ip_VehSpd();
    
    /* init for variable SysFricLrng_Ip_VehSpdVld */
    _main_gen_init_sym_SysFricLrng_Ip_VehSpdVld();
    
    /* init for variable SysFricLrng_Op_MaxLrndFric : useless (never read) */

    /* init for variable SysFricLrng_Op_SysFricEstimd : useless (never read) */

    /* init for variable SysFricLrng_Op_SysFricOffs : useless (never read) */

    /* init for variable SysFricLrng_Op_SysSatnFricEstimd : useless (never read) */

    /* init for variable SysFricLrng_Cal_SysFricLrngAvrgFricFrq */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngAvrgFricFrq();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngBasLineEolFric */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineEolFric();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngBasLineFric */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineFric();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngBasLineHys */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineHys();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngBasLineRngCntr */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngBasLineRngCntr();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngDataPrepLpFilFrq */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngDataPrepLpFilFrq();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngDebStep */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngDebStep();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngEolFricDifHiLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngEolFricDifHiLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngEolFricDifLoLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngEolFricDifLoLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngEolFricDifScagFac */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngEolFricDifScagFac();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngFricChgWght */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricChgWght();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngFricDiagcThd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricDiagcThd();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngFricHysHwAgPt */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricHysHwAgPt();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngFricOffsHiLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricOffsHiLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngFricOffsLoLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricOffsLoLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngFricOffsLpFilFrq */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngFricOffsLpFilFrq();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngGain */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngGain();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngHiFricDebStep */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHiFricDebStep();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngHiFricDiagcThd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHiFricDiagcThd();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngHwPosnAuthyThd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwPosnAuthyThd();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngHwVelConstrLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwVelConstrLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngHwVelHiLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwVelHiLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngHwVelLoLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngHwVelLoLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngIgnCycFricOffs */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIgnCycFricOffs();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngIvsTrsmRatX */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIvsTrsmRatX();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngIvsTrsmRatY */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIvsTrsmRatY();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngLatAHiLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngLatAHiLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngLatALoLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngLatALoLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngMaskVehSpd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngMaskVehSpd();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngRngCntrThd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngRngCntrThd();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngTHiLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngTHiLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngTLoLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngTLoLim();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngThd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngThd();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngVehSpd */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngVehSpd();
    
    /* init for variable SysFricLrng_Pim_FricLrngData */
    _main_gen_init_sym_SysFricLrng_Pim_FricLrngData();
    
    /* init for variable SysFricLrng_Pim_FricNonLrngData */
    _main_gen_init_sym_SysFricLrng_Pim_FricNonLrngData();
    
    /* init for variable SysFricLrng_Pim_AssiMechTLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_AssiMechTLpFil();
    
    /* init for variable SysFricLrng_Pim_AvrgFricLpFil1 */
    _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil1();
    
    /* init for variable SysFricLrng_Pim_AvrgFricLpFil2 */
    _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil2();
    
    /* init for variable SysFricLrng_Pim_AvrgFricLpFil3 */
    _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil3();
    
    /* init for variable SysFricLrng_Pim_AvrgFricLpFil4 */
    _main_gen_init_sym_SysFricLrng_Pim_AvrgFricLpFil4();
    
    /* init for variable SysFricLrng_Pim_ColTqAry */
    _main_gen_init_sym_SysFricLrng_Pim_ColTqAry();
    
    /* init for variable SysFricLrng_Pim_ColTqLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_ColTqLpFil();
    
    /* init for variable SysFricLrng_Pim_EstimdFric */
    _main_gen_init_sym_SysFricLrng_Pim_EstimdFric();
    
    /* init for variable SysFricLrng_Pim_FilAvrgFric */
    _main_gen_init_sym_SysFricLrng_Pim_FilAvrgFric();
    
    /* init for variable SysFricLrng_Pim_FricChgLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_FricChgLpFil();
    
    /* init for variable SysFricLrng_Pim_FricLrngOperModPrev */
    _main_gen_init_sym_SysFricLrng_Pim_FricLrngOperModPrev();
    
    /* init for variable SysFricLrng_Pim_FricLrngRunOneTi : useless (never read) */

    /* init for variable SysFricLrng_Pim_FricOffs */
    _main_gen_init_sym_SysFricLrng_Pim_FricOffs();
    
    /* init for variable SysFricLrng_Pim_FricOffsOutpDi */
    _main_gen_init_sym_SysFricLrng_Pim_FricOffsOutpDi();
    
    /* init for variable SysFricLrng_Pim_HwAgAuthyLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_HwAgAuthyLpFil();
    
    /* init for variable SysFricLrng_Pim_HwAgBuf */
    _main_gen_init_sym_SysFricLrng_Pim_HwAgBuf();
    
    /* init for variable SysFricLrng_Pim_HwAgLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_HwAgLpFil();
    
    /* init for variable SysFricLrng_Pim_HwVelBuf */
    _main_gen_init_sym_SysFricLrng_Pim_HwVelBuf();
    
    /* init for variable SysFricLrng_Pim_HwVelLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_HwVelLpFil();
    
    /* init for variable SysFricLrng_Pim_LatALpFil */
    _main_gen_init_sym_SysFricLrng_Pim_LatALpFil();
    
    /* init for variable SysFricLrng_Pim_PrevMaxRawAvrgFric */
    _main_gen_init_sym_SysFricLrng_Pim_PrevMaxRawAvrgFric();
    
    /* init for variable SysFricLrng_Pim_RawAvrgFric */
    _main_gen_init_sym_SysFricLrng_Pim_RawAvrgFric();
    
    /* init for variable SysFricLrng_Pim_RefTmrLrngConstr */
    _main_gen_init_sym_SysFricLrng_Pim_RefTmrLrngConstr();
    
    /* init for variable SysFricLrng_Pim_SatnAvrgFric */
    _main_gen_init_sym_SysFricLrng_Pim_SatnAvrgFric();
    
    /* init for variable SysFricLrng_Pim_SatnEstimdFric */
    _main_gen_init_sym_SysFricLrng_Pim_SatnEstimdFric();
    
    /* init for variable SysFricLrng_Pim_VehBasLineFric */
    _main_gen_init_sym_SysFricLrng_Pim_VehBasLineFric();
    
    /* init for variable SysFricLrng_Pim_VehSpdLpFil */
    _main_gen_init_sym_SysFricLrng_Pim_VehSpdLpFil();
    
    /* init for variable SysFricLrng_Cal_SysFricLrngIgnCycFricChgLim */
    _main_gen_init_sym_SysFricLrng_Cal_SysFricLrngIgnCycFricChgLim();
    
}
