/* Contract file for CM104A */

#define MCUDIAGCERRINJ STD_OFF

extern void ClrErrInjReg_Oper(void);
extern void ReadErrInjReg_Oper(uint32* ErrId);


#if (MCUDIAGCERRINJ == STD_ON)
extern void InjEcmMstChkrRtErr(void);
extern void InjUkwnStrtUpDetdErr(void);
#define MCUERRINJ_NTC0026BIT02CASE01_CNT_U32                                    0x00260401U
#define MCUERRINJ_NTC0026BIT03CASE01_CNT_U32                                    0x00260801U
#define MCUERRINJ_NTC0021BIT07CASE01_CNT_U32                                    0x00218001U
#define MCUERRINJ_NTC0026BIT00CASE01_CNT_U32                                    0x00260101U
#define MCUERRINJ_NTC0026BIT01CASE01_CNT_U32                                    0x00260201U
#define MCUERRINJ_NTC0026BIT00CASE02_CNT_U32                                    0x00260102U
#define MCUERRINJ_NTC0026BIT04CASE01_CNT_U32                                    0x00261001U
#define MCUERRINJ_NTC0026BIT04CASE02_CNT_U32                                    0x00261002U
#define MCUERRINJ_NTC0026BIT07CASE01_CNT_U32                                    0x00268001U
#define MCUERRINJ_NTC0026BIT07CASE02_CNT_U32                                    0x00268002U
#define MCUERRINJ_NTC0029BIT01CASE01_CNT_U32                                    0x00290201U

#endif


