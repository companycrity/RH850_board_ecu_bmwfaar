/* Contract file for CM104A */
#ifndef NXTRMCUSUPRTLIB_H
#define NXTRMCUSUPRTLIB_H

extern void WrProtdRegEcm_u32(uint32, volatile uint32*);
extern void WrProtdRegEcmm_u08(uint32, volatile uint8*);
extern void WrProtdRegEcmc_u08(uint32, volatile uint8*);

#endif
