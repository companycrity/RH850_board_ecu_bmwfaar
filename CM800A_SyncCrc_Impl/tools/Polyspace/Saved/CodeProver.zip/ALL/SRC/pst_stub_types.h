typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT8 *__PST__g__16;
typedef __PST__UINT16 *__PST__g__17;
typedef __PST__UINT8 __PST__g__15(__PST__g__16, __PST__UINT32, __PST__UINT16, __PST__UINT8, __PST__g__17);
typedef __PST__UINT8 __PST__g__18(__PST__g__17, __PST__UINT32, __PST__UINT16, __PST__UINT8, __PST__g__17);
typedef __PST__UINT32 *__PST__g__20;
typedef __PST__UINT8 __PST__g__19(__PST__g__16, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__21(__PST__g__17, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__22(__PST__g__20, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__23(__PST__g__16, __PST__UINT32, __PST__UINT8, __PST__UINT8, __PST__g__16);
typedef __PST__UINT8 __PST__g__24(__PST__UINT8, __PST__UINT8, __PST__g__20, __PST__g__20, __PST__UINT32, __PST__g__20);
typedef __PST__VOID __PST__g__25(void);
typedef __PST__VOID __PST__g__26(__PST__UINT16, __PST__g__11);
typedef const __PST__UINT32 __PST__g__29;
typedef __PST__g__29 __PST__g__28[8];
typedef volatile struct __PST__g__35 __PST__g__34;
typedef __PST__g__34 *__PST__g__33;
struct __PST__g__32
  {
    __PST__g__33 Reg_rec;
  };
typedef const struct __PST__g__32 __PST__g__31;
typedef __PST__g__31 __PST__g__30[8];
typedef __PST__SINT8 __PST__g__102[24];
struct __PST__g__38
  {
    __PST__UINT8 POL : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 ISZ : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 2;
  };
union __PST__g__37
  {
    struct __PST__g__38 Bit_b08;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef __PST__SINT8 __PST__g__40[3];
struct __PST__g__35
  {
    __PST__UINT32 Inp_u32;
    __PST__UINT32 Outp_u32;
    __PST__g__102 __pst_unused_field_2;
    union __PST__g__37 Ctrl_rec;
    __PST__g__40 __pst_unused_field___pstfiller;
  };
typedef __PST__UINT32 __PST__g__36[6];
typedef __PST__FLOAT64 __PST__g__41(void);
typedef __PST__g__11 *__PST__g__42;
typedef volatile __PST__FLOAT64 __PST__g__43;
typedef __PST__SINT8 *__PST__g__45;
typedef volatile __PST__g__45 __PST__g__44;
struct __PST__g__47
  {
    __PST__UINT32 TaskId;
    __PST__UINT8 CrcHwSts;
    __PST__g__40 __pst_unused_field___pstfiller;
  };
typedef struct __PST__g__47 __PST__g__46[8];
typedef __PST__VOID __PST__g__48(__PST__SINT32);
typedef __PST__UINT8 __PST__g__49(__PST__g__17);
typedef __PST__UINT8 __PST__g__50(void);
typedef __PST__UINT8 __PST__g__51(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT8);
typedef __PST__g__46 *__PST__g__52;
struct __PST__g__53
  {
    __PST__UINT8 CrcHwIdx;
  };
struct __PST__g__54
  {
    __PST__UINT8 ResvCall;
  };
typedef __PST__g__49 *__PST__g__55;
typedef __PST__VOID __PST__g__56(__PST__UINT8);
typedef __PST__g__56 *__PST__g__57;
typedef struct __PST__g__54 *__PST__g__58;
typedef __PST__g__26 *__PST__g__59;
typedef __PST__g__50 *__PST__g__60;
typedef struct __PST__g__47 *__PST__g__61;
typedef __PST__g__30 *__PST__g__62;
typedef __PST__g__31 *__PST__g__63;
typedef const __PST__g__33 __PST__g__64;
typedef __PST__g__64 *__PST__g__65;
typedef volatile union __PST__g__37 __PST__g__66;
typedef __PST__g__66 *__PST__g__67;
typedef volatile struct __PST__g__38 __PST__g__68;
typedef __PST__g__68 *__PST__g__69;
typedef volatile __PST__UINT32 __PST__g__72;
typedef __PST__g__72 *__PST__g__73;
typedef __PST__g__48 *__PST__g__74;
typedef struct __PST__g__53 *__PST__g__75;
typedef __PST__g__51 *__PST__g__76;
typedef __PST__g__28 *__PST__g__77;
typedef __PST__g__29 *__PST__g__78;
typedef __PST__VOID __PST__g__79(__PST__UINT8, __PST__UINT8, __PST__UINT32);
typedef __PST__g__79 *__PST__g__80;
typedef __PST__g__25 *__PST__g__81;
typedef __PST__SINT32 __PST__g__82();
typedef __PST__g__82 *__PST__g__83;
typedef __PST__g__15 *__PST__g__84;
typedef __PST__g__18 *__PST__g__85;
typedef __PST__g__19 *__PST__g__86;
typedef __PST__g__21 *__PST__g__87;
typedef __PST__g__22 *__PST__g__88;
typedef __PST__g__23 *__PST__g__89;
typedef __PST__g__24 *__PST__g__90;
typedef volatile __PST__SINT32 __PST__g__91;
typedef __PST__SINT8 __PST__g__97(void);
typedef volatile __PST__SINT8 __PST__g__98;
typedef volatile __PST__UINT8 __PST__g__99;
typedef __PST__SINT32 __PST__g__100(void);
typedef __PST__UINT32 __PST__g__101(void);
