#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct __PST__g__38 _main_gen_init_g38(void);

extern union __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__38 _main_gen_init_g38(void)
{
    static struct __PST__g__38 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x.POL = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x.ISZ = bitf;
    }
    return x;
}

union __PST__g__37 _main_gen_init_g37(void)
{
    static union __PST__g__37 x;
    /* struct/union type */
    x.Bit_b08 = _main_gen_init_g38();
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* struct/union type */
    x.Ctrl_rec = _main_gen_init_g37();
    x.Inp_u32 = _main_gen_init_g8();
    x.Outp_u32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SyncCrc_Pim_CrcHwSts(void)
{
    extern __PST__g__46 SyncCrc_Pim_CrcHwSts;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 8; _main_gen_tmp_4_0++)
            {
                /* struct/union type */
                SyncCrc_Pim_CrcHwSts[_main_gen_tmp_4_0].TaskId = _main_gen_init_g8();
                SyncCrc_Pim_CrcHwSts[_main_gen_tmp_4_0].CrcHwSts = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DATACRCREGCH0(void)
{
    extern __PST__g__34 DATACRCREGCH0;
    
    /* initialization with random value */
    {
        DATACRCREGCH0 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH1(void)
{
    extern __PST__g__34 DATACRCREGCH1;
    
    /* initialization with random value */
    {
        DATACRCREGCH1 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH2(void)
{
    extern __PST__g__34 DATACRCREGCH2;
    
    /* initialization with random value */
    {
        DATACRCREGCH2 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH3(void)
{
    extern __PST__g__34 DATACRCREGCH3;
    
    /* initialization with random value */
    {
        DATACRCREGCH3 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH4(void)
{
    extern __PST__g__34 DATACRCREGCH4;
    
    /* initialization with random value */
    {
        DATACRCREGCH4 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH5(void)
{
    extern __PST__g__34 DATACRCREGCH5;
    
    /* initialization with random value */
    {
        DATACRCREGCH5 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH6(void)
{
    extern __PST__g__34 DATACRCREGCH6;
    
    /* initialization with random value */
    {
        DATACRCREGCH6 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DATACRCREGCH7(void)
{
    extern __PST__g__34 DATACRCREGCH7;
    
    /* initialization with random value */
    {
        DATACRCREGCH7 = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_DataPtr(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc16BitCrc_u08_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u08_DataPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc16BitCrc_u08_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u08_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_StrtVal(void)
{
    extern __PST__UINT16 SyncCrc_Cli_Calc16BitCrc_u08_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u08_StrtVal = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc16BitCrc_u08_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u08_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_CalcCrcRes(void)
{
    extern __PST__UINT16 SyncCrc_Cli_Calc16BitCrc_u08_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u08_CalcCrcRes = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_DataPtr(void)
{
    extern __PST__UINT16 SyncCrc_Cli_Calc16BitCrc_u16_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u16_DataPtr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc16BitCrc_u16_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u16_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_StrtVal(void)
{
    extern __PST__UINT16 SyncCrc_Cli_Calc16BitCrc_u16_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u16_StrtVal = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc16BitCrc_u16_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u16_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_CalcCrcRes(void)
{
    extern __PST__UINT16 SyncCrc_Cli_Calc16BitCrc_u16_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc16BitCrc_u16_CalcCrcRes = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_DataPtr(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc32BitCrc_u08_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u08_DataPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u08_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u08_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_StrtVal(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u08_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u08_StrtVal = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc32BitCrc_u08_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u08_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_CalcCrcRes(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u08_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u08_CalcCrcRes = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_DataPtr(void)
{
    extern __PST__UINT16 SyncCrc_Cli_Calc32BitCrc_u16_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u16_DataPtr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u16_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u16_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_StrtVal(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u16_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u16_StrtVal = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc32BitCrc_u16_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u16_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_CalcCrcRes(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u16_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u16_CalcCrcRes = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_DataPtr(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u32_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u32_DataPtr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u32_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u32_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_StrtVal(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u32_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u32_StrtVal = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc32BitCrc_u32_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u32_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_CalcCrcRes(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc32BitCrc_u32_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc32BitCrc_u32_CalcCrcRes = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_DataPtr(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc_DataPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc8BitCrc_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_StrtVal(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc_StrtVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_CalcCrcRes(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc_CalcCrcRes = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_DataPtr(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc0X2F_DataPtr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc0X2F_DataPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_Len(void)
{
    extern __PST__UINT32 SyncCrc_Cli_Calc8BitCrc0X2F_Len;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc0X2F_Len = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_StrtVal(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc0X2F_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc0X2F_StrtVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_FirstCall(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc0X2F_FirstCall;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc0X2F_FirstCall = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_CalcCrcRes(void)
{
    extern __PST__UINT8 SyncCrc_Cli_Calc8BitCrc0X2F_CalcCrcRes;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_Calc8BitCrc0X2F_CalcCrcRes = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_Mod(void)
{
    extern __PST__UINT8 SyncCrc_Cli_ResvCrcHwUnit_Mod;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_ResvCrcHwUnit_Mod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_CrcCfg(void)
{
    extern __PST__UINT8 SyncCrc_Cli_ResvCrcHwUnit_CrcCfg;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_ResvCrcHwUnit_CrcCfg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_CrcHwInRegAdr(void)
{
    extern __PST__UINT32 SyncCrc_Cli_ResvCrcHwUnit_CrcHwInRegAdr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_ResvCrcHwUnit_CrcHwInRegAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_CrcHwOutRegAdr(void)
{
    extern __PST__UINT32 SyncCrc_Cli_ResvCrcHwUnit_CrcHwOutRegAdr;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_ResvCrcHwUnit_CrcHwOutRegAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_StrtVal(void)
{
    extern __PST__UINT32 SyncCrc_Cli_ResvCrcHwUnit_StrtVal;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_ResvCrcHwUnit_StrtVal = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_ResvKey(void)
{
    extern __PST__UINT32 SyncCrc_Cli_ResvCrcHwUnit_ResvKey;
    
    /* initialization with random value */
    {
        SyncCrc_Cli_ResvCrcHwUnit_ResvKey = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SyncCrc_Pim_CrcHwSts */
    _main_gen_init_sym_SyncCrc_Pim_CrcHwSts();
    
    /* init for variable DATACRCREGCH0 */
    _main_gen_init_sym_DATACRCREGCH0();
    
    /* init for variable DATACRCREGCH1 */
    _main_gen_init_sym_DATACRCREGCH1();
    
    /* init for variable DATACRCREGCH2 */
    _main_gen_init_sym_DATACRCREGCH2();
    
    /* init for variable DATACRCREGCH3 */
    _main_gen_init_sym_DATACRCREGCH3();
    
    /* init for variable DATACRCREGCH4 */
    _main_gen_init_sym_DATACRCREGCH4();
    
    /* init for variable DATACRCREGCH5 */
    _main_gen_init_sym_DATACRCREGCH5();
    
    /* init for variable DATACRCREGCH6 */
    _main_gen_init_sym_DATACRCREGCH6();
    
    /* init for variable DATACRCREGCH7 */
    _main_gen_init_sym_DATACRCREGCH7();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u08_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u08_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_Len();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u08_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u08_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u08_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u08_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u08_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_Calc16BitCrc_u16_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u16_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_Len();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u16_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u16_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u16_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc16BitCrc_u16_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc16BitCrc_u16_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_Calc32BitCrc_u08_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u08_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_Len();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u08_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u08_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u08_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u08_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u08_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_Calc32BitCrc_u16_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u16_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_Len();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u16_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u16_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u16_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u16_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u16_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_Calc32BitCrc_u32_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u32_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_Len();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u32_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u32_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u32_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc32BitCrc_u32_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc32BitCrc_u32_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_Calc8BitCrc_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_Len();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_Calc8BitCrc0X2F_DataPtr */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_DataPtr();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc0X2F_Len */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_Len();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc0X2F_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_StrtVal();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc0X2F_FirstCall */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_FirstCall();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc0X2F_CalcCrcRes */
    _main_gen_init_sym_SyncCrc_Cli_Calc8BitCrc0X2F_CalcCrcRes();
    
    /* init for variable SyncCrc_Cli_Calc8BitCrc0X2F_Return : useless (never read) */

    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_Mod */
    _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_Mod();
    
    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_CrcCfg */
    _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_CrcCfg();
    
    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_CrcHwInRegAdr */
    _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_CrcHwInRegAdr();
    
    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_CrcHwOutRegAdr */
    _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_CrcHwOutRegAdr();
    
    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_StrtVal */
    _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_StrtVal();
    
    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_ResvKey */
    _main_gen_init_sym_SyncCrc_Cli_ResvCrcHwUnit_ResvKey();
    
    /* init for variable SyncCrc_Cli_ResvCrcHwUnit_Return : useless (never read) */

}
