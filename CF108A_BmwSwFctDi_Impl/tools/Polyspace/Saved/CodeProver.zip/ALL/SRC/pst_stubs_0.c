#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_BmwSwFctDi_CtrldVelRtnCmd_Val
 */


__PST__UINT8 Rte_Read_BmwSwFctDi_CtrldVelRtnCmd_Val(__PST__g__38 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwSwFctDi_HwTqCmdHys_Val
 */


__PST__UINT8 Rte_Read_BmwSwFctDi_HwTqCmdHys_Val(__PST__g__38 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwSwFctDi_InertiaCmpVelCmdDi_Logl
 */


__PST__UINT8 Rte_Read_BmwSwFctDi_InertiaCmpVelCmdDi_Logl(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwSwFctDi_PullCmpCmdDi_Logl
 */


__PST__UINT8 Rte_Read_BmwSwFctDi_PullCmpCmdDi_Logl(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_BmwOutpTqOvrlCmdEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_BmwOutpTqOvrlCmdEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_BmwOutpTqOvrlCmdEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_BmwStrtStopMsgEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_BmwStrtStopMsgEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_BmwStrtStopMsgEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_CtrldVelRtnCmdBmwOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_CtrldVelRtnCmdBmwOvrd_Val"


__PST__UINT8 Rte_Write_BmwSwFctDi_CtrldVelRtnCmdBmwOvrd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_DampgCmdPwrPrkgEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_DampgCmdPwrPrkgEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_DampgCmdPwrPrkgEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_DrvgDynFacEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_DrvgDynFacEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_DrvgDynFacEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_FricLrngCustEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_FricLrngCustEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_FricLrngCustEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_HaptcFbEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_HaptcFbEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_HaptcFbEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_HwTqCmdHysBmwOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_HwTqCmdHysBmwOvrd_Val"


__PST__UINT8 Rte_Write_BmwSwFctDi_HwTqCmdHysBmwOvrd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_HwTqOvrlCmdEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_HwTqOvrlCmdEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_HwTqOvrlCmdEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_InertiaCmpVelCmdDiBmwOvrd_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_InertiaCmpVelCmdDiBmwOvrd_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_InertiaCmpVelCmdDiBmwOvrd_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_MaxCurrAtHiSpd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_MaxCurrAtHiSpd_Val"


__PST__UINT8 Rte_Write_BmwSwFctDi_MaxCurrAtHiSpd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_MaxCurrAtLoSpd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_MaxCurrAtLoSpd_Val"


__PST__UINT8 Rte_Write_BmwSwFctDi_MaxCurrAtLoSpd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_PullCmpCmdDiBmwOvrd_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_PullCmpCmdDiBmwOvrd_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_PullCmpCmdDiBmwOvrd_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_TrfcJamAssiCmdEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_TrfcJamAssiCmdEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_TrfcJamAssiCmdEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwSwFctDi_TunSetHndlrEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwSwFctDi_TunSetHndlrEna_Logl"


__PST__UINT8 Rte_Write_BmwSwFctDi_TunSetHndlrEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Mode_BmwSwFctDi_Coding_DataMode_Mode
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Mode_BmwSwFctDi_Coding_DataMode_Mode"


__PST__UINT8 Rte_Mode_BmwSwFctDi_Coding_DataMode_Mode(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME00_01_CalculationOfActiveReturn
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME00_01_CalculationOfActiveReturn(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME00_03_ActiveInfluenceOnTheSteeringHysterisis
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME00_03_ActiveInfluenceOnTheSteeringHysterisis(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME01_03_ParkingPowerDamping
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME01_03_ParkingPowerDamping(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME02_00_CompensationOfFriction
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME02_00_CompensationOfFriction(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME02_01_CompensationOfConstantSteeringPullAndLateralInclinationPull
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME02_01_CompensationOfConstantSteeringPullAndLateralInclinationPull(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME02_04_CompensationOfInertiaOfTheSteeringGear
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME02_04_CompensationOfInertiaOfTheSteeringGear(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME02_05_CompensationOfInertiaOfTheSteeringWheel
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME02_05_CompensationOfInertiaOfTheSteeringWheel(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_00_DrivingDynamicsInterfaceMinusDriversTorque
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_00_DrivingDynamicsInterfaceMinusDriversTorque(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_00_DrivingDynamicsInterfaceMinusMotorTorque
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_00_DrivingDynamicsInterfaceMinusMotorTorque(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_02_DrivingDynamicsInterfaceMinusFactors
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_02_DrivingDynamicsInterfaceMinusFactors(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_03_DrivingDynamicsInterfaceMinusAdditionalDamping
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_03_DrivingDynamicsInterfaceMinusAdditionalDamping(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_04_EPSVibration
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_04_EPSVibration(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_05_DrivingExperienceSwitch
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_05_DrivingExperienceSwitch(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwSwFctDi_Data_GetNAME04_07_automaticEngineStartStopFunction
 */


__PST__UINT8 Rte_Call_BmwSwFctDi_Data_GetNAME04_07_automaticEngineStartStopFunction(__PST__g__50 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwActvRtnOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwActvRtnOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwActvRtnOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwEngStrtStopOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwEngStrtStopOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwEngStrtStopOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwEpsOscnOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwEpsOscnOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwEpsOscnOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwFricCmpOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwFricCmpOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwFricCmpOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwGearInertiaCmpOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwGearInertiaCmpOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwGearInertiaCmpOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwHwInertiaCmpOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwHwInertiaCmpOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwHwInertiaCmpOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwHysActvInflOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwHysActvInflOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwHysActvInflOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegDampgOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegDampgOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegDampgOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegFacOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegFacOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegFacOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegHwTqOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegHwTqOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegHwTqOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegMotTqOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegMotTqOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwIfNegMotTqOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwLrnSwtOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwLrnSwtOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwLrnSwtOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwPrkgPwrDampgOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwPrkgPwrDampgOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiBmwPrkgPwrDampgOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiCodingOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiCodingOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiCodingOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiMaxCurrAtHiSpdOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiMaxCurrAtHiSpdOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiMaxCurrAtHiSpdOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwSwFctDi_BmwSwFctDiMaxCurrAtLoSpdOvrd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwSwFctDi_BmwSwFctDiMaxCurrAtLoSpdOvrd_Val"


__PST__UINT8 Rte_Prm_BmwSwFctDi_BmwSwFctDiMaxCurrAtLoSpdOvrd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__SINT32 fabsf(__PST__FLOAT64 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * atan2f
 */

#pragma POLYSPACE_POLYMORPHIC "atan2f"


__PST__SINT32 atan2f(__PST__FLOAT64 P_0, __PST__FLOAT64 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * sinf
 */

#pragma POLYSPACE_POLYMORPHIC "sinf"


__PST__SINT32 sinf(__PST__FLOAT64 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * cosf
 */

#pragma POLYSPACE_POLYMORPHIC "cosf"


__PST__SINT32 cosf(__PST__FLOAT64 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__SINT32 expf(__PST__FLOAT64 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * sqrtf
 */

#pragma POLYSPACE_POLYMORPHIC "sqrtf"


__PST__SINT32 sqrtf(__PST__FLOAT64 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fmodf
 */

#pragma POLYSPACE_POLYMORPHIC "fmodf"


__PST__SINT32 fmodf(__PST__FLOAT64 P_0, __PST__FLOAT64 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT32 real_random_for_return  = 0;
        __PST__SINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

