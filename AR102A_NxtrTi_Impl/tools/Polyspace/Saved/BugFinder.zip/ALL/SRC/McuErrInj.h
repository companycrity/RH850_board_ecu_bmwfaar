/* Contract file for AR102A */
#define MCUDIAGCERRINJ  STD_OFF

#if (MCUDIAGCERRINJ == STD_ON)

#define MCUERRINJ_NTC0039BIT00CASE01_CNT_U32                                    0x00390101U
#define MCUERRINJ_NTC0039BIT00CASE02_CNT_U32                                    0x00390102U
#define MCUERRINJ_NTC0039BIT00CASE03_CNT_U32                                    0x00390103U
#define MCUERRINJ_NTC0039BIT00CASE04_CNT_U32                                    0x00390104U

#endif

