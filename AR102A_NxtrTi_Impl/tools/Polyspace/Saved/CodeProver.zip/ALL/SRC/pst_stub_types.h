typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT32 *__PST__g__16;
typedef __PST__VOID __PST__g__15(__PST__g__16);
typedef __PST__VOID __PST__g__17(__PST__UINT32, __PST__g__16);
typedef __PST__VOID __PST__g__18(void);
typedef __PST__UINT8 __PST__g__19(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__FLOAT64 __PST__g__20(void);
typedef __PST__g__11 *__PST__g__22;
typedef volatile __PST__FLOAT64 __PST__g__23;
typedef __PST__SINT8 *__PST__g__25;
typedef volatile __PST__g__25 __PST__g__24;
typedef const __PST__UINT32 __PST__g__28;
typedef __PST__SINT8 __PST__g__128[1];
typedef __PST__SINT8 __PST__g__129[3];
struct __PST__g__46
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 TE03 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef const struct __PST__g__46 __PST__g__45;
union __PST__g__44
  {
    __PST__g__45 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__44 __PST__g__43;
struct __PST__g__49
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 TS03 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__48
  {
    struct __PST__g__49 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef __PST__SINT8 __PST__g__130[19];
typedef __PST__SINT8 __PST__g__131[2];
typedef __PST__SINT16 __PST__g__133[1];
union __PST__g__65
  {
    __PST__g__133 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
struct __PST__g__71
  {
    __PST__UINT16 __pst_unused_field_0 : 4;
    __PST__UINT16 __pst_unused_field_1 : 4;
    __PST__UINT16 __pst_unused_field_2 : 4;
    __PST__UINT16 PRS3 : 4;
  };
union __PST__g__70
  {
    struct __PST__g__71 BIT;
    __PST__UINT16 __pst_unused_field_1;
  };
typedef __PST__SINT8 __PST__g__132[3931];
struct __PST__g__27
  {
    __PST__UINT32 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__UINT32 CDR3;
    __PST__g__28 __pst_unused_field_4;
    __PST__g__28 __pst_unused_field_5;
    __PST__g__28 __pst_unused_field_6;
    __PST__g__28 CNT3;
    __PST__g__128 __pst_unused_field_8;
    __PST__g__129 __pst_unused_field_9;
    __PST__g__128 __pst_unused_field_10;
    __PST__g__129 __pst_unused_field_11;
    __PST__g__128 __pst_unused_field_12;
    __PST__g__129 __pst_unused_field_13;
    __PST__g__128 __pst_unused_field_14;
    __PST__g__129 __pst_unused_field_15;
    __PST__g__128 __pst_unused_field_16;
    __PST__g__129 __pst_unused_field_17;
    __PST__g__128 __pst_unused_field_18;
    __PST__g__129 __pst_unused_field_19;
    __PST__g__128 __pst_unused_field_20;
    __PST__g__129 __pst_unused_field_21;
    __PST__g__128 __pst_unused_field_22;
    __PST__g__129 __pst_unused_field_23;
    __PST__g__128 __pst_unused_field_24;
    __PST__g__129 __pst_unused_field_25;
    __PST__g__128 __pst_unused_field_26;
    __PST__g__129 __pst_unused_field_27;
    __PST__g__128 __pst_unused_field_28;
    __PST__g__129 __pst_unused_field_29;
    __PST__g__128 __pst_unused_field_30;
    __PST__g__129 __pst_unused_field_31;
    __PST__g__43 TE;
    __PST__g__129 __pst_unused_field_33;
    union __PST__g__48 TS;
    __PST__g__129 __pst_unused_field_35;
    __PST__g__128 __pst_unused_field_36;
    __PST__g__129 __pst_unused_field_37;
    __PST__g__128 __pst_unused_field_38;
    __PST__g__129 __pst_unused_field_39;
    __PST__g__128 __pst_unused_field_40;
    __PST__g__129 __pst_unused_field_41;
    __PST__g__128 __pst_unused_field_42;
    __PST__g__129 __pst_unused_field_43;
    __PST__g__128 __pst_unused_field_44;
    __PST__g__129 __pst_unused_field_45;
    __PST__g__128 __pst_unused_field_46;
    __PST__g__130 __pst_unused_field_47;
    __PST__g__131 __pst_unused_field_48;
    __PST__g__131 __pst_unused_field_49;
    __PST__g__131 __pst_unused_field_50;
    __PST__g__131 __pst_unused_field_51;
    __PST__g__131 __pst_unused_field_52;
    __PST__g__131 __pst_unused_field_53;
    union __PST__g__65 CMOR3;
    __PST__g__131 __pst_unused_field_55;
    union __PST__g__70 TPS;
    __PST__g__131 __pst_unused_field_57;
    __PST__UINT8 BRS;
    __PST__g__129 __pst_unused_field_59;
    __PST__g__128 __pst_unused_field_60;
    __PST__g__129 __pst_unused_field_61;
    __PST__g__128 __pst_unused_field_62;
    __PST__g__129 __pst_unused_field_63;
    __PST__g__128 __pst_unused_field_64;
    __PST__g__129 __pst_unused_field_65;
    __PST__g__128 __pst_unused_field_66;
    __PST__g__132 __pst_unused_field_67;
  };
typedef volatile struct __PST__g__27 __PST__g__26;
union __PST__g__29
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__30
  {
    __PST__UINT8 __pst_unused_field_0 : 2;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__33[3];
union __PST__g__35
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__35 __PST__g__34;
struct __PST__g__37
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__37 __PST__g__36;
union __PST__g__41
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__42
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__50
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__51
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__52
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__53
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__54
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__55
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__56
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__57
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__58
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__59
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__61
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__61 __PST__g__60;
struct __PST__g__63
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef const struct __PST__g__63 __PST__g__62;
typedef __PST__UINT8 __PST__g__64[19];
struct __PST__g__66
  {
    __PST__UINT16 __pst_unused_field_0 : 5;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 2;
    __PST__UINT16 __pst_unused_field_3 : 3;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 2;
    __PST__UINT16 __pst_unused_field_6 : 2;
  };
typedef __PST__UINT8 __PST__g__69[2];
union __PST__g__72
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__73
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__74
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__75
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__76
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__77
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__78
  {
    __PST__g__128 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__79
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef __PST__UINT8 __PST__g__80[3931];
typedef __PST__VOID __PST__g__81(__PST__SINT32);
typedef __PST__UINT32 __PST__g__82(__PST__SINT32);
typedef __PST__g__26 *__PST__g__83;
typedef volatile __PST__g__28 __PST__g__84;
typedef __PST__g__84 *__PST__g__85;
typedef __PST__g__18 *__PST__g__86;
typedef __PST__g__19 *__PST__g__87;
typedef __PST__g__82 *__PST__g__88;
typedef volatile union __PST__g__70 __PST__g__89;
typedef __PST__g__89 *__PST__g__90;
typedef volatile struct __PST__g__71 __PST__g__91;
typedef __PST__g__91 *__PST__g__92;
typedef volatile __PST__UINT8 __PST__g__95;
typedef __PST__g__95 *__PST__g__96;
typedef volatile __PST__UINT32 __PST__g__97;
typedef __PST__g__97 *__PST__g__98;
typedef volatile union __PST__g__65 __PST__g__99;
typedef __PST__g__99 *__PST__g__100;
typedef volatile __PST__UINT16 __PST__g__101;
typedef __PST__g__101 *__PST__g__102;
typedef volatile union __PST__g__48 __PST__g__103;
typedef __PST__g__103 *__PST__g__104;
typedef volatile struct __PST__g__49 __PST__g__105;
typedef __PST__g__105 *__PST__g__106;
typedef volatile __PST__g__43 __PST__g__109;
typedef __PST__g__109 *__PST__g__110;
typedef volatile __PST__g__45 __PST__g__111;
typedef __PST__g__111 *__PST__g__112;
typedef __PST__g__15 *__PST__g__115;
typedef __PST__g__17 *__PST__g__116;
typedef volatile __PST__SINT32 __PST__g__117;
typedef __PST__SINT8 __PST__g__123(void);
typedef volatile __PST__SINT8 __PST__g__124;
typedef __PST__UINT8 __PST__g__125(void);
typedef __PST__SINT32 __PST__g__126(void);
typedef __PST__UINT32 __PST__g__127(void);
