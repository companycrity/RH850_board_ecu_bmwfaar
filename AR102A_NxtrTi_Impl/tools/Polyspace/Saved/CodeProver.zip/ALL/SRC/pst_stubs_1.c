#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__70 _main_gen_init_g70(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__65 _main_gen_init_g65(void);

extern struct __PST__g__49 _main_gen_init_g49(void);

extern union __PST__g__48 _main_gen_init_g48(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__46 _main_gen_init_g46(void);

extern union __PST__g__44 _main_gen_init_g44(void);

extern __PST__g__26 _main_gen_init_g26(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__46 _main_gen_init_g46(void)
{
    static struct __PST__g__46 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TE03 = bitf;
    }
    return x;
}

union __PST__g__44 _main_gen_init_g44(void)
{
    static union __PST__g__44 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g46();
    return x;
}

struct __PST__g__49 _main_gen_init_g49(void)
{
    static struct __PST__g__49 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TS03 = bitf;
    }
    return x;
}

union __PST__g__48 _main_gen_init_g48(void)
{
    static union __PST__g__48 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g49();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__65 _main_gen_init_g65(void)
{
    static union __PST__g__65 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__71 _main_gen_init_g71(void)
{
    static struct __PST__g__71 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 15);
        x.PRS3 = bitf;
    }
    return x;
}

union __PST__g__70 _main_gen_init_g70(void)
{
    static union __PST__g__70 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g71();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* struct/union type */
    x.TE = _main_gen_init_g44();
    x.TS = _main_gen_init_g48();
    x.CMOR3 = _main_gen_init_g65();
    x.TPS = _main_gen_init_g70();
    x.CDR3 = _main_gen_init_g8();
    x.CNT3 = _main_gen_init_g8();
    x.BRS = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TAUJ1(void)
{
    extern __PST__g__26 TAUJ1;
    
    /* initialization with random value */
    {
        TAUJ1 = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_TAUJ2(void)
{
    extern __PST__g__26 TAUJ2;
    
    /* initialization with random value */
    {
        TAUJ2 = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_NxtrTi_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 NxtrTi_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        NxtrTi_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TAUJ1 */
    _main_gen_init_sym_TAUJ1();
    
    /* init for variable TAUJ2 */
    _main_gen_init_sym_TAUJ2();
    
    /* init for variable NxtrTi_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_Return */
    _main_gen_init_sym_NxtrTi_Srv_SetNtcSts_Return();
    
    /* init for variable NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan();
    
}
