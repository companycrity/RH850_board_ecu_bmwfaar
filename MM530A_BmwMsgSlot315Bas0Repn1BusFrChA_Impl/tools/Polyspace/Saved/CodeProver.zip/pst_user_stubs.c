/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS(__PST__UINT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS(__PST__UINT16 P_0)
// {
//    ...
// }

