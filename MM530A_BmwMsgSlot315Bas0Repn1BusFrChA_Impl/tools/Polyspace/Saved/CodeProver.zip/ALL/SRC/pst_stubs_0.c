#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BmwVehCdn_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_BrdgVltg_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_EcuTFild_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq4RawAdc_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_HwTq5RawAdc_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotCurrPeakEstimdFild_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotFetT_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotMagT_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPreLim_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotTqCmdPwrLimd_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotVelMrf_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_MotWidgT_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_SysSt_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val
 */


__PST__UINT8 Rte_Read_BmwMsgSlot315Bas0Repn1BusFrChA_VehSpd_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_BATT_VLTG_EPS_BATT_VLTG_EPS(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_DBG_EPS_BS_MOD_58_BYTE_ID2_DBG_EPS_BS_MOD_58_BYTE_ID2(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ECU_TEMP_EPS_ECU_TEMP_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ESTIMD_PEAK_MOT_CURR_EPS_ESTIMD_PEAK_MOT_CURR_EPS(__PST__UINT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_FET_TEMP_EPS_MOT_FET_TEMP_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_MAG_TEMP_EPS_MOT_MAG_TEMP_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_EPS_MOT_TQ_CMD_EPS(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_TQ_CMD_LIMD_EPS_MOT_TQ_CMD_LIMD_EPS(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_VEL_EPS_MOT_VEL_EPS(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_MOT_WIDG_TEMP_EPS_MOT_WIDG_TEMP_EPS(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_PRIM_HW_TQ_SNSR_VLTG_EPS_PRIM_HW_TQ_SNSR_VLTG_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SECDRY_HW_TQ_SNSR_VLTG_EPS_SECDRY_HW_TQ_SNSR_VLTG_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_ST_CON_VEH_EPS_ST_CON_VEH_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_SYS_ST_EPS_SYS_ST_EPS(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS"


__PST__UINT8 Rte_Write_BmwMsgSlot315Bas0Repn1BusFrChA_VEH_SPD_EPS_VEH_SPD_EPS(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

