#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotAgCmp_Ip_AssiMechPolarity(void)
{
    extern __PST__SINT8 MotAgCmp_Ip_AssiMechPolarity;
    
    /* initialization with random value */
    {
        MotAgCmp_Ip_AssiMechPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotAgCmp_Ip_MotAgCumvAlgndMrfRev(void)
{
    extern __PST__SINT32 MotAgCmp_Ip_MotAgCumvAlgndMrfRev;
    
    /* initialization with random value */
    {
        MotAgCmp_Ip_MotAgCumvAlgndMrfRev = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotAgCmp_Ip_MotAgCumvInid(void)
{
    extern __PST__UINT8 MotAgCmp_Ip_MotAgCumvInid;
    
    /* initialization with random value */
    {
        MotAgCmp_Ip_MotAgCumvInid = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgCmp_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__28 MotAgCmp_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        MotAgCmp_Cal_SysGlbPrmSysKineRat = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_MotAgCmp_Pim_MotAgCmpMotAgBackEmf(void)
{
    extern __PST__UINT16 MotAgCmp_Pim_MotAgCmpMotAgBackEmf;
    
    /* initialization with random value */
    {
        MotAgCmp_Pim_MotAgCmpMotAgBackEmf = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgCmp_Cal_SysGlbPrmMotPoleCnt(void)
{
    extern __PST__g__30 MotAgCmp_Cal_SysGlbPrmMotPoleCnt;
    
    /* initialization with random value */
    {
        MotAgCmp_Cal_SysGlbPrmMotPoleCnt = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_MotAgCmp_Pim_CmpEnaCntr(void)
{
    extern __PST__UINT8 MotAgCmp_Pim_CmpEnaCntr;
    
    /* initialization with random value */
    {
        MotAgCmp_Pim_CmpEnaCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgCmp_Pim_MotAgCmpMotCtrlMotAgCumvAlgndMrfRevPrev(void)
{
    extern __PST__SINT32 MotAgCmp_Pim_MotAgCmpMotCtrlMotAgCumvAlgndMrfRevPrev;
    
    /* initialization with random value */
    {
        MotAgCmp_Pim_MotAgCmpMotCtrlMotAgCumvAlgndMrfRevPrev = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotAgCmp_Pim_MotAgCmpMotCtrlMotAgMeclPrev(void)
{
    extern __PST__SINT32 MotAgCmp_Pim_MotAgCmpMotCtrlMotAgMeclPrev;
    
    /* initialization with random value */
    {
        MotAgCmp_Pim_MotAgCmpMotCtrlMotAgMeclPrev = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgMecl;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev(void)
{
    extern __PST__SINT32 MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotAgCmp_Srv_MotAgCmpMotAgBackEmf_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 MotAgCmp_Srv_MotAgCmpMotAgBackEmf_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        MotAgCmp_Srv_MotAgCmpMotAgBackEmf_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgCmp_Cli_MotAgCmpBackEmfRead_MotAgBackEmfRead(void)
{
    extern __PST__UINT16 MotAgCmp_Cli_MotAgCmpBackEmfRead_MotAgBackEmfRead;
    
    /* initialization with random value */
    {
        MotAgCmp_Cli_MotAgCmpBackEmfRead_MotAgBackEmfRead = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgCmp_Cli_MotAgCmpBackEmfWr_MotAgCmpBackEmfWrData(void)
{
    extern __PST__UINT16 MotAgCmp_Cli_MotAgCmpBackEmfWr_MotAgCmpBackEmfWrData;
    
    /* initialization with random value */
    {
        MotAgCmp_Cli_MotAgCmpBackEmfWr_MotAgCmpBackEmfWrData = _main_gen_init_g7();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotAgCmp_Ip_AssiMechPolarity */
    _main_gen_init_sym_MotAgCmp_Ip_AssiMechPolarity();
    
    /* init for variable MotAgCmp_Ip_MotAgCumvAlgndMrfRev */
    _main_gen_init_sym_MotAgCmp_Ip_MotAgCumvAlgndMrfRev();
    
    /* init for variable MotAgCmp_Ip_MotAgCumvInid */
    _main_gen_init_sym_MotAgCmp_Ip_MotAgCumvInid();
    
    /* init for variable MotAgCmp_Op_MotAgCumvAlgndCrf : useless (never read) */

    /* init for variable MotAgCmp_Op_MotAgCumvAlgndMrf : useless (never read) */

    /* init for variable MotAgCmp_Op_MotAgCumvAlgndVld : useless (never read) */

    /* init for variable MotAgCmp_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_MotAgCmp_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable MotAgCmp_Pim_MotAgCmpMotAgBackEmf */
    _main_gen_init_sym_MotAgCmp_Pim_MotAgCmpMotAgBackEmf();
    
    /* init for variable MotAgCmp_Pim_DigMotHwPosn : useless (never read) */

    /* init for variable MotAgCmp_Cal_SysGlbPrmMotPoleCnt */
    _main_gen_init_sym_MotAgCmp_Cal_SysGlbPrmMotPoleCnt();
    
    /* init for variable MotAgCmp_Pim_CmpEnaCntr */
    _main_gen_init_sym_MotAgCmp_Pim_CmpEnaCntr();
    
    /* init for variable MotAgCmp_Pim_MotAgCmpMotCtrlMotAgCumvAlgndMrfRevPrev */
    _main_gen_init_sym_MotAgCmp_Pim_MotAgCmpMotCtrlMotAgCumvAlgndMrfRevPrev();
    
    /* init for variable MotAgCmp_Pim_MotAgCmpMotCtrlMotAgMeclPrev */
    _main_gen_init_sym_MotAgCmp_Pim_MotAgCmpMotCtrlMotAgMeclPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMecl */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElec : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgCumvInid : useless (never read) */

    /* init for variable MotAgCmp_Srv_MotAgCmpMotAgBackEmf_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable MotAgCmp_Srv_MotAgCmpMotAgBackEmf_SetRamBlockStatus_Return */
    _main_gen_init_sym_MotAgCmp_Srv_MotAgCmpMotAgBackEmf_SetRamBlockStatus_Return();
    
    /* init for variable MotAgCmp_Cli_MotAgCmpBackEmfRead_MotAgBackEmfRead */
    _main_gen_init_sym_MotAgCmp_Cli_MotAgCmpBackEmfRead_MotAgBackEmfRead();
    
    /* init for variable MotAgCmp_Cli_MotAgCmpBackEmfWr_MotAgCmpBackEmfWrData */
    _main_gen_init_sym_MotAgCmp_Cli_MotAgCmpBackEmfWr_MotAgCmpBackEmfWrData();
    
}
