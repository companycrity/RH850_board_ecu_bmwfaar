#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__38 _main_gen_init_g38(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__33 _main_gen_init_g33(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__33 _main_gen_init_g33(void)
{
    __PST__g__33 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__36 _main_gen_init_g36(void)
{
    static struct __PST__g__36 x;
    /* struct/union type */
    x.BmwRackCentrToVehCentrOffs = _main_gen_init_g10();
    x.VehCentrOffs = _main_gen_init_g10();
    x.BmwPinionAgOffs = _main_gen_init_g10();
    x.BmwQuadRotorOffs = _main_gen_init_g2();
    x.TurnCntrCorrlnSts = _main_gen_init_g6();
    x.Ntc8CSts = _main_gen_init_g6();
    x.Ntc8ESts = _main_gen_init_g6();
    x.BmwMotAgSelnSt = _main_gen_init_g6();
    x.LongTermVehCentrCmpl = _main_gen_init_g6();
    x.RackCentrToVehCentrOffsVld = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__38 _main_gen_init_g38(void)
{
    static struct __PST__g__38 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwHwAgOffs(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_BmwHwAgOffs;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwHwAgOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffs(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffs;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffsSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffsSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffsSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsStsVld(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsStsVld;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsStsVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffs(void)
{
    extern __PST__SINT8 BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffs;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffs = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffsVld(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffsVld;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffsVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwVehSpdSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_BmwVehSpdSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_BmwVehSpdSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_CmplncErrMotToPinion(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_CmplncErrMotToPinion;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_CmplncErrMotToPinion = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_DiKineIntegrityTest(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_DiKineIntegrityTest;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_DiKineIntegrityTest = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_LongTermRackCentrCmpl(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_LongTermRackCentrCmpl;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_LongTermRackCentrCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_MotAgCumvAlgndMrf(void)
{
    extern __PST__SINT32 BmwHwAgArbnAndEotPosn_Ip_MotAgCumvAlgndMrf;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_MotAgCumvAlgndMrf = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_MotAgMeclCorrlnSt(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_MotAgMeclCorrlnSt;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_MotAgMeclCorrlnSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_MotAgTurnCntr(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_MotAgTurnCntr;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_MotAgTurnCntr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_RackCentrPinionAg(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_RackCentrPinionAg;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_RackCentrPinionAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_TotRackTrvl(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_TotRackTrvl;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_TotRackTrvl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_TurnCntrCorrlnSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_TurnCntrCorrlnSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_TurnCntrCorrlnSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_VehSpdVld(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Ip_VehSpdVld;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Ip_VehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnAllwExitFromInit(void)
{
    extern __PST__g__32 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnAllwExitFromInit;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnAllwExitFromInit = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsLim(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsLim;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsLim = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsRateLim(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsRateLim;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsRateLim = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMax(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMax;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMax = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMin(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMin;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMin = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMax(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMax;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMax = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMin(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMin;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMin = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnKineIntegrityDiagcMaxRackLim(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnKineIntegrityDiagcMaxRackLim;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnKineIntegrityDiagcMaxRackLim = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMinVehSpdReqdVldAbsPos(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMinVehSpdReqdVldAbsPos;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMinVehSpdReqdVldAbsPos = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotPosnDegArbdBlnd(void)
{
    extern __PST__g__34 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotPosnDegArbdBlnd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotPosnDegArbdBlnd = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotToHwResl(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotToHwResl;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotToHwResl = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsAuthy(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsAuthy;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsAuthy = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnAuthy(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnAuthy;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnAuthy = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnTmrThd(void)
{
    extern __PST__g__32 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnTmrThd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnTmrThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampDwnRate(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampDwnRate;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampDwnRate = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampUpRate(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampUpRate;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampUpRate = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgDifThd(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgDifThd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgDifThd = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFilFrq(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFilFrq;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFilFrq = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFltTmrThd(void)
{
    extern __PST__g__32 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFltTmrThd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFltTmrThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnSysPolarityAssi(void)
{
    extern __PST__g__35 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnSysPolarityAssi;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnSysPolarityAssi = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTmpCmpdAuthy(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTmpCmpdAuthy;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTmpCmpdAuthy = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrAuthy(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrAuthy;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrAuthy = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrCorrlnStsTmrThd(void)
{
    extern __PST__g__34 BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrCorrlnStsTmrThd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrCorrlnStsTmrThd = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__33 BmwHwAgArbnAndEotPosn_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cal_SysGlbPrmSysKineRat = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_BmwVehCentrOffs(void)
{
    extern struct __PST__g__36 BmwHwAgArbnAndEotPosn_Pim_BmwVehCentrOffs;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_BmwVehCentrOffs = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_AllwExitFromInitTi(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Pim_AllwExitFromInitTi;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_AllwExitFromInitTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_BmwPinionAgOffsRateLim(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Pim_BmwPinionAgOffsRateLim;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_BmwPinionAgOffsRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_BmwRackCentrToVehCentrOffsSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_BmwRackCentrToVehCentrOffsSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_BmwRackCentrToVehCentrOffsSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_ClrNotCmplPinionAgFlg(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_ClrNotCmplPinionAgFlg;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_ClrNotCmplPinionAgFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_CurrAlgndPinionAg(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Pim_CurrAlgndPinionAg;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_CurrAlgndPinionAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_CurrDftPinionAgFltPrsnt(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_CurrDftPinionAgFltPrsnt;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_CurrDftPinionAgFltPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_DynStabyCtrlCdn(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_DynStabyCtrlCdn;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_DynStabyCtrlCdn = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_FirstLoopIndcr(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_FirstLoopIndcr;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_FirstLoopIndcr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_IniTurnCntrCorrlnSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_IniTurnCntrCorrlnSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_IniTurnCntrCorrlnSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_KineIntegrityFlt(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_KineIntegrityFlt;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_KineIntegrityFlt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_LpFilActvd(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_LpFilActvd;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_LpFilActvd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndFac(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndFac;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndFac = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndTi(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndTi;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_OffsCorrnRefTi(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Pim_OffsCorrnRefTi;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_OffsCorrnRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PinionAgConfRampStVari(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Pim_PinionAgConfRampStVari;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PinionAgConfRampStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PinionAgFilStVari(void)
{
    extern struct __PST__g__38 BmwHwAgArbnAndEotPosn_Pim_PinionAgFilStVari;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PinionAgFilStVari = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PinionAgFltRefTi(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Pim_PinionAgFltRefTi;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PinionAgFltRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevAllwCorrn(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevAllwCorrn;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevAllwCorrn = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevBmwMotAgSelnSt(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevBmwMotAgSelnSt;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevBmwMotAgSelnSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthy(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthy;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthy = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthyFlg(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthyFlg;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthyFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycBmwMotAgSelnSt(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycBmwMotAgSelnSt;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycBmwMotAgSelnSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8CSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8CSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8CSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8ESts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8ESts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8ESts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycTurnCntrCorrlnSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycTurnCntrCorrlnSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycTurnCntrCorrlnSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwMotAgSelnSt(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwMotAgSelnSt;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwMotAgSelnSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwQuadOffsSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwQuadOffsSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwQuadOffsSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevLoopPinionAg(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Pim_PrevLoopPinionAg;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevLoopPinionAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevPinionAgConf(void)
{
    extern __PST__FLOAT32 BmwHwAgArbnAndEotPosn_Pim_PrevPinionAgConf;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_PrevPinionAgConf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_SetBmwRackCentrToVehCentrOffsTrig(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_SetBmwRackCentrToVehCentrOffsTrig;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_SetBmwRackCentrToVehCentrOffsTrig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_TurnCntrCorrlnStsTmrTrig(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_TurnCntrCorrlnStsTmrTrig;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_TurnCntrCorrlnStsTmrTrig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_TurnCntrValTi(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Pim_TurnCntrValTi;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_TurnCntrValTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_VehCentrCmpl(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Pim_VehCentrCmpl;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Pim_VehCentrCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_ReqResPtr(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_ReqResPtr;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_ReqResPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwHwAgArbnAndEotPosn_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cli_SetVehCentrPosn_BmwSetVehCentrOffsSts(void)
{
    extern __PST__UINT8 BmwHwAgArbnAndEotPosn_Cli_SetVehCentrPosn_BmwSetVehCentrOffsSts;
    
    /* initialization with random value */
    {
        BmwHwAgArbnAndEotPosn_Cli_SetVehCentrPosn_BmwSetVehCentrOffsSts = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwHwAgOffs */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwHwAgOffs();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffs */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffs();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffsSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwPinionAgOffsSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsStsVld */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadOffsStsVld();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffs */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffs();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffsVld */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwQuadRotorOffsVld();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_BmwVehSpdSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_BmwVehSpdSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_CmplncErrMotToPinion */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_CmplncErrMotToPinion();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_DiKineIntegrityTest */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_DiKineIntegrityTest();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_LongTermRackCentrCmpl */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_LongTermRackCentrCmpl();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_MotAgCumvAlgndMrf */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_MotAgCumvAlgndMrf();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_MotAgMeclCorrlnSt */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_MotAgMeclCorrlnSt();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_MotAgTurnCntr */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_MotAgTurnCntr();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_RackCentrPinionAg */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_RackCentrPinionAg();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_TotRackTrvl */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_TotRackTrvl();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_TurnCntrCorrlnSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_TurnCntrCorrlnSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_VehSpd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_VehSpd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Ip_VehSpdVld */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Ip_VehSpdVld();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Op_AlgndPinionAg : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_BmwPinionAg : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_BmwPinionAgQlfr : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_BmwRackCentrToVehCentrOffs : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_BmwRackCentrToVehCentrOffsVld : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_HwAgCcwDetd : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_HwAgCwDetd : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_HwAgEotCcw : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_HwAgEotCw : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_LongTermVehCentrCmpl : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_OffsCmpdPinionAg : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_PinionAg : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Op_PinionAgConf : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnAllwExitFromInit */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnAllwExitFromInit();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsLim */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsLim();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsRateLim */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnBmwPinionAgOffsRateLim();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMax */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMax();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMin */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCcwMin();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMax */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMax();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMin */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnEotCwMin();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnKineIntegrityDiagcMaxRackLim */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnKineIntegrityDiagcMaxRackLim();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMinVehSpdReqdVldAbsPos */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMinVehSpdReqdVldAbsPos();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotPosnDegArbdBlnd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotPosnDegArbdBlnd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotToHwResl */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnMotToHwResl();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsAuthy */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsAuthy();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnAuthy */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnAuthy();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnTmrThd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnOffsCorrnTmrThd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampDwnRate */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampDwnRate();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampUpRate */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgConfRampUpRate();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgDifThd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgDifThd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFilFrq */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFilFrq();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFltTmrThd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnPinionAgFltTmrThd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnSysPolarityAssi */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnSysPolarityAssi();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTmpCmpdAuthy */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTmpCmpdAuthy();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrAuthy */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrAuthy();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrCorrlnStsTmrThd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_BmwHwAgArbnAndEotPosnTurnCntrCorrlnStsTmrThd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_BmwVehCentrOffs */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_BmwVehCentrOffs();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_dBmwHwAgArbnAndEotPosnBmwMotAgSelnSt : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Pim_AllwExitFromInitTi */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_AllwExitFromInitTi();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_BmwPinionAgOffsRateLim */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_BmwPinionAgOffsRateLim();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_BmwRackCentrToVehCentrOffsSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_BmwRackCentrToVehCentrOffsSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_ClrNotCmplPinionAgFlg */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_ClrNotCmplPinionAgFlg();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_CurrAlgndPinionAg */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_CurrAlgndPinionAg();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_CurrDftPinionAgFltPrsnt */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_CurrDftPinionAgFltPrsnt();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_DynStabyCtrlCdn */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_DynStabyCtrlCdn();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_FirstLoopIndcr */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_FirstLoopIndcr();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_IniTurnCntrCorrlnSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_IniTurnCntrCorrlnSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_KineIntegrityFlt */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_KineIntegrityFlt();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_LpFilActvd */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_LpFilActvd();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndFac */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndFac();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndTi */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_MotPosnDegArbdBlndTi();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_OffsCorrnRefTi */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_OffsCorrnRefTi();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PinionAgConfRampStVari */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PinionAgConfRampStVari();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PinionAgFilStVari */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PinionAgFilStVari();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PinionAgFltRefTi */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PinionAgFltRefTi();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevAllwCorrn */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevAllwCorrn();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevBmwMotAgSelnSt */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevBmwMotAgSelnSt();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthy */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthy();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthyFlg */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevBmwOffsAuthyFlg();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycBmwMotAgSelnSt */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycBmwMotAgSelnSt();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8CSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8CSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8ESts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycNtc8ESts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycTurnCntrCorrlnSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevIgnCycTurnCntrCorrlnSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwMotAgSelnSt */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwMotAgSelnSt();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwQuadOffsSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevLoopBmwQuadOffsSts();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevLoopPinionAg */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevLoopPinionAg();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_PrevPinionAgConf */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_PrevPinionAgConf();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_SetBmwRackCentrToVehCentrOffsTrig */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_SetBmwRackCentrToVehCentrOffsTrig();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_TurnCntrCorrlnStsTmrTrig */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_TurnCntrCorrlnStsTmrTrig();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_TurnCntrValTi */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_TurnCntrValTi();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Pim_VehCentrCmpl */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Pim_VehCentrCmpl();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_ReqResPtr */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_ReqResPtr();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_Return */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_GetErrorStatus_Return();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_SetRamBlockStatus_Return */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_BmwVehCentrOffs_SetRamBlockStatus_Return();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_Return */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Srv_SetNtcSts_Return();
    
    /* init for variable BmwHwAgArbnAndEotPosn_Cli_SetVehCentrPosn_BmwSetVehCentrOffsSts */
    _main_gen_init_sym_BmwHwAgArbnAndEotPosn_Cli_SetVehCentrPosn_BmwSetVehCentrOffsSts();
    
}
