#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpd(void)
{
    extern __PST__FLOAT32 BmwVehSpd_Ip_BmwCogVehSpd;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwCogVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpdQlfr(void)
{
    extern __PST__UINT8 BmwVehSpd_Ip_BmwCogVehSpdQlfr;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwCogVehSpdQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpdQlfrVld(void)
{
    extern __PST__UINT8 BmwVehSpd_Ip_BmwCogVehSpdQlfrVld;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwCogVehSpdQlfrVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpdVld(void)
{
    extern __PST__UINT8 BmwVehSpd_Ip_BmwCogVehSpdVld;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwCogVehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwNearStillVehSpdSts(void)
{
    extern __PST__UINT8 BmwVehSpd_Ip_BmwNearStillVehSpdSts;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwNearStillVehSpdSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwNearStillVehSpdStsVld(void)
{
    extern __PST__UINT8 BmwVehSpd_Ip_BmwNearStillVehSpdStsVld;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwNearStillVehSpdStsVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Ip_BmwPinionAgQlfr(void)
{
    extern __PST__UINT8 BmwVehSpd_Ip_BmwPinionAgQlfr;
    
    /* initialization with random value */
    {
        BmwVehSpd_Ip_BmwPinionAgQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdBmwSecurVehSpdStsSigValVldDurnTiVal(void)
{
    extern __PST__g__25 BmwVehSpd_Cal_BmwVehSpdBmwSecurVehSpdStsSigValVldDurnTiVal;
    
    /* initialization with random value */
    {
        BmwVehSpd_Cal_BmwVehSpdBmwSecurVehSpdStsSigValVldDurnTiVal = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdNearStillSubVehSpd(void)
{
    extern __PST__g__26 BmwVehSpd_Cal_BmwVehSpdNearStillSubVehSpd;
    
    /* initialization with random value */
    {
        BmwVehSpd_Cal_BmwVehSpdNearStillSubVehSpd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdRunngSubVehSpd(void)
{
    extern __PST__g__26 BmwVehSpd_Cal_BmwVehSpdRunngSubVehSpd;
    
    /* initialization with random value */
    {
        BmwVehSpd_Cal_BmwVehSpdRunngSubVehSpd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdSecurVehSpdInvldRateLim(void)
{
    extern __PST__g__26 BmwVehSpd_Cal_BmwVehSpdSecurVehSpdInvldRateLim;
    
    /* initialization with random value */
    {
        BmwVehSpd_Cal_BmwVehSpdSecurVehSpdInvldRateLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdSecurVehSpdVldRateLim(void)
{
    extern __PST__g__26 BmwVehSpd_Cal_BmwVehSpdSecurVehSpdVldRateLim;
    
    /* initialization with random value */
    {
        BmwVehSpd_Cal_BmwVehSpdSecurVehSpdVldRateLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Pim_BmwSecurVehSpdStsSigValVldDurn(void)
{
    extern __PST__UINT32 BmwVehSpd_Pim_BmwSecurVehSpdStsSigValVldDurn;
    
    /* initialization with random value */
    {
        BmwVehSpd_Pim_BmwSecurVehSpdStsSigValVldDurn = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Pim_SpdDifChkFlg(void)
{
    extern __PST__UINT8 BmwVehSpd_Pim_SpdDifChkFlg;
    
    /* initialization with random value */
    {
        BmwVehSpd_Pim_SpdDifChkFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Pim_VehSpdLimPrev(void)
{
    extern __PST__FLOAT32 BmwVehSpd_Pim_VehSpdLimPrev;
    
    /* initialization with random value */
    {
        BmwVehSpd_Pim_VehSpdLimPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwVehSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwVehSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwVehSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwVehSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwVehSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwVehSpd_Ip_BmwCogVehSpd */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpd();
    
    /* init for variable BmwVehSpd_Ip_BmwCogVehSpdQlfr */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpdQlfr();
    
    /* init for variable BmwVehSpd_Ip_BmwCogVehSpdQlfrVld */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpdQlfrVld();
    
    /* init for variable BmwVehSpd_Ip_BmwCogVehSpdVld */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwCogVehSpdVld();
    
    /* init for variable BmwVehSpd_Ip_BmwNearStillVehSpdSts */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwNearStillVehSpdSts();
    
    /* init for variable BmwVehSpd_Ip_BmwNearStillVehSpdStsVld */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwNearStillVehSpdStsVld();
    
    /* init for variable BmwVehSpd_Ip_BmwPinionAgQlfr */
    _main_gen_init_sym_BmwVehSpd_Ip_BmwPinionAgQlfr();
    
    /* init for variable BmwVehSpd_Op_BmwSecurVehSpdSts : useless (never read) */

    /* init for variable BmwVehSpd_Op_VehSpd : useless (never read) */

    /* init for variable BmwVehSpd_Op_VehSpdVld : useless (never read) */

    /* init for variable BmwVehSpd_Cal_BmwVehSpdBmwSecurVehSpdStsSigValVldDurnTiVal */
    _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdBmwSecurVehSpdStsSigValVldDurnTiVal();
    
    /* init for variable BmwVehSpd_Cal_BmwVehSpdNearStillSubVehSpd */
    _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdNearStillSubVehSpd();
    
    /* init for variable BmwVehSpd_Cal_BmwVehSpdRunngSubVehSpd */
    _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdRunngSubVehSpd();
    
    /* init for variable BmwVehSpd_Cal_BmwVehSpdSecurVehSpdInvldRateLim */
    _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdSecurVehSpdInvldRateLim();
    
    /* init for variable BmwVehSpd_Cal_BmwVehSpdSecurVehSpdVldRateLim */
    _main_gen_init_sym_BmwVehSpd_Cal_BmwVehSpdSecurVehSpdVldRateLim();
    
    /* init for variable BmwVehSpd_Pim_BmwSecurVehSpdStsSigValVldDurn */
    _main_gen_init_sym_BmwVehSpd_Pim_BmwSecurVehSpdStsSigValVldDurn();
    
    /* init for variable BmwVehSpd_Pim_SpdDifChkFlg */
    _main_gen_init_sym_BmwVehSpd_Pim_SpdDifChkFlg();
    
    /* init for variable BmwVehSpd_Pim_VehSpdLimPrev */
    _main_gen_init_sym_BmwVehSpd_Pim_VehSpdLimPrev();
    
    /* init for variable BmwVehSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwVehSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwVehSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwVehSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwVehSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
