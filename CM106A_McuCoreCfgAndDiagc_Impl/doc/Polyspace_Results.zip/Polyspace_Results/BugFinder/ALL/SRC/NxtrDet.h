/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name: NxtrDet.h
* Module Description: Nexteer Det Configuration
* Project           : CBD
* Author            : Lucas Wendling
***********************************************************************************************************************
* Version Control:
* %version:          1 %
* %derived_by:       czgng4 %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  -------------------------------------------------------------------------     ----------
* 10/15/15  1        LWW       Initial version                                                                 EA4#1916
**********************************************************************************************************************/
/******************************************* Multiple Include Protection *********************************************/
#ifndef NXTRDET_H
#define NXTRDET_H

/************************************************ Include Statements *************************************************/
#include "Std_Types.h"
#include "Det.h"

/******************************************** File Level Rule Deviations *********************************************/

#define NXTRDET_NXTRMCUSUPRTLIBMODID_CNT_U16                            (65535U)
#define NXTRDET_SYNCCRCMODID_CNT_U16                                            (65534U)

#ifdef DET_ENABLED
        #define NXTRDET_NXTRMCUSUPRTLIB                                                 STD_ON
        #define NXTRDET_SYNCCRC                                                                 STD_ON
#else
        #define NXTRDET_NXTRMCUSUPRTLIB                                                 STD_OFF
        #define NXTRDET_SYNCCRC                                                                 STD_OFF
#endif
/*********************************************** Exported Declarations ***********************************************/

#endif

