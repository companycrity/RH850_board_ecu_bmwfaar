#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__314 _main_gen_init_g314(void);

extern __PST__g__312 _main_gen_init_g312(void);

extern union __PST__g__310 _main_gen_init_g310(void);

extern __PST__g__308 _main_gen_init_g308(void);

extern struct __PST__g__139 _main_gen_init_g139(void);

extern union __PST__g__137 _main_gen_init_g137(void);

extern struct __PST__g__132 _main_gen_init_g132(void);

extern union __PST__g__130 _main_gen_init_g130(void);

extern union __PST__g__126 _main_gen_init_g126(void);

extern union __PST__g__124 _main_gen_init_g124(void);

extern union __PST__g__122 _main_gen_init_g122(void);

extern union __PST__g__120 _main_gen_init_g120(void);

extern union __PST__g__118 _main_gen_init_g118(void);

extern union __PST__g__114 _main_gen_init_g114(void);

extern __PST__g__103 _main_gen_init_g103(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__79 _main_gen_init_g79(void);

extern union __PST__g__76 _main_gen_init_g76(void);

extern union __PST__g__72 _main_gen_init_g72(void);

extern union __PST__g__68 _main_gen_init_g68(void);

extern union __PST__g__64 _main_gen_init_g64(void);

extern union __PST__g__60 _main_gen_init_g60(void);

extern union __PST__g__55 _main_gen_init_g55(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern struct __PST__g__46 _main_gen_init_g46(void);

extern union __PST__g__44 _main_gen_init_g44(void);

extern struct __PST__g__40 _main_gen_init_g40(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct Rte_CDS_CDD_McuCoreCfgAndDiagc _main_gen_init_g26(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_McuCoreCfgAndDiagc _main_gen_init_g26(void)
{
    static struct Rte_CDS_CDD_McuCoreCfgAndDiagc x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g8();
        }
        x.Pim_CoreCompTestRegRead = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}

struct __PST__g__40 _main_gen_init_g40(void)
{
    static struct __PST__g__40 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.SSE001 = bitf;
    }
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g40();
    return x;
}

struct __PST__g__46 _main_gen_init_g46(void)
{
    static struct __PST__g__46 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.SSE108 = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.SSE109 = bitf;
    }
    return x;
}

union __PST__g__44 _main_gen_init_g44(void)
{
    static union __PST__g__44 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g46();
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g38();
    x.ESSTR1 = _main_gen_init_g44();
    return x;
}

union __PST__g__55 _main_gen_init_g55(void)
{
    static union __PST__g__55 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__60 _main_gen_init_g60(void)
{
    static union __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__64 _main_gen_init_g64(void)
{
    static union __PST__g__64 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__68 _main_gen_init_g68(void)
{
    static union __PST__g__68 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__72 _main_gen_init_g72(void)
{
    static union __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__76 _main_gen_init_g76(void)
{
    static union __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__79 _main_gen_init_g79(void)
{
    static union __PST__g__79 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.MICFG0 = _main_gen_init_g55();
    x.NMICFG0 = _main_gen_init_g60();
    x.IRCFG0 = _main_gen_init_g64();
    x.EMK0 = _main_gen_init_g68();
    x.ESSTC0 = _main_gen_init_g72();
    x.PCMD1 = _main_gen_init_g76();
    x.PS = _main_gen_init_g79();
    return x;
}

union __PST__g__114 _main_gen_init_g114(void)
{
    static union __PST__g__114 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__118 _main_gen_init_g118(void)
{
    static union __PST__g__118 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__120 _main_gen_init_g120(void)
{
    static union __PST__g__120 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__122 _main_gen_init_g122(void)
{
    static union __PST__g__122 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__124 _main_gen_init_g124(void)
{
    static union __PST__g__124 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__126 _main_gen_init_g126(void)
{
    static union __PST__g__126 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__132 _main_gen_init_g132(void)
{
    static struct __PST__g__132 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 7);
        x.BIST_RESULT = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODE = bitf;
    }
    return x;
}

union __PST__g__130 _main_gen_init_g130(void)
{
    static union __PST__g__130 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g132();
    return x;
}

struct __PST__g__139 _main_gen_init_g139(void)
{
    static struct __PST__g__139 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 7);
        x.BIST_RESULTB = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODEB = bitf;
    }
    return x;
}

union __PST__g__137 _main_gen_init_g137(void)
{
    static union __PST__g__137 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g139();
    return x;
}

__PST__g__103 _main_gen_init_g103(void)
{
    __PST__g__103 x;
    /* struct/union type */
    x.LBISTREF1 = _main_gen_init_g114();
    x.LBISTREF2 = _main_gen_init_g118();
    x.MBISTREF = _main_gen_init_g120();
    x.LBISTSIG1 = _main_gen_init_g122();
    x.LBISTSIG2 = _main_gen_init_g124();
    x.MBISTSIG = _main_gen_init_g126();
    x.BSEQ0ST = _main_gen_init_g130();
    x.BSEQ0STB = _main_gen_init_g137();
    return x;
}

union __PST__g__310 _main_gen_init_g310(void)
{
    static union __PST__g__310 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__308 _main_gen_init_g308(void)
{
    __PST__g__308 x;
    /* struct/union type */
    x.PDMA_COMP_CNTRL = _main_gen_init_g310();
    return x;
}

union __PST__g__314 _main_gen_init_g314(void)
{
    static union __PST__g__314 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__312 _main_gen_init_g312(void)
{
    __PST__g__312 x;
    /* struct/union type */
    x.REG0 = _main_gen_init_g314();
    x.REG1 = _main_gen_init_g314();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_McuCoreCfgAndDiagc(void)
{
    extern __PST__g__23 Rte_Inst_CDD_McuCoreCfgAndDiagc;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_McuCoreCfgAndDiagc _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_McuCoreCfgAndDiagc)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_McuCoreCfgAndDiagc); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g26();
            }
            Rte_Inst_CDD_McuCoreCfgAndDiagc = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_McuCoreCfgAndDiagc) / 2];
        }
    }
}

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__28 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECMC(void)
{
    extern __PST__g__28 ECMC;
    
    /* initialization with random value */
    {
        ECMC = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__51 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__103 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g103();
    }
}

static void _main_gen_init_sym_PDMACOMP(void)
{
    extern __PST__g__308 PDMACOMP;
    
    /* initialization with random value */
    {
        PDMACOMP = _main_gen_init_g308();
    }
}

static void _main_gen_init_sym_TESTCOMP(void)
{
    extern __PST__g__312 TESTCOMP;
    
    /* initialization with random value */
    {
        TESTCOMP = _main_gen_init_g312();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_McuCoreCfgAndDiagc */
    _main_gen_init_sym_Rte_Inst_CDD_McuCoreCfgAndDiagc();
    
    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECMC */
    _main_gen_init_sym_ECMC();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable PDMACOMP */
    _main_gen_init_sym_PDMACOMP();
    
    /* init for variable TESTCOMP */
    _main_gen_init_sym_TESTCOMP();
    
}
