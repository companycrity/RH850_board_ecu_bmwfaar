#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__30 _main_gen_init_g30(void)
{
    static struct __PST__g__30 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynDampgFacReq(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynDampgFacReq;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynDampgFacReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynEffortFacReq(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynEffortFacReq;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynEffortFacReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynErrIfActv(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynErrIfActv;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynErrIfActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynRtnFacReq(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynRtnFacReq;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynRtnFacReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwOutpTqOvrlCmdEna(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwOutpTqOvrlCmdEna;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwOutpTqOvrlCmdEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwTarSteerTqDrvrActr(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwTarSteerTqDrvrActr;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwTarSteerTqDrvrActr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynActv(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynActv;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynFacEna(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynFacEna;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynFacEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynIfSt(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynIfSt;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynIfSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_HwTq(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_HwTq;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_OutpTqOvrlRampInEna(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Ip_OutpTqOvrlRampInEna;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_OutpTqOvrlRampInEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvDampgSlewRate(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvDampgSlewRate;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvDampgSlewRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvEffortSlewRate(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvEffortSlewRate;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvEffortSlewRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvRtnSlewRate(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvRtnSlewRate;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvRtnSlewRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimX(void)
{
    extern __PST__g__26 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 12; _main_gen_tmp_1_0++)
            {
                /* base type */
                BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimX[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimY(void)
{
    extern __PST__g__28 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 12; _main_gen_tmp_2_0++)
            {
                __PST__UINT32 _main_gen_tmp_2_1;
                
                for (_main_gen_tmp_2_1 = 0; _main_gen_tmp_2_1 < 12; _main_gen_tmp_2_1++)
                {
                    /* base type */
                    BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimY[_main_gen_tmp_2_0][_main_gen_tmp_2_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimX(void)
{
    extern __PST__g__26 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 12; _main_gen_tmp_3_0++)
            {
                /* base type */
                BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimX[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimY(void)
{
    extern __PST__g__28 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 12; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 12; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimY[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvDampgSlewRate(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvDampgSlewRate;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvDampgSlewRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvEffortSlewRate(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvEffortSlewRate;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvEffortSlewRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvRtnSlewRate(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvRtnSlewRate;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvRtnSlewRate = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacOutpTqOvrlSlew(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacOutpTqOvrlSlew;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacOutpTqOvrlSlew = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacReqdRtnCmdScaLoLim(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacReqdRtnCmdScaLoLim;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacReqdRtnCmdScaLoLim = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrLpFilFrq(void)
{
    extern __PST__g__25 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrLpFilFrq;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrLpFilFrq = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrMaxY(void)
{
    extern __PST__g__29 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrMaxY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 10; _main_gen_tmp_5_0++)
            {
                /* base type */
                BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrMaxY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrSpdX(void)
{
    extern __PST__g__29 BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrSpdX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 10; _main_gen_tmp_6_0++)
            {
                /* base type */
                BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrSpdX[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__26 BmwTqOvrlCdngAndDrvgDynFac_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 12; _main_gen_tmp_7_0++)
            {
                /* base type */
                BmwTqOvrlCdngAndDrvgDynFac_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdRampCmpl(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdRampCmpl;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdRampCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdStVari(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdStVari;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwTarSteerTqDrvrActrLpFilStVari(void)
{
    extern struct __PST__g__30 BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwTarSteerTqDrvrActrLpFilStVari;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwTarSteerTqDrvrActrLpFilStVari = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_DampgCmdScaRateLimrStVari(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_DampgCmdScaRateLimrStVari;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_DampgCmdScaRateLimrStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_EffortCmdScaRateLimrStVari(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_EffortCmdScaRateLimrStVari;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_EffortCmdScaRateLimrStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznBmwTarSteerTqDrvrActr(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznBmwTarSteerTqDrvrActr;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznBmwTarSteerTqDrvrActr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznSigActv(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznSigActv;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznSigActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_LimdCdndTqOvrl(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_LimdCdndTqOvrl;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_LimdCdndTqOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_MsgCycTmr(void)
{
    extern __PST__UINT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_MsgCycTmr;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_MsgCycTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDampgSlewInProgs(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDampgSlewInProgs;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDampgSlewInProgs = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynActv(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynActv;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynIfSt(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynIfSt;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynIfSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevEffortSlewInProgs(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevEffortSlewInProgs;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevEffortSlewInProgs = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevRtnSlewInProgs(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevRtnSlewInProgs;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevRtnSlewInProgs = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_RampToZeroEnad(void)
{
    extern __PST__UINT8 BmwTqOvrlCdngAndDrvgDynFac_Pim_RampToZeroEnad;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_RampToZeroEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_RtnCmdScaRateLimrStVari(void)
{
    extern __PST__FLOAT32 BmwTqOvrlCdngAndDrvgDynFac_Pim_RtnCmdScaRateLimrStVari;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Pim_RtnCmdScaRateLimrStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwTqOvrlCdngAndDrvgDynFac_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwTqOvrlCdngAndDrvgDynFac_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwTqOvrlCdngAndDrvgDynFac_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynDampgFacReq */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynDampgFacReq();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynEffortFacReq */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynEffortFacReq();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynErrIfActv */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynErrIfActv();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynRtnFacReq */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwDrvgDynRtnFacReq();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwOutpTqOvrlCmdEna */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwOutpTqOvrlCmdEna();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwTarSteerTqDrvrActr */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_BmwTarSteerTqDrvrActr();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynActv */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynActv();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynFacEna */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynFacEna();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynIfSt */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_DrvgDynIfSt();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_HwTq */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_HwTq();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_MotVelCrf */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_MotVelCrf();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_OutpTqOvrlRampInEna */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_OutpTqOvrlRampInEna();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Ip_VehSpd */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Ip_VehSpd();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Op_BmwOutpTqOvrlCmd : useless (never read) */

    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Op_DampgCmdSca : useless (never read) */

    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Op_EffortCmdSca : useless (never read) */

    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Op_RtnCmdSca : useless (never read) */

    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvDampgSlewRate */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvDampgSlewRate();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvEffortSlewRate */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvEffortSlewRate();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvRtnSlewRate */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacActvRtnSlewRate();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimX */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimX();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimY */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacDampgScaLoLimY();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimX */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimX();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimY */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacEffortScaHiLimY();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvDampgSlewRate */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvDampgSlewRate();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvEffortSlewRate */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvEffortSlewRate();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvRtnSlewRate */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacInactvRtnSlewRate();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacOutpTqOvrlSlew */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacOutpTqOvrlSlew();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacReqdRtnCmdScaLoLim */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacReqdRtnCmdScaLoLim();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrLpFilFrq */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrLpFilFrq();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrMaxY */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrMaxY();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrSpdX */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_BmwTqOvrlCdngAndDrvgDynFacTarSteerTqDrvrActrSpdX();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdRampCmpl */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdRampCmpl();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdStVari */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwOutpTqOvrlCmdStVari();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwTarSteerTqDrvrActrLpFilStVari */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_BmwTarSteerTqDrvrActrLpFilStVari();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_DampgCmdScaRateLimrStVari */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_DampgCmdScaRateLimrStVari();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_EffortCmdScaRateLimrStVari */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_EffortCmdScaRateLimrStVari();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznBmwTarSteerTqDrvrActr */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznBmwTarSteerTqDrvrActr();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznSigActv */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_FrznSigActv();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_LimdCdndTqOvrl */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_LimdCdndTqOvrl();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_MsgCycTmr */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_MsgCycTmr();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDampgSlewInProgs */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDampgSlewInProgs();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynActv */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynActv();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynIfSt */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevDrvgDynIfSt();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevEffortSlewInProgs */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevEffortSlewInProgs();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevRtnSlewInProgs */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_PrevRtnSlewInProgs();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_RampToZeroEnad */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_RampToZeroEnad();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Pim_RtnCmdScaRateLimrStVari */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Pim_RtnCmdScaRateLimrStVari();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwTqOvrlCdngAndDrvgDynFac_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwTqOvrlCdngAndDrvgDynFac_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
