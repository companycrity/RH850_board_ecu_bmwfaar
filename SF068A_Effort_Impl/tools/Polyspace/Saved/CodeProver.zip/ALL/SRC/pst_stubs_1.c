#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Effort_Ip_EffortCmdSca(void)
{
    extern __PST__FLOAT32 Effort_Ip_EffortCmdSca;
    
    /* initialization with random value */
    {
        Effort_Ip_EffortCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Effort_Ip_RackFEstimd(void)
{
    extern __PST__FLOAT32 Effort_Ip_RackFEstimd;
    
    /* initialization with random value */
    {
        Effort_Ip_RackFEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Effort_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 Effort_Ip_VehSpd;
    
    /* initialization with random value */
    {
        Effort_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Effort_Cal_EffortRackFX(void)
{
    extern __PST__g__22 Effort_Cal_EffortRackFX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 24; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 10; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    Effort_Cal_EffortRackFX[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Effort_Cal_EffortRackFY(void)
{
    extern __PST__g__22 Effort_Cal_EffortRackFY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 24; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 10; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    Effort_Cal_EffortRackFY[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Effort_Cal_EffortScaBlndX(void)
{
    extern __PST__g__25 Effort_Cal_EffortScaBlndX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 10; _main_gen_tmp_2_0++)
            {
                /* base type */
                Effort_Cal_EffortScaBlndX[_main_gen_tmp_2_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_Effort_Cal_EffortScaBlndY(void)
{
    extern __PST__g__23 Effort_Cal_EffortScaBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 10; _main_gen_tmp_3_0++)
            {
                /* base type */
                Effort_Cal_EffortScaBlndY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Effort_Cal_EffortScaRackFThd(void)
{
    extern __PST__g__27 Effort_Cal_EffortScaRackFThd;
    
    /* initialization with random value */
    {
        Effort_Cal_EffortScaRackFThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_Effort_Cal_EffortVehSpdBilnrSeln(void)
{
    extern __PST__g__23 Effort_Cal_EffortVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 10; _main_gen_tmp_4_0++)
            {
                /* base type */
                Effort_Cal_EffortVehSpdBilnrSeln[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Effort_Ip_EffortCmdSca */
    _main_gen_init_sym_Effort_Ip_EffortCmdSca();
    
    /* init for variable Effort_Ip_RackFEstimd */
    _main_gen_init_sym_Effort_Ip_RackFEstimd();
    
    /* init for variable Effort_Ip_VehSpd */
    _main_gen_init_sym_Effort_Ip_VehSpd();
    
    /* init for variable Effort_Op_HwTqCmdEffort : useless (never read) */

    /* init for variable Effort_Cal_EffortRackFX */
    _main_gen_init_sym_Effort_Cal_EffortRackFX();
    
    /* init for variable Effort_Cal_EffortRackFY */
    _main_gen_init_sym_Effort_Cal_EffortRackFY();
    
    /* init for variable Effort_Cal_EffortScaBlndX */
    _main_gen_init_sym_Effort_Cal_EffortScaBlndX();
    
    /* init for variable Effort_Cal_EffortScaBlndY */
    _main_gen_init_sym_Effort_Cal_EffortScaBlndY();
    
    /* init for variable Effort_Cal_EffortScaRackFThd */
    _main_gen_init_sym_Effort_Cal_EffortScaRackFThd();
    
    /* init for variable Effort_Cal_EffortVehSpdBilnrSeln */
    _main_gen_init_sym_Effort_Cal_EffortVehSpdBilnrSeln();
    
}
