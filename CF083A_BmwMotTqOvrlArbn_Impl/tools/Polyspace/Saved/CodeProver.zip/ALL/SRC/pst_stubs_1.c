#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_BmwNearStillVehSpdSts(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_BmwNearStillVehSpdSts;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_BmwNearStillVehSpdSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_BmwOutpTqOvrlCmd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_BmwOutpTqOvrlCmd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_BmwOutpTqOvrlCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_BmwTrfcJamAssiDampgSt(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_BmwTrfcJamAssiDampgSt;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_BmwTrfcJamAssiDampgSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_DrvgDynActv(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_DrvgDynActv;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_DrvgDynActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_HwOscnActv(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_HwOscnActv;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_HwOscnActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_HwOscnCmd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_HwOscnCmd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_HwOscnCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_HwOscnDcThdExcdd(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_HwOscnDcThdExcdd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_HwOscnDcThdExcdd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PinionCentrLrnCmd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_PinionCentrLrnCmd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_PinionCentrLrnCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PinionCentrLrnEna(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_PinionCentrLrnEna;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_PinionCentrLrnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PosnServoCmd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_PosnServoCmd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_PosnServoCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PosnServoEna(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Ip_PosnServoEna;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_PosnServoEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PullCmpCmd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_PullCmpCmd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_PullCmpCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_TrfcJamAssiCmd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_TrfcJamAssiCmd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_TrfcJamAssiCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 BmwMotTqOvrlArbn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnBmwNearStillVehSpdStsRefTiThd(void)
{
    extern __PST__g__25 BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnBmwNearStillVehSpdStsRefTiThd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnBmwNearStillVehSpdStsRefTiThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdRefTiThd(void)
{
    extern __PST__g__25 BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdRefTiThd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdRefTiThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdThd(void)
{
    extern __PST__g__26 BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdThd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModVehSpdThd(void)
{
    extern __PST__g__26 BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModVehSpdThd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModVehSpdThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnPullCmpCmdLim(void)
{
    extern __PST__g__26 BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnPullCmpCmdLim;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnPullCmpCmdLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnVehSpdRefTiThd(void)
{
    extern __PST__g__25 BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnVehSpdRefTiThd;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnVehSpdRefTiThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_BmwNearStillVehSpdStsCdnRefTi(void)
{
    extern __PST__UINT32 BmwMotTqOvrlArbn_Pim_BmwNearStillVehSpdStsCdnRefTi;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Pim_BmwNearStillVehSpdStsCdnRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_FctlErrStVari(void)
{
    extern __PST__UINT8 BmwMotTqOvrlArbn_Pim_FctlErrStVari;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Pim_FctlErrStVari = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_MfgModCmdCdnRefTi(void)
{
    extern __PST__UINT32 BmwMotTqOvrlArbn_Pim_MfgModCmdCdnRefTi;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Pim_MfgModCmdCdnRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_VehSpdCdnRefTi(void)
{
    extern __PST__UINT32 BmwMotTqOvrlArbn_Pim_VehSpdCdnRefTi;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Pim_VehSpdCdnRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwMotTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwMotTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwMotTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwMotTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwMotTqOvrlArbn_Ip_BmwNearStillVehSpdSts */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_BmwNearStillVehSpdSts();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_BmwOutpTqOvrlCmd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_BmwOutpTqOvrlCmd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_BmwTrfcJamAssiDampgSt */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_BmwTrfcJamAssiDampgSt();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_DrvgDynActv */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_DrvgDynActv();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_HwOscnActv */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_HwOscnActv();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_HwOscnCmd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_HwOscnCmd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_HwOscnDcThdExcdd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_HwOscnDcThdExcdd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_PinionCentrLrnCmd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PinionCentrLrnCmd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_PinionCentrLrnEna */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PinionCentrLrnEna();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_PosnServoCmd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PosnServoCmd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_PosnServoEna */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PosnServoEna();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_PullCmpCmd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_PullCmpCmd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_TrfcJamAssiCmd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_TrfcJamAssiCmd();
    
    /* init for variable BmwMotTqOvrlArbn_Ip_VehSpd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Ip_VehSpd();
    
    /* init for variable BmwMotTqOvrlArbn_Op_MotTqOvrlCmd : useless (never read) */

    /* init for variable BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnBmwNearStillVehSpdStsRefTiThd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnBmwNearStillVehSpdStsRefTiThd();
    
    /* init for variable BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdRefTiThd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdRefTiThd();
    
    /* init for variable BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdThd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModCmdThd();
    
    /* init for variable BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModVehSpdThd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnMfgModVehSpdThd();
    
    /* init for variable BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnPullCmpCmdLim */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnPullCmpCmdLim();
    
    /* init for variable BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnVehSpdRefTiThd */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Cal_BmwMotTqOvrlArbnVehSpdRefTiThd();
    
    /* init for variable BmwMotTqOvrlArbn_Pim_BmwNearStillVehSpdStsCdnRefTi */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_BmwNearStillVehSpdStsCdnRefTi();
    
    /* init for variable BmwMotTqOvrlArbn_Pim_FctlErrStVari */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_FctlErrStVari();
    
    /* init for variable BmwMotTqOvrlArbn_Pim_MfgModCmdCdnRefTi */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_MfgModCmdCdnRefTi();
    
    /* init for variable BmwMotTqOvrlArbn_Pim_VehSpdCdnRefTi */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Pim_VehSpdCdnRefTi();
    
    /* init for variable BmwMotTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwMotTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwMotTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwMotTqOvrlArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
