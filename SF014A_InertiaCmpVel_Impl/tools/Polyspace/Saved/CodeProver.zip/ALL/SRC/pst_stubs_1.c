#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__31 _main_gen_init_g31(void);

extern struct __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__30 _main_gen_init_g30(void)
{
    static struct __PST__g__30 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.FilSt1 = _main_gen_init_g10();
    x.FilSt2 = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_InertiaCmpVel_Ip_AssiCmdBas(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Ip_AssiCmdBas;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_AssiCmdBas = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_HwTq(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Ip_HwTq;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_InertiaCmpDecelGainDi(void)
{
    extern __PST__UINT8 InertiaCmpVel_Ip_InertiaCmpDecelGainDi;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_InertiaCmpDecelGainDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_InertiaCmpVelCmdDi(void)
{
    extern __PST__UINT8 InertiaCmpVel_Ip_InertiaCmpVelCmdDi;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_InertiaCmpVelCmdDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_VehLgtA(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Ip_VehLgtA;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_VehLgtA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Ip_VehSpd;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Ip_WhlImbRejctnAmp(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Ip_WhlImbRejctnAmp;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Ip_WhlImbRejctnAmp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgCoeffX(void)
{
    extern __PST__g__22 InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgCoeffX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 10; _main_gen_tmp_3_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgCoeffX[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgWhlImbRejctnOnY(void)
{
    extern __PST__g__22 InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgWhlImbRejctnOnY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 10; _main_gen_tmp_4_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgWhlImbRejctnOnY[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgY(void)
{
    extern __PST__g__22 InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 10; _main_gen_tmp_5_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatWhlImbRejctnOnY(void)
{
    extern __PST__g__22 InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatWhlImbRejctnOnY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 10; _main_gen_tmp_6_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatWhlImbRejctnOnY[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatY(void)
{
    extern __PST__g__22 InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 10; _main_gen_tmp_7_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelCmdScaY(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_InertiaCmpVelCmdScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 12; _main_gen_tmp_8_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelCmdScaY[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGain(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGain;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGain = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainFallSlew(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainFallSlew;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainFallSlew = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewX(void)
{
    extern __PST__g__26 InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 6; _main_gen_tmp_9_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewX[_main_gen_tmp_9_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewY(void)
{
    extern __PST__g__26 InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 6; _main_gen_tmp_10_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewY[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrq(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrq;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 12; _main_gen_tmp_11_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrq[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrqWhlImbRejctnOn(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrqWhlImbRejctnOn;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 12; _main_gen_tmp_12_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrqWhlImbRejctnOn[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgGainOffThd(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_InertiaCmpVelDampgGainOffThd;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelDampgGainOffThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgGainOnThd(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_InertiaCmpVelDampgGainOnThd;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelDampgGainOnThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgSpdBlndY(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_InertiaCmpVelDampgSpdBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 12; _main_gen_tmp_13_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgSpdBlndY[_main_gen_tmp_13_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndX(void)
{
    extern __PST__g__27 InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 5; _main_gen_tmp_14_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndX[_main_gen_tmp_14_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndY(void)
{
    extern __PST__g__27 InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 5; _main_gen_tmp_15_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndY[_main_gen_tmp_15_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDecelGainEnaCal(void)
{
    extern __PST__g__28 InertiaCmpVel_Cal_InertiaCmpVelDecelGainEnaCal;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelDecelGainEnaCal = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndX(void)
{
    extern __PST__g__29 InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 2; _main_gen_tmp_16_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndX[_main_gen_tmp_16_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndY(void)
{
    extern __PST__g__29 InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 2; _main_gen_tmp_17_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndY[_main_gen_tmp_17_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelMotInertia(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_InertiaCmpVelMotInertia;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelMotInertia = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagX(void)
{
    extern __PST__g__29 InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 2; _main_gen_tmp_18_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagX[_main_gen_tmp_18_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagY(void)
{
    extern __PST__g__29 InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 2; _main_gen_tmp_19_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagY[_main_gen_tmp_19_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelNotchBlndY(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_InertiaCmpVelNotchBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 12; _main_gen_tmp_20_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelNotchBlndY[_main_gen_tmp_20_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelFilFrq(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelFilFrq;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelFilFrq = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelSca(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelSca;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_21_0;
            
            for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 12; _main_gen_tmp_21_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelSca[_main_gen_tmp_21_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_SysGlbPrmSysKineRat = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_SysGlbPrmTorsBarStfn(void)
{
    extern __PST__g__25 InertiaCmpVel_Cal_SysGlbPrmTorsBarStfn;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Cal_SysGlbPrmTorsBarStfn = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__24 InertiaCmpVel_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 12; _main_gen_tmp_22_0++)
            {
                /* base type */
                InertiaCmpVel_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_22_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_DecelGain(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Pim_DecelGain;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_DecelGain = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_NotchFilChk(void)
{
    extern __PST__UINT8 InertiaCmpVel_Pim_NotchFilChk;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_NotchFilChk = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_PreScagCmpCmdPrev1(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Pim_PreScagCmpCmdPrev1;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_PreScagCmpCmdPrev1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_PreScagCmpCmdPrev2(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Pim_PreScagCmpCmdPrev2;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_PreScagCmpCmdPrev2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_ScaDrvrVelPrev1(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Pim_ScaDrvrVelPrev1;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_ScaDrvrVelPrev1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_ScaDrvrVelPrev2(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Pim_ScaDrvrVelPrev2;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_ScaDrvrVelPrev2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_TqSnsrAgPrev(void)
{
    extern __PST__FLOAT32 InertiaCmpVel_Pim_TqSnsrAgPrev;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_TqSnsrAgPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_TqSnsrVelFil(void)
{
    extern struct __PST__g__30 InertiaCmpVel_Pim_TqSnsrVelFil;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_TqSnsrVelFil = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_InertiaCmpVel_Pim_TqSnsrVelFilNotchSt(void)
{
    extern struct __PST__g__31 InertiaCmpVel_Pim_TqSnsrVelFilNotchSt;
    
    /* initialization with random value */
    {
        InertiaCmpVel_Pim_TqSnsrVelFilNotchSt = _main_gen_init_g31();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable InertiaCmpVel_Ip_AssiCmdBas */
    _main_gen_init_sym_InertiaCmpVel_Ip_AssiCmdBas();
    
    /* init for variable InertiaCmpVel_Ip_HwTq */
    _main_gen_init_sym_InertiaCmpVel_Ip_HwTq();
    
    /* init for variable InertiaCmpVel_Ip_InertiaCmpDecelGainDi */
    _main_gen_init_sym_InertiaCmpVel_Ip_InertiaCmpDecelGainDi();
    
    /* init for variable InertiaCmpVel_Ip_InertiaCmpVelCmdDi */
    _main_gen_init_sym_InertiaCmpVel_Ip_InertiaCmpVelCmdDi();
    
    /* init for variable InertiaCmpVel_Ip_MotVelCrf */
    _main_gen_init_sym_InertiaCmpVel_Ip_MotVelCrf();
    
    /* init for variable InertiaCmpVel_Ip_VehLgtA */
    _main_gen_init_sym_InertiaCmpVel_Ip_VehLgtA();
    
    /* init for variable InertiaCmpVel_Ip_VehSpd */
    _main_gen_init_sym_InertiaCmpVel_Ip_VehSpd();
    
    /* init for variable InertiaCmpVel_Ip_WhlImbRejctnAmp */
    _main_gen_init_sym_InertiaCmpVel_Ip_WhlImbRejctnAmp();
    
    /* init for variable InertiaCmpVel_Op_InertiaCmpVelCmd : useless (never read) */

    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgCoeffX */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgCoeffX();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgWhlImbRejctnOnY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgWhlImbRejctnOnY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgRollgY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatWhlImbRejctnOnY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatWhlImbRejctnOnY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelAssiBasdDampgStatY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelCmdScaY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelCmdScaY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGain */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGain();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainFallSlew */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainFallSlew();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewX */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewX();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgDecelGainRisngSlewY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrq */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrq();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrqWhlImbRejctnOn */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgFilFrqWhlImbRejctnOn();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgGainOffThd */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgGainOffThd();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgGainOnThd */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgGainOnThd();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgSpdBlndY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgSpdBlndY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndX */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndX();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDampgWhlImbRejctnBlndY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelDecelGainEnaCal */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelDecelGainEnaCal();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndX */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndX();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelModWhlImbRejctnBlndY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelMotInertia */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelMotInertia();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagX */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagX();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelMotVelBasdOutpScagY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelNotchBlndY */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelNotchBlndY();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelFilFrq */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelFilFrq();
    
    /* init for variable InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelSca */
    _main_gen_init_sym_InertiaCmpVel_Cal_InertiaCmpVelTqSnsrVelSca();
    
    /* init for variable InertiaCmpVel_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_InertiaCmpVel_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable InertiaCmpVel_Cal_SysGlbPrmTorsBarStfn */
    _main_gen_init_sym_InertiaCmpVel_Cal_SysGlbPrmTorsBarStfn();
    
    /* init for variable InertiaCmpVel_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_InertiaCmpVel_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelAssiBasdDampgCoeff : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelCalcdInertiaCmp : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelFilFrq : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelMotVelBasdOutpScag : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelNotScadDrvrVel : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelNotchBlndVal : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelNotchInpVal : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelNotchOutpVal : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelRawDecelGain : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelScadDrvrVel : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_dInertiaCmpVelTqSnsrVelFildVal : useless (never read) */

    /* init for variable InertiaCmpVel_Pim_DecelGain */
    _main_gen_init_sym_InertiaCmpVel_Pim_DecelGain();
    
    /* init for variable InertiaCmpVel_Pim_NotchFilChk */
    _main_gen_init_sym_InertiaCmpVel_Pim_NotchFilChk();
    
    /* init for variable InertiaCmpVel_Pim_PreScagCmpCmdPrev1 */
    _main_gen_init_sym_InertiaCmpVel_Pim_PreScagCmpCmdPrev1();
    
    /* init for variable InertiaCmpVel_Pim_PreScagCmpCmdPrev2 */
    _main_gen_init_sym_InertiaCmpVel_Pim_PreScagCmpCmdPrev2();
    
    /* init for variable InertiaCmpVel_Pim_ScaDrvrVelPrev1 */
    _main_gen_init_sym_InertiaCmpVel_Pim_ScaDrvrVelPrev1();
    
    /* init for variable InertiaCmpVel_Pim_ScaDrvrVelPrev2 */
    _main_gen_init_sym_InertiaCmpVel_Pim_ScaDrvrVelPrev2();
    
    /* init for variable InertiaCmpVel_Pim_TqSnsrAgPrev */
    _main_gen_init_sym_InertiaCmpVel_Pim_TqSnsrAgPrev();
    
    /* init for variable InertiaCmpVel_Pim_TqSnsrVelFil */
    _main_gen_init_sym_InertiaCmpVel_Pim_TqSnsrVelFil();
    
    /* init for variable InertiaCmpVel_Pim_TqSnsrVelFilNotchSt */
    _main_gen_init_sym_InertiaCmpVel_Pim_TqSnsrVelFilNotchSt();
    
}
