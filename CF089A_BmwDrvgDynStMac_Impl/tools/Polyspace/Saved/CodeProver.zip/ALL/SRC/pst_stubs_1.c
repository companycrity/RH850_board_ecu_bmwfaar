#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwDrvgDynEnaReq(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwDrvgDynEnaReq;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwDrvgDynEnaReq = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfr(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfr;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfrVld(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfrVld;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfrVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfr(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfr;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfrVld(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfrVld;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfrVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfr(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfr;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfrVld(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfrVld;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfrVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReq(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReq;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReq = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReqVld(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReqVld;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReqVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwVehCdn(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_BmwVehCdn;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_BmwVehCdn = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_DampgCmdSca(void)
{
    extern __PST__FLOAT32 BmwDrvgDynStMac_Ip_DampgCmdSca;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_DampgCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_DiagcStsCtrldShtDwnFltPrsnt(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_DiagcStsCtrldShtDwnFltPrsnt;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_DiagcStsCtrldShtDwnFltPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_DiagcStsNonRcvrlReqDiFltPrsnt(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_DiagcStsNonRcvrlReqDiFltPrsnt;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_DiagcStsNonRcvrlReqDiFltPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_EffortCmdSca(void)
{
    extern __PST__FLOAT32 BmwDrvgDynStMac_Ip_EffortCmdSca;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_EffortCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_MotTqCmdPwrLimd(void)
{
    extern __PST__FLOAT32 BmwDrvgDynStMac_Ip_MotTqCmdPwrLimd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_MotTqCmdPwrLimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_MotTqOvrlCmd(void)
{
    extern __PST__FLOAT32 BmwDrvgDynStMac_Ip_MotTqOvrlCmd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_MotTqOvrlCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_RtnCmdSca(void)
{
    extern __PST__FLOAT32 BmwDrvgDynStMac_Ip_RtnCmdSca;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_RtnCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_StsSteerAssi(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_StsSteerAssi;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_StsSteerAssi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Ip_SysStFltOutpReqDi(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Ip_SysStFltOutpReqDi;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Ip_SysStFltOutpReqDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacAssiLvlThd(void)
{
    extern __PST__g__25 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacAssiLvlThd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacAssiLvlThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacDampgCmdScaDft(void)
{
    extern __PST__g__26 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacDampgCmdScaDft;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacDampgCmdScaDft = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacEffortCmdScaDft(void)
{
    extern __PST__g__26 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacEffortCmdScaDft;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacEffortCmdScaDft = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacErrIfTmrThd(void)
{
    extern __PST__g__25 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacErrIfTmrThd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacErrIfTmrThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlActvtThd(void)
{
    extern __PST__g__26 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlActvtThd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlActvtThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlDeactvtThd(void)
{
    extern __PST__g__26 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlDeactvtThd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlDeactvtThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacRtnCmdScaDft(void)
{
    extern __PST__g__26 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacRtnCmdScaDft;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacRtnCmdScaDft = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacVehCdnTmrThd(void)
{
    extern __PST__g__25 BmwDrvgDynStMac_Cal_BmwDrvgDynStMacVehCdnTmrThd;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Cal_BmwDrvgDynStMacVehCdnTmrThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_AssiLvlActvtTi(void)
{
    extern __PST__UINT32 BmwDrvgDynStMac_Pim_AssiLvlActvtTi;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_AssiLvlActvtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_AssiLvlDeactvtTi(void)
{
    extern __PST__UINT32 BmwDrvgDynStMac_Pim_AssiLvlDeactvtTi;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_AssiLvlDeactvtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_ErrIfTi(void)
{
    extern __PST__UINT32 BmwDrvgDynStMac_Pim_ErrIfTi;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_ErrIfTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnActvt(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnActvt;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnActvt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnDeactvt(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnDeactvt;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnDeactvt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_StMacSt(void)
{
    extern __PST__UINT8 BmwDrvgDynStMac_Pim_StMacSt;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_StMacSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Pim_VehCdnTi(void)
{
    extern __PST__UINT32 BmwDrvgDynStMac_Pim_VehCdnTi;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Pim_VehCdnTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 BmwDrvgDynStMac_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_BmwDrvgDynStMac_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 BmwDrvgDynStMac_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        BmwDrvgDynStMac_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BmwDrvgDynStMac_Ip_BmwDrvgDynEnaReq */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwDrvgDynEnaReq();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfr */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfr();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfrVld */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwDrvgDynFacQlfrVld();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfr */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfr();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfrVld */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarHwTqOvrlQlfrVld();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfr */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfr();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfrVld */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTarSteerTqDrvrActrQlfrVld();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReq */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReq();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReqVld */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwTrfcJamAssiDampgStReqVld();
    
    /* init for variable BmwDrvgDynStMac_Ip_BmwVehCdn */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_BmwVehCdn();
    
    /* init for variable BmwDrvgDynStMac_Ip_DampgCmdSca */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_DampgCmdSca();
    
    /* init for variable BmwDrvgDynStMac_Ip_DiagcStsCtrldShtDwnFltPrsnt */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_DiagcStsCtrldShtDwnFltPrsnt();
    
    /* init for variable BmwDrvgDynStMac_Ip_DiagcStsNonRcvrlReqDiFltPrsnt */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_DiagcStsNonRcvrlReqDiFltPrsnt();
    
    /* init for variable BmwDrvgDynStMac_Ip_EffortCmdSca */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_EffortCmdSca();
    
    /* init for variable BmwDrvgDynStMac_Ip_MotTqCmdPwrLimd */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_MotTqCmdPwrLimd();
    
    /* init for variable BmwDrvgDynStMac_Ip_MotTqOvrlCmd */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_MotTqOvrlCmd();
    
    /* init for variable BmwDrvgDynStMac_Ip_RtnCmdSca */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_RtnCmdSca();
    
    /* init for variable BmwDrvgDynStMac_Ip_StsSteerAssi */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_StsSteerAssi();
    
    /* init for variable BmwDrvgDynStMac_Ip_SysStFltOutpReqDi */
    _main_gen_init_sym_BmwDrvgDynStMac_Ip_SysStFltOutpReqDi();
    
    /* init for variable BmwDrvgDynStMac_Op_DrvgDynActv : useless (never read) */

    /* init for variable BmwDrvgDynStMac_Op_DrvgDynIfSt : useless (never read) */

    /* init for variable BmwDrvgDynStMac_Op_OutpTqOvrlRampInEna : useless (never read) */

    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacAssiLvlThd */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacAssiLvlThd();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacDampgCmdScaDft */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacDampgCmdScaDft();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacEffortCmdScaDft */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacEffortCmdScaDft();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacErrIfTmrThd */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacErrIfTmrThd();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlActvtThd */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlActvtThd();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlDeactvtThd */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacMotTqCmdOvrlDeactvtThd();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacRtnCmdScaDft */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacRtnCmdScaDft();
    
    /* init for variable BmwDrvgDynStMac_Cal_BmwDrvgDynStMacVehCdnTmrThd */
    _main_gen_init_sym_BmwDrvgDynStMac_Cal_BmwDrvgDynStMacVehCdnTmrThd();
    
    /* init for variable BmwDrvgDynStMac_Pim_AssiLvlActvtTi */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_AssiLvlActvtTi();
    
    /* init for variable BmwDrvgDynStMac_Pim_AssiLvlDeactvtTi */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_AssiLvlDeactvtTi();
    
    /* init for variable BmwDrvgDynStMac_Pim_ErrIfTi */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_ErrIfTi();
    
    /* init for variable BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnActvt */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnActvt();
    
    /* init for variable BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnDeactvt */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_MotTqCmdPwrLimdCdnDeactvt();
    
    /* init for variable BmwDrvgDynStMac_Pim_StMacSt */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_StMacSt();
    
    /* init for variable BmwDrvgDynStMac_Pim_VehCdnTi */
    _main_gen_init_sym_BmwDrvgDynStMac_Pim_VehCdnTi();
    
    /* init for variable BmwDrvgDynStMac_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_BmwDrvgDynStMac_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable BmwDrvgDynStMac_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable BmwDrvgDynStMac_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_BmwDrvgDynStMac_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
