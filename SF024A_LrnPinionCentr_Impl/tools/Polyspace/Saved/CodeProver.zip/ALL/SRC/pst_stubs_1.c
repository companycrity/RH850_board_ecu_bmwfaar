#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__28 _main_gen_init_g28(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__28 _main_gen_init_g28(void)
{
    static struct __PST__g__28 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_LrnPinionCentr_Ip_HwAg(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Ip_HwAg;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Ip_PinionCentrLrnEna(void)
{
    extern __PST__UINT8 LrnPinionCentr_Ip_PinionCentrLrnEna;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Ip_PinionCentrLrnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrDampgCtrlGain(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrDampgCtrlGain;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrDampgCtrlGain = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHldTq(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrHldTq;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrHldTq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHldTqErrThd(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrHldTqErrThd;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrHldTqErrThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHldTqRateLim(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrHldTqRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrHldTqRateLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHwPosnErrThd(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrHwPosnErrThd;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrHwPosnErrThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrIntglCtrlGain(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrIntglCtrlGain;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrIntglCtrlGain = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrMaxTqCmd(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrMaxTqCmd;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrMaxTqCmd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrMinMotTq(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrMinMotTq;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrMinMotTq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrMotVelThd(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrMotVelThd;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrMotVelThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrPropCtrlGain(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_LrnPinionCentrPropCtrlGain;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrPropCtrlGain = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrTiOutThd(void)
{
    extern __PST__g__27 LrnPinionCentr_Cal_LrnPinionCentrTiOutThd;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrTiOutThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrTiThd(void)
{
    extern __PST__g__27 LrnPinionCentr_Cal_LrnPinionCentrTiThd;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_LrnPinionCentrTiThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__26 LrnPinionCentr_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cal_SysGlbPrmSysKineRat = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_MaxHwPosnPrev(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_MaxHwPosnPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_MaxHwPosnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_MinHwPosnPrev(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_MinHwPosnPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_MinHwPosnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_PinionCentrLrnEnaPrev(void)
{
    extern __PST__UINT8 LrnPinionCentr_Pim_PinionCentrLrnEnaPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_PinionCentrLrnEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_PinionCentrLrnHwCentrPrev(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_PinionCentrLrnHwCentrPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_PinionCentrLrnHwCentrPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_PinionCentrLrnHwTrvlPrev(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_PinionCentrLrnHwTrvlPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_PinionCentrLrnHwTrvlPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1PosnErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl1PosnErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl1PosnErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1RateLimdPosnErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl1RateLimdPosnErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl1RateLimdPosnErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1TmrARefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl1TmrARefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl1TmrARefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1TmrBRefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl1TmrBRefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl1TmrBRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2RateLimdTqErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl2RateLimdTqErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl2RateLimdTqErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2TmrARefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl2TmrARefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl2TmrARefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2TmrBRefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl2TmrBRefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl2TmrBRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2TqErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl2TqErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl2TqErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3PosnErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl3PosnErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl3PosnErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3RateLimdPosnErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl3RateLimdPosnErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl3RateLimdPosnErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3RateLimdTqErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl3RateLimdTqErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl3RateLimdTqErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3TmrARefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl3TmrARefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl3TmrARefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3TmrBRefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl3TmrBRefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl3TmrBRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3TqErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl3TqErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl3TqErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4RateLimdTqErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl4RateLimdTqErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl4RateLimdTqErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4TmrARefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl4TmrARefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl4TmrARefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4TmrBRefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl4TmrBRefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl4TmrBRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4TqErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl4TqErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl4TqErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5IntglEnaOutpPrev(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl5IntglEnaOutpPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5IntglEnaOutpPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5PosnErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl5PosnErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5PosnErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5RateLimdPosnErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl5RateLimdPosnErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5RateLimdPosnErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5RateLimdTqErrLpFil(void)
{
    extern struct __PST__g__28 LrnPinionCentr_Pim_StCtrl5RateLimdTqErrLpFil;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5RateLimdTqErrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5TmrARefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl5TmrARefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5TmrARefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5TmrBRefTi(void)
{
    extern __PST__UINT32 LrnPinionCentr_Pim_StCtrl5TmrBRefTi;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5TmrBRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5TqErrRateLim(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_StCtrl5TqErrRateLim;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StCtrl5TqErrRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_StEstimdPrev(void)
{
    extern __PST__UINT8 LrnPinionCentr_Pim_StEstimdPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_StEstimdPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_TarHwAg(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_TarHwAg;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_TarHwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_TarMotVel(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_TarMotVel;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_TarMotVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Pim_TqCmdEstimdPrev(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Pim_TqCmdEstimdPrev;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Pim_TqCmdEstimdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Irv_TarA(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Irv_TarA;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Irv_TarA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Irv_TarVel(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Irv_TarVel;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Irv_TarVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 LrnPinionCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 LrnPinionCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cli_SetInpPrm_TarVel(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Cli_SetInpPrm_TarVel;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cli_SetInpPrm_TarVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_LrnPinionCentr_Cli_SetInpPrm_TarA(void)
{
    extern __PST__FLOAT32 LrnPinionCentr_Cli_SetInpPrm_TarA;
    
    /* initialization with random value */
    {
        LrnPinionCentr_Cli_SetInpPrm_TarA = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable LrnPinionCentr_Ip_HwAg */
    _main_gen_init_sym_LrnPinionCentr_Ip_HwAg();
    
    /* init for variable LrnPinionCentr_Ip_MotVelCrf */
    _main_gen_init_sym_LrnPinionCentr_Ip_MotVelCrf();
    
    /* init for variable LrnPinionCentr_Ip_PinionCentrLrnEna */
    _main_gen_init_sym_LrnPinionCentr_Ip_PinionCentrLrnEna();
    
    /* init for variable LrnPinionCentr_Op_PinionCentrLrnCmd : useless (never read) */

    /* init for variable LrnPinionCentr_Op_PinionCentrLrnHwCentr : useless (never read) */

    /* init for variable LrnPinionCentr_Op_PinionCentrLrnHwTrvl : useless (never read) */

    /* init for variable LrnPinionCentr_Op_PinionCentrLrnSt : useless (never read) */

    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrDampgCtrlGain */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrDampgCtrlGain();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrHldTq */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHldTq();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrHldTqErrThd */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHldTqErrThd();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrHldTqRateLim */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHldTqRateLim();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrHwPosnErrThd */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrHwPosnErrThd();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrIntglCtrlGain */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrIntglCtrlGain();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrMaxTqCmd */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrMaxTqCmd();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrMinMotTq */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrMinMotTq();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrMotVelThd */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrMotVelThd();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrPropCtrlGain */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrPropCtrlGain();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrTiOutThd */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrTiOutThd();
    
    /* init for variable LrnPinionCentr_Cal_LrnPinionCentrTiThd */
    _main_gen_init_sym_LrnPinionCentr_Cal_LrnPinionCentrTiThd();
    
    /* init for variable LrnPinionCentr_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_LrnPinionCentr_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable LrnPinionCentr_Pim_dLrnPinionCentrHwPosnCmd : useless (never read) */

    /* init for variable LrnPinionCentr_Pim_MaxHwPosnPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_MaxHwPosnPrev();
    
    /* init for variable LrnPinionCentr_Pim_MinHwPosnPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_MinHwPosnPrev();
    
    /* init for variable LrnPinionCentr_Pim_PinionCentrLrnEnaPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_PinionCentrLrnEnaPrev();
    
    /* init for variable LrnPinionCentr_Pim_PinionCentrLrnHwCentrPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_PinionCentrLrnHwCentrPrev();
    
    /* init for variable LrnPinionCentr_Pim_PinionCentrLrnHwTrvlPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_PinionCentrLrnHwTrvlPrev();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl1PosnErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1PosnErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl1RateLimdPosnErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1RateLimdPosnErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl1TmrARefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1TmrARefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl1TmrBRefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl1TmrBRefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl2RateLimdTqErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2RateLimdTqErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl2TmrARefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2TmrARefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl2TmrBRefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2TmrBRefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl2TqErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl2TqErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl3PosnErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3PosnErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl3RateLimdPosnErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3RateLimdPosnErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl3RateLimdTqErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3RateLimdTqErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl3TmrARefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3TmrARefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl3TmrBRefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3TmrBRefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl3TqErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl3TqErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl4RateLimdTqErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4RateLimdTqErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl4TmrARefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4TmrARefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl4TmrBRefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4TmrBRefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl4TqErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl4TqErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5IntglEnaOutpPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5IntglEnaOutpPrev();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5PosnErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5PosnErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5RateLimdPosnErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5RateLimdPosnErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5RateLimdTqErrLpFil */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5RateLimdTqErrLpFil();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5TmrARefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5TmrARefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5TmrBRefTi */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5TmrBRefTi();
    
    /* init for variable LrnPinionCentr_Pim_StCtrl5TqErrRateLim */
    _main_gen_init_sym_LrnPinionCentr_Pim_StCtrl5TqErrRateLim();
    
    /* init for variable LrnPinionCentr_Pim_StEstimdPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_StEstimdPrev();
    
    /* init for variable LrnPinionCentr_Pim_TarHwAg */
    _main_gen_init_sym_LrnPinionCentr_Pim_TarHwAg();
    
    /* init for variable LrnPinionCentr_Pim_TarMotVel */
    _main_gen_init_sym_LrnPinionCentr_Pim_TarMotVel();
    
    /* init for variable LrnPinionCentr_Pim_TqCmdEstimdPrev */
    _main_gen_init_sym_LrnPinionCentr_Pim_TqCmdEstimdPrev();
    
    /* init for variable LrnPinionCentr_Irv_TarA */
    _main_gen_init_sym_LrnPinionCentr_Irv_TarA();
    
    /* init for variable LrnPinionCentr_Irv_TarVel */
    _main_gen_init_sym_LrnPinionCentr_Irv_TarVel();
    
    /* init for variable LrnPinionCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_LrnPinionCentr_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable LrnPinionCentr_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable LrnPinionCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_LrnPinionCentr_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable LrnPinionCentr_Cli_SetInpPrm_TarVel */
    _main_gen_init_sym_LrnPinionCentr_Cli_SetInpPrm_TarVel();
    
    /* init for variable LrnPinionCentr_Cli_SetInpPrm_TarA */
    _main_gen_init_sym_LrnPinionCentr_Cli_SetInpPrm_TarA();
    
}
