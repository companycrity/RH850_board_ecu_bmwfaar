#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SteerCmdArbnAndLim_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 SteerCmdArbnAndLim_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 SteerCmdArbnAndLim_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmd(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmdEna(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmdEna;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmdEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_AssiLnrGain(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_AssiLnrGain;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_AssiLnrGain = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_AssiLnrGainEna(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Ip_AssiLnrGainEna;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_AssiLnrGainEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_EotCtrlSca(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_EotCtrlSca;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_EotCtrlSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_FalbckAssiMotTqCmd(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_FalbckAssiMotTqCmd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_FalbckAssiMotTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_HwTq(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_HwTq;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_LimdMotTqCmd(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_LimdMotTqCmd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_LimdMotTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_MotTqCmd(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_MotTqCmd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_MotTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_MotTqCmdLimDi(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Ip_MotTqCmdLimDi;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_MotTqCmdLimDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_StallMotTqLim(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_StallMotTqLim;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_StallMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_SysMotTqCmdSca(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_SysMotTqCmdSca;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_SysMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_ThermMotTqLim(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_ThermMotTqLim;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_ThermMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_VehSpd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Ip_VehSpdMotTqLim(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Ip_VehSpdMotTqLim;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Ip_VehSpdMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFalbckTiThd(void)
{
    extern __PST__g__28 SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFalbckTiThd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFalbckTiThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFwTiThd(void)
{
    extern __PST__g__28 SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFwTiThd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFwTiThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Pim_FalbckDebStVari(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Pim_FalbckDebStVari;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Pim_FalbckDebStVari = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Pim_FwDebStVari(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Pim_FwDebStVari;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Pim_FwDebStVari = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFalbck(void)
{
    extern __PST__UINT32 SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFalbck;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFalbck = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFw(void)
{
    extern __PST__UINT32 SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFw;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFw = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimSt(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimSt;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Irv_ProcdManTqCmd(void)
{
    extern __PST__FLOAT32 SteerCmdArbnAndLim_Irv_ProcdManTqCmd;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Irv_ProcdManTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SteerCmdArbnAndLim_Irv_ProcdManTqCmdEna(void)
{
    extern __PST__UINT8 SteerCmdArbnAndLim_Irv_ProcdManTqCmdEna;
    
    /* initialization with random value */
    {
        SteerCmdArbnAndLim_Irv_ProcdManTqCmdEna = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SteerCmdArbnAndLim_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_SteerCmdArbnAndLim_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable SteerCmdArbnAndLim_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_SteerCmdArbnAndLim_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmd();
    
    /* init for variable SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmdEna */
    _main_gen_init_sym_SteerCmdArbnAndLim_Cli_SetManTqCmd_ManTqCmdEna();
    
    /* init for variable SteerCmdArbnAndLim_Cli_SetManTqCmd_Return : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Srv_SetNtcSts_Return */
    _main_gen_init_sym_SteerCmdArbnAndLim_Srv_SetNtcSts_Return();
    
    /* init for variable SteerCmdArbnAndLim_Ip_AssiLnrGain */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_AssiLnrGain();
    
    /* init for variable SteerCmdArbnAndLim_Ip_AssiLnrGainEna */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_AssiLnrGainEna();
    
    /* init for variable SteerCmdArbnAndLim_Ip_EotCtrlSca */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_EotCtrlSca();
    
    /* init for variable SteerCmdArbnAndLim_Ip_FalbckAssiMotTqCmd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_FalbckAssiMotTqCmd();
    
    /* init for variable SteerCmdArbnAndLim_Ip_HwTq */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_HwTq();
    
    /* init for variable SteerCmdArbnAndLim_Ip_LimdMotTqCmd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_LimdMotTqCmd();
    
    /* init for variable SteerCmdArbnAndLim_Ip_MotTqCmd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_MotTqCmd();
    
    /* init for variable SteerCmdArbnAndLim_Ip_MotTqCmdLimDi */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_MotTqCmdLimDi();
    
    /* init for variable SteerCmdArbnAndLim_Ip_StallMotTqLim */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_StallMotTqLim();
    
    /* init for variable SteerCmdArbnAndLim_Ip_SysMotTqCmdSca */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_SysMotTqCmdSca();
    
    /* init for variable SteerCmdArbnAndLim_Ip_ThermMotTqLim */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_ThermMotTqLim();
    
    /* init for variable SteerCmdArbnAndLim_Ip_VehSpd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_VehSpd();
    
    /* init for variable SteerCmdArbnAndLim_Ip_VehSpdMotTqLim */
    _main_gen_init_sym_SteerCmdArbnAndLim_Ip_VehSpdMotTqLim();
    
    /* init for variable SteerCmdArbnAndLim_Op_ArbdMotTqCmd : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Op_MotTqCmdLimdPreStall : useless (never read) */

    /* init for variable SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFalbckTiThd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFalbckTiThd();
    
    /* init for variable SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFwTiThd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Cal_SteerCmdArbnAndLimFwTiThd();
    
    /* init for variable SteerCmdArbnAndLim_Pim_FalbckDebStVari */
    _main_gen_init_sym_SteerCmdArbnAndLim_Pim_FalbckDebStVari();
    
    /* init for variable SteerCmdArbnAndLim_Pim_FwDebStVari */
    _main_gen_init_sym_SteerCmdArbnAndLim_Pim_FwDebStVari();
    
    /* init for variable SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFalbck */
    _main_gen_init_sym_SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFalbck();
    
    /* init for variable SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFw */
    _main_gen_init_sym_SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimDebStFw();
    
    /* init for variable SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimSt */
    _main_gen_init_sym_SteerCmdArbnAndLim_Pim_SteerCmdArbnAndLimSt();
    
    /* init for variable SteerCmdArbnAndLim_Irv_ProcdManTqCmd */
    _main_gen_init_sym_SteerCmdArbnAndLim_Irv_ProcdManTqCmd();
    
    /* init for variable SteerCmdArbnAndLim_Irv_ProcdManTqCmdEna */
    _main_gen_init_sym_SteerCmdArbnAndLim_Irv_ProcdManTqCmdEna();
    
}
