#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__642 _main_gen_init_g642(void);

extern union __PST__g__603 _main_gen_init_g603(void);

extern union __PST__g__575 _main_gen_init_g575(void);

extern __PST__g__491 _main_gen_init_g491(void);

extern __PST__g__481 _main_gen_init_g481(void);

extern union __PST__g__231 _main_gen_init_g231(void);

extern __PST__g__225 _main_gen_init_g225(void);

extern union __PST__g__201 _main_gen_init_g201(void);

extern union __PST__g__194 _main_gen_init_g194(void);

extern union __PST__g__187 _main_gen_init_g187(void);

extern __PST__g__168 _main_gen_init_g168(void);

extern struct __PST__g__145 _main_gen_init_g145(void);

extern union __PST__g__143 _main_gen_init_g143(void);

extern struct __PST__g__159 _main_gen_init_g159(void);

extern union __PST__g__158 _main_gen_init_g158(void);

extern struct __PST__g__150 _main_gen_init_g150(void);

extern union __PST__g__149 _main_gen_init_g149(void);

extern union __PST__g__152 _main_gen_init_g152(void);

extern struct __PST__g__141 _main_gen_init_g141(void);

extern union __PST__g__140 _main_gen_init_g140(void);

extern union __PST__g__136 _main_gen_init_g136(void);

extern union __PST__g__134 _main_gen_init_g134(void);

extern union __PST__g__132 _main_gen_init_g132(void);

extern union __PST__g__128 _main_gen_init_g128(void);

extern union __PST__g__126 _main_gen_init_g126(void);

extern union __PST__g__124 _main_gen_init_g124(void);

extern union __PST__g__122 _main_gen_init_g122(void);

extern union __PST__g__117 _main_gen_init_g117(void);

extern union __PST__g__81 _main_gen_init_g81(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__117 _main_gen_init_g117(void)
{
    static union __PST__g__117 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__122 _main_gen_init_g122(void)
{
    static union __PST__g__122 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__124 _main_gen_init_g124(void)
{
    static union __PST__g__124 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__126 _main_gen_init_g126(void)
{
    static union __PST__g__126 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__128 _main_gen_init_g128(void)
{
    static union __PST__g__128 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__132 _main_gen_init_g132(void)
{
    static union __PST__g__132 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__134 _main_gen_init_g134(void)
{
    static union __PST__g__134 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__136 _main_gen_init_g136(void)
{
    static union __PST__g__136 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__141 _main_gen_init_g141(void)
{
    static struct __PST__g__141 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DTE = bitf;
    }
    return x;
}

union __PST__g__140 _main_gen_init_g140(void)
{
    static union __PST__g__140 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g141();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__152 _main_gen_init_g152(void)
{
    static union __PST__g__152 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__150 _main_gen_init_g150(void)
{
    static struct __PST__g__150 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.TCC = bitf;
    }
    return x;
}

union __PST__g__149 _main_gen_init_g149(void)
{
    static union __PST__g__149 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g150();
    return x;
}

struct __PST__g__159 _main_gen_init_g159(void)
{
    static struct __PST__g__159 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DRQC = bitf;
    }
    return x;
}

union __PST__g__158 _main_gen_init_g158(void)
{
    static union __PST__g__158 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g159();
    return x;
}

struct __PST__g__145 _main_gen_init_g145(void)
{
    static struct __PST__g__145 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.TC = bitf;
    }
    return x;
}

union __PST__g__143 _main_gen_init_g143(void)
{
    static union __PST__g__143 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g145();
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* struct/union type */
    x.CMVC = _main_gen_init_g81();
    x.DM00CM = _main_gen_init_g117();
    x.DM01CM = _main_gen_init_g117();
    x.DM02CM = _main_gen_init_g117();
    x.DM03CM = _main_gen_init_g117();
    x.DM04CM = _main_gen_init_g117();
    x.DM06CM = _main_gen_init_g117();
    x.DM07CM = _main_gen_init_g117();
    x.DM11CM = _main_gen_init_g117();
    x.DM12CM = _main_gen_init_g117();
    x.DM13CM = _main_gen_init_g117();
    x.DM14CM = _main_gen_init_g117();
    x.DM15CM = _main_gen_init_g117();
    x.DM16CM = _main_gen_init_g117();
    x.DM17CM = _main_gen_init_g117();
    x.DSA0 = _main_gen_init_g122();
    x.DDA0 = _main_gen_init_g124();
    x.DTC0 = _main_gen_init_g126();
    x.DTCT0 = _main_gen_init_g128();
    x.DRSA0 = _main_gen_init_g132();
    x.DRDA0 = _main_gen_init_g134();
    x.DRTC0 = _main_gen_init_g136();
    x.DCEN0 = _main_gen_init_g140();
    x.DTFR0 = _main_gen_init_g152();
    x.DSA1 = _main_gen_init_g122();
    x.DDA1 = _main_gen_init_g124();
    x.DTC1 = _main_gen_init_g126();
    x.DTCT1 = _main_gen_init_g128();
    x.DRSA1 = _main_gen_init_g132();
    x.DRDA1 = _main_gen_init_g134();
    x.DRTC1 = _main_gen_init_g136();
    x.DCEN1 = _main_gen_init_g140();
    x.DTFR1 = _main_gen_init_g152();
    x.DSA2 = _main_gen_init_g122();
    x.DDA2 = _main_gen_init_g124();
    x.DTC2 = _main_gen_init_g126();
    x.DTCT2 = _main_gen_init_g128();
    x.DRSA2 = _main_gen_init_g132();
    x.DRDA2 = _main_gen_init_g134();
    x.DRTC2 = _main_gen_init_g136();
    x.DCEN2 = _main_gen_init_g140();
    x.DTFR2 = _main_gen_init_g152();
    x.DSA3 = _main_gen_init_g122();
    x.DDA3 = _main_gen_init_g124();
    x.DTC3 = _main_gen_init_g126();
    x.DTCT3 = _main_gen_init_g128();
    x.DRSA3 = _main_gen_init_g132();
    x.DRDA3 = _main_gen_init_g134();
    x.DRTC3 = _main_gen_init_g136();
    x.DCEN3 = _main_gen_init_g140();
    x.DTFR3 = _main_gen_init_g152();
    x.DSA4 = _main_gen_init_g122();
    x.DDA4 = _main_gen_init_g124();
    x.DTC4 = _main_gen_init_g126();
    x.DTCT4 = _main_gen_init_g128();
    x.DRSA4 = _main_gen_init_g132();
    x.DRDA4 = _main_gen_init_g134();
    x.DRTC4 = _main_gen_init_g136();
    x.DCEN4 = _main_gen_init_g140();
    x.DTFR4 = _main_gen_init_g152();
    x.DSA6 = _main_gen_init_g122();
    x.DDA6 = _main_gen_init_g124();
    x.DTC6 = _main_gen_init_g126();
    x.DTCT6 = _main_gen_init_g128();
    x.DRSA6 = _main_gen_init_g132();
    x.DRDA6 = _main_gen_init_g134();
    x.DRTC6 = _main_gen_init_g136();
    x.DCEN6 = _main_gen_init_g140();
    x.DCSTC6 = _main_gen_init_g149();
    x.DTFR6 = _main_gen_init_g152();
    x.DTFRRQC6 = _main_gen_init_g158();
    x.DSA7 = _main_gen_init_g122();
    x.DDA7 = _main_gen_init_g124();
    x.DTC7 = _main_gen_init_g126();
    x.DTCT7 = _main_gen_init_g128();
    x.DRSA7 = _main_gen_init_g132();
    x.DRDA7 = _main_gen_init_g134();
    x.DRTC7 = _main_gen_init_g136();
    x.DCEN7 = _main_gen_init_g140();
    x.DCSTC7 = _main_gen_init_g149();
    x.DTFR7 = _main_gen_init_g152();
    x.DTFRRQC7 = _main_gen_init_g158();
    x.DSA9 = _main_gen_init_g122();
    x.DDA9 = _main_gen_init_g124();
    x.DTC9 = _main_gen_init_g126();
    x.DTCT9 = _main_gen_init_g128();
    x.DRSA9 = _main_gen_init_g132();
    x.DRDA9 = _main_gen_init_g134();
    x.DRTC9 = _main_gen_init_g136();
    x.DCEN9 = _main_gen_init_g140();
    x.DCSTC9 = _main_gen_init_g149();
    x.DTFR9 = _main_gen_init_g152();
    x.DTFRRQC9 = _main_gen_init_g158();
    x.DSA10 = _main_gen_init_g122();
    x.DDA10 = _main_gen_init_g124();
    x.DTC10 = _main_gen_init_g126();
    x.DTCT10 = _main_gen_init_g128();
    x.DRSA10 = _main_gen_init_g132();
    x.DRDA10 = _main_gen_init_g134();
    x.DRTC10 = _main_gen_init_g136();
    x.DCEN10 = _main_gen_init_g140();
    x.DTFR10 = _main_gen_init_g152();
    x.DSA11 = _main_gen_init_g122();
    x.DDA11 = _main_gen_init_g124();
    x.DTC11 = _main_gen_init_g126();
    x.DTCT11 = _main_gen_init_g128();
    x.DRSA11 = _main_gen_init_g132();
    x.DRDA11 = _main_gen_init_g134();
    x.DRTC11 = _main_gen_init_g136();
    x.DCEN11 = _main_gen_init_g140();
    x.DTFR11 = _main_gen_init_g152();
    x.DSA12 = _main_gen_init_g122();
    x.DDA12 = _main_gen_init_g124();
    x.DTC12 = _main_gen_init_g126();
    x.DTCT12 = _main_gen_init_g128();
    x.DRSA12 = _main_gen_init_g132();
    x.DRDA12 = _main_gen_init_g134();
    x.DRTC12 = _main_gen_init_g136();
    x.DCEN12 = _main_gen_init_g140();
    x.DTFR12 = _main_gen_init_g152();
    x.DSA13 = _main_gen_init_g122();
    x.DDA13 = _main_gen_init_g124();
    x.DTC13 = _main_gen_init_g126();
    x.DTCT13 = _main_gen_init_g128();
    x.DRSA13 = _main_gen_init_g132();
    x.DRDA13 = _main_gen_init_g134();
    x.DRTC13 = _main_gen_init_g136();
    x.DCEN13 = _main_gen_init_g140();
    x.DTFR13 = _main_gen_init_g152();
    x.DSA14 = _main_gen_init_g122();
    x.DDA14 = _main_gen_init_g124();
    x.DTC14 = _main_gen_init_g126();
    x.DTCT14 = _main_gen_init_g128();
    x.DRSA14 = _main_gen_init_g132();
    x.DRDA14 = _main_gen_init_g134();
    x.DRTC14 = _main_gen_init_g136();
    x.DCEN14 = _main_gen_init_g140();
    x.DCSTC14 = _main_gen_init_g149();
    x.DTFR14 = _main_gen_init_g152();
    x.DTFRRQC14 = _main_gen_init_g158();
    x.DSA15 = _main_gen_init_g122();
    x.DDA15 = _main_gen_init_g124();
    x.DTC15 = _main_gen_init_g126();
    x.DTCT15 = _main_gen_init_g128();
    x.DRSA15 = _main_gen_init_g132();
    x.DRDA15 = _main_gen_init_g134();
    x.DRTC15 = _main_gen_init_g136();
    x.DCEN15 = _main_gen_init_g140();
    x.DCST15 = _main_gen_init_g143();
    x.DCSTC15 = _main_gen_init_g149();
    x.DTFR15 = _main_gen_init_g152();
    return x;
}

union __PST__g__187 _main_gen_init_g187(void)
{
    static union __PST__g__187 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__194 _main_gen_init_g194(void)
{
    static union __PST__g__194 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__201 _main_gen_init_g201(void)
{
    static union __PST__g__201 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__168 _main_gen_init_g168(void)
{
    __PST__g__168 x;
    /* struct/union type */
    x.MCTL2 = _main_gen_init_g187();
    x.RX0W = _main_gen_init_g194();
    x.MRWP0 = _main_gen_init_g201();
    return x;
}

union __PST__g__231 _main_gen_init_g231(void)
{
    static union __PST__g__231 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__225 _main_gen_init_g225(void)
{
    __PST__g__225 x;
    /* struct/union type */
    x.DR00 = _main_gen_init_g231();
    return x;
}

__PST__g__481 _main_gen_init_g481(void)
{
    __PST__g__481 x;
    /* struct/union type */
    x.DR00 = _main_gen_init_g231();
    return x;
}

union __PST__g__575 _main_gen_init_g575(void)
{
    static union __PST__g__575 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__603 _main_gen_init_g603(void)
{
    static union __PST__g__603 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__491 _main_gen_init_g491(void)
{
    __PST__g__491 x;
    /* struct/union type */
    x.DCMP0E = _main_gen_init_g575();
    x.CMPWE = _main_gen_init_g603();
    return x;
}

struct __PST__g__642 _main_gen_init_g642(void)
{
    static struct __PST__g__642 x;
    /* struct/union type */
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DmaCfgAndUse_Ip_MotAg0SnsrCfgAdr(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Ip_MotAg0SnsrCfgAdr;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Ip_MotAg0SnsrCfgAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg0ReadPtrRst(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_MotAg0ReadPtrRst;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_MotAg0ReadPtrRst = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg0SnsrCfgAdrStord(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_MotAg0SnsrCfgAdrStord;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_MotAg0SnsrCfgAdrStord = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg0TrsmStrt(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_MotAg0TrsmStrt;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_MotAg0TrsmStrt = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg1ReadPtrRst(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_MotAg1ReadPtrRst;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_MotAg1ReadPtrRst = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg1SnsrCfgAdrStord(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_MotAg1SnsrCfgAdrStord;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_MotAg1SnsrCfgAdrStord = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg1TrsmStrt(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_MotAg1TrsmStrt;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_MotAg1TrsmStrt = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__26 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_CSIH1(void)
{
    extern __PST__g__168 CSIH1;
    
    /* initialization with random value */
    {
        CSIH1 = _main_gen_init_g168();
    }
}

static void _main_gen_init_sym_CSIH3(void)
{
    extern __PST__g__168 CSIH3;
    
    /* initialization with random value */
    {
        CSIH3 = _main_gen_init_g168();
    }
}

static void _main_gen_init_sym_ADCD0(void)
{
    extern __PST__g__225 ADCD0;
    
    /* initialization with random value */
    {
        ADCD0 = _main_gen_init_g225();
    }
}

static void _main_gen_init_sym_ADCD1(void)
{
    extern __PST__g__481 ADCD1;
    
    /* initialization with random value */
    {
        ADCD1 = _main_gen_init_g481();
    }
}

static void _main_gen_init_sym_TSG31(void)
{
    extern __PST__g__491 TSG31;
    
    /* initialization with random value */
    {
        TSG31 = _main_gen_init_g491();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0RawRes(void)
{
    extern __PST__g__641 MOTCTRLMGR_MotCtrlMotAg0RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < pst_random_g_8; _main_gen_tmp_0_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg0RawRes[_main_gen_tmp_0_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes(void)
{
    extern __PST__g__641 MOTCTRLMGR_MotCtrlMotAg1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < pst_random_g_8; _main_gen_tmp_1_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg1RawRes[_main_gen_tmp_1_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc0RawRes(void)
{
    extern __PST__g__641 MOTCTRLMGR_MotCtrlAdc0RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < pst_random_g_8; _main_gen_tmp_2_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlAdc0RawRes[_main_gen_tmp_2_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31DCMP0E(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlTSG31DCMP0E;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlTSG31DCMP0E = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31CMPWE(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlTSG31CMPWE;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlTSG31CMPWE = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_TwoMilliSecToMotCtrl_Rec(void)
{
    extern struct __PST__g__642 MotCtrlMgr_TwoMilliSecToMotCtrl_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_TwoMilliSecToMotCtrl_Rec = _main_gen_init_g642();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec(void)
{
    extern struct __PST__g__642 MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec = _main_gen_init_g642();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc1RawRes(void)
{
    extern __PST__g__641 MOTCTRLMGR_MotCtrlAdc1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < pst_random_g_8; _main_gen_tmp_3_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlAdc1RawRes[_main_gen_tmp_3_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlMgr_MotCtrlToTwoMilliSec_Rec(void)
{
    extern struct __PST__g__642 MotCtrlMgr_MotCtrlToTwoMilliSec_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_MotCtrlToTwoMilliSec_Rec = _main_gen_init_g642();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec(void)
{
    extern struct __PST__g__642 MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec = _main_gen_init_g642();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return(void)
{
    extern __PST__UINT8 DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_ReadErrInjReg_ErrId(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Srv_ReadErrInjReg_ErrId;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_ReadErrInjReg_ErrId = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DmaCfgAndUse_Ip_MotAg0SnsrCfgAdr */
    _main_gen_init_sym_DmaCfgAndUse_Ip_MotAg0SnsrCfgAdr();
    
    /* init for variable DmaCfgAndUse_Pim_d2MilliSecAdcActDmaTrfTi : useless (never read) */

    /* init for variable DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi */
    _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi();
    
    /* init for variable DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi */
    _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi();
    
    /* init for variable DmaCfgAndUse_Pim_MotAg0ReadPtrRst */
    _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg0ReadPtrRst();
    
    /* init for variable DmaCfgAndUse_Pim_MotAg0SnsrCfgAdrStord */
    _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg0SnsrCfgAdrStord();
    
    /* init for variable DmaCfgAndUse_Pim_MotAg0TrsmStrt */
    _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg0TrsmStrt();
    
    /* init for variable DmaCfgAndUse_Pim_MotAg1ReadPtrRst */
    _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg1ReadPtrRst();
    
    /* init for variable DmaCfgAndUse_Pim_MotAg1SnsrCfgAdrStord */
    _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg1SnsrCfgAdrStord();
    
    /* init for variable DmaCfgAndUse_Pim_MotAg1TrsmStrt */
    _main_gen_init_sym_DmaCfgAndUse_Pim_MotAg1TrsmStrt();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
    /* init for variable CSIH1 */
    _main_gen_init_sym_CSIH1();
    
    /* init for variable CSIH3 */
    _main_gen_init_sym_CSIH3();
    
    /* init for variable ADCD0 */
    _main_gen_init_sym_ADCD0();
    
    /* init for variable ADCD1 */
    _main_gen_init_sym_ADCD1();
    
    /* init for variable TSG31 */
    _main_gen_init_sym_TSG31();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg0RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdc0RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc0RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlTSG31DCMP0E */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31DCMP0E();
    
    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPWE */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31CMPWE();
    
    /* init for variable MotCtrlMgr_TwoMilliSecToMotCtrl_Rec */
    _main_gen_init_sym_MotCtrlMgr_TwoMilliSecToMotCtrl_Rec();
    
    /* init for variable MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec */
    _main_gen_init_sym_MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdc1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc1RawRes();
    
    /* init for variable MotCtrlMgr_MotCtrlToTwoMilliSec_Rec */
    _main_gen_init_sym_MotCtrlMgr_MotCtrlToTwoMilliSec_Rec();
    
    /* init for variable MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec */
    _main_gen_init_sym_MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec();
    
    /* init for variable DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan();
    
    /* init for variable DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return */
    _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return();
    
    /* init for variable DmaCfgAndUse_Srv_ReadErrInjReg_ErrId */
    _main_gen_init_sym_DmaCfgAndUse_Srv_ReadErrInjReg_ErrId();
    
    /* init for variable DmaCfgAndUse_Cli_DmaWaitForMotCtrlTo2MilliSecTrf_Return : useless (never read) */

    /* init for variable DmaCfgAndUse_Cli_MotAg0SnsrCfgDmaStrt_Return : useless (never read) */

}
