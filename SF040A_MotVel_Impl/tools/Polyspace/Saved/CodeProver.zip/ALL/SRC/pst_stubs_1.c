#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotVel_Ip_AssiMechPolarity(void)
{
    extern __PST__SINT8 MotVel_Ip_AssiMechPolarity;
    
    /* initialization with random value */
    {
        MotVel_Ip_AssiMechPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotVel_Ip_MotAgBufIdx(void)
{
    extern __PST__UINT8 MotVel_Ip_MotAgBufIdx;
    
    /* initialization with random value */
    {
        MotVel_Ip_MotAgBufIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotVel_Ip_MotAgMeclIdptSig(void)
{
    extern __PST__UINT8 MotVel_Ip_MotAgMeclIdptSig;
    
    /* initialization with random value */
    {
        MotVel_Ip_MotAgMeclIdptSig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotVel_Pim_MotAgBufIdxPrev(void)
{
    extern __PST__UINT8 MotVel_Pim_MotAgBufIdxPrev;
    
    /* initialization with random value */
    {
        MotVel_Pim_MotAgBufIdxPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotVel_Pim_MotAgBufPrev(void)
{
    extern __PST__g__26 MotVel_Pim_MotAgBufPrev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 8; _main_gen_tmp_0_0++)
            {
                /* base type */
                MotVel_Pim_MotAgBufPrev[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotVel_Pim_MotAgTiBufPrev(void)
{
    extern __PST__g__27 MotVel_Pim_MotAgTiBufPrev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 8; _main_gen_tmp_1_0++)
            {
                /* base type */
                MotVel_Pim_MotAgTiBufPrev[_main_gen_tmp_1_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotVel_Pim_MotVelIninCntr(void)
{
    extern __PST__UINT8 MotVel_Pim_MotVelIninCntr;
    
    /* initialization with random value */
    {
        MotVel_Pim_MotVelIninCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotVel_Pim_MotAgBufIdxPrim(void)
{
    extern __PST__UINT8 MotVel_Pim_MotAgBufIdxPrim;
    
    /* initialization with random value */
    {
        MotVel_Pim_MotAgBufIdxPrim = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgMecl;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMeasTi(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlMotAgMeasTi;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMeasTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgBuf(void)
{
    extern __PST__g__26 MOTCTRLMGR_MotCtrlMotAgBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 8; _main_gen_tmp_2_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAgBuf[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgTiBuf(void)
{
    extern __PST__g__27 MOTCTRLMGR_MotCtrlMotAgTiBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 8; _main_gen_tmp_3_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAgTiBuf[_main_gen_tmp_3_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotVel_Ip_MotAgBuf(void)
{
    extern __PST__g__26 MotVel_Ip_MotAgBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 8; _main_gen_tmp_4_0++)
            {
                /* base type */
                MotVel_Ip_MotAgBuf[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotVel_Ip_MotAgTiBuf(void)
{
    extern __PST__g__27 MotVel_Ip_MotAgTiBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 8; _main_gen_tmp_5_0++)
            {
                /* base type */
                MotVel_Ip_MotAgTiBuf[_main_gen_tmp_5_0] = pst_random_g_8;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotVel_Ip_AssiMechPolarity */
    _main_gen_init_sym_MotVel_Ip_AssiMechPolarity();
    
    /* init for variable MotVel_Ip_MotAgBufIdx */
    _main_gen_init_sym_MotVel_Ip_MotAgBufIdx();
    
    /* init for variable MotVel_Ip_MotAgMeclIdptSig */
    _main_gen_init_sym_MotVel_Ip_MotAgMeclIdptSig();
    
    /* init for variable MotVel_Op_MotVelCrf : useless (never read) */

    /* init for variable MotVel_Op_MotVelMrf : useless (never read) */

    /* init for variable MotVel_Op_MotVelVld : useless (never read) */

    /* init for variable MotVel_Pim_dMotVelAvrgTi : useless (never read) */

    /* init for variable MotVel_Pim_dMotVelMotAgRef : useless (never read) */

    /* init for variable MotVel_Pim_dMotVelTiStampRef : useless (never read) */

    /* init for variable MotVel_Pim_MotAgBufIdxPrev */
    _main_gen_init_sym_MotVel_Pim_MotAgBufIdxPrev();
    
    /* init for variable MotVel_Pim_MotAgBufPrev */
    _main_gen_init_sym_MotVel_Pim_MotAgBufPrev();
    
    /* init for variable MotVel_Pim_MotAgTiBufPrev */
    _main_gen_init_sym_MotVel_Pim_MotAgTiBufPrev();
    
    /* init for variable MotVel_Pim_MotVelIninCntr */
    _main_gen_init_sym_MotVel_Pim_MotVelIninCntr();
    
    /* init for variable MotVel_Pim_MotAgBufIdxPrim */
    _main_gen_init_sym_MotVel_Pim_MotAgBufIdxPrim();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMecl */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMeasTi */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMeasTi();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgBuf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgBuf();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgTiBuf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgTiBuf();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgBufIdx : useless (never read) */

    /* init for variable MotVel_Ip_MotAgBuf */
    _main_gen_init_sym_MotVel_Ip_MotAgBuf();
    
    /* init for variable MotVel_Ip_MotAgTiBuf */
    _main_gen_init_sym_MotVel_Ip_MotAgTiBuf();
    
}
