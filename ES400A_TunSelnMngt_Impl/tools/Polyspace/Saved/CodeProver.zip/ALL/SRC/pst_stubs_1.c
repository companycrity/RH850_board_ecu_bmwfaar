#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__60 _main_gen_init_g60(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

struct __PST__g__60 _main_gen_init_g60(void)
{
    static struct __PST__g__60 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_4_0;
        
        for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 3; _main_gen_tmp_4_0++)
        {
            /* struct/union type */
            { /* array type */
                __PST__UINT32 _main_gen_tmp_5_0;
                
                for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 2; _main_gen_tmp_5_0++)
                {
                    /* struct/union type */
                    x.Seg[_main_gen_tmp_4_0].Page[_main_gen_tmp_5_0].PageAcs = _main_gen_init_g6();
                }
            }
        }
    }
    x.CopySts = _main_gen_init_g6();
    x.ActvGroup = _main_gen_init_g6();
    x.ActvInin = _main_gen_init_g6();
    x.ActvIninOptSetA = _main_gen_init_g6();
    x.ActvRt = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TunSelnMngt_Srv_Calc32BitCrc_u32_CalcCrcRes(void)
{
    extern __PST__UINT32 TunSelnMngt_Srv_Calc32BitCrc_u32_CalcCrcRes;
    
    /* initialization with random value */
    {
        TunSelnMngt_Srv_Calc32BitCrc_u32_CalcCrcRes = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Srv_Calc32BitCrc_u32_Return(void)
{
    extern __PST__UINT8 TunSelnMngt_Srv_Calc32BitCrc_u32_Return;
    
    /* initialization with random value */
    {
        TunSelnMngt_Srv_Calc32BitCrc_u32_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Srv_RtCalChgReq_Return(void)
{
    extern __PST__UINT8 TunSelnMngt_Srv_RtCalChgReq_Return;
    
    /* initialization with random value */
    {
        TunSelnMngt_Srv_RtCalChgReq_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 TunSelnMngt_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        TunSelnMngt_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_CopyCalPageReq_Seg_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_CopyCalPageReq_Seg_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_CopyCalPageReq_Seg_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Seg_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetCalPageReq_Seg_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetCalPageReq_Seg_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Mod_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetCalPageReq_Mod_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetCalPageReq_Mod_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Page_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetCalPageReq_Page_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetCalPageReq_Page_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Rtn_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetCalPageReq_Rtn_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetCalPageReq_Rtn_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Mod_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetSegInfoReq_Mod_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetSegInfoReq_Mod_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Seg_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetSegInfoReq_Seg_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetSegInfoReq_Seg_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_SegInfo_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetSegInfoReq_SegInfo_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetSegInfoReq_SegInfo_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_MpgIdx_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetSegInfoReq_MpgIdx_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetSegInfoReq_MpgIdx_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Resp_Arg(void)
{
    extern __PST__g__55 TunSelnMngt_Cli_GetSegInfoReq_Resp_Arg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 65535; _main_gen_tmp_0_0++)
            {
                /* base type */
                TunSelnMngt_Cli_GetSegInfoReq_Resp_Arg[_main_gen_tmp_0_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_RespLen_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetSegInfoReq_RespLen_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetSegInfoReq_RespLen_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Rtn_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_GetSegInfoReq_Rtn_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_GetSegInfoReq_Rtn_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqAdr_Arg(void)
{
    extern __PST__UINT32 TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqAdr_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqAdr_Arg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_OnlineTunRamAdrMpg_CorrdAdr_Arg(void)
{
    extern __PST__UINT32 TunSelnMngt_Cli_OnlineTunRamAdrMpg_CorrdAdr_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_OnlineTunRamAdrMpg_CorrdAdr_Arg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqTyp_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqTyp_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqTyp_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_SetCalPageReq_Seg_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_SetCalPageReq_Seg_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_SetCalPageReq_Seg_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_SetCalPageReq_Mod_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_SetCalPageReq_Mod_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_SetCalPageReq_Mod_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Cli_SetCalPageReq_Page_Arg(void)
{
    extern __PST__UINT8 TunSelnMngt_Cli_SetCalPageReq_Page_Arg;
    
    /* initialization with random value */
    {
        TunSelnMngt_Cli_SetCalPageReq_Page_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RteParameterRefTab(void)
{
    extern __PST__g__57 RteParameterRefTab;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 36; _main_gen_tmp_1_0++)
            {
                /* pointer */
                {
                    static __PST__SINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__SINT8)];
                    __PST__UINT32 _i_main_gen_tmp_3;
                    for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_3++)
                    {
                        _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g2();
                    }
                    RteParameterRefTab[_main_gen_tmp_1_0] = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__SINT8) / 2];
                }
            }
        }
    }
}

static void _main_gen_init_sym_TunSelnMngt_Ip_DesIninIdx(void)
{
    extern __PST__UINT8 TunSelnMngt_Ip_DesIninIdx;
    
    /* initialization with random value */
    {
        TunSelnMngt_Ip_DesIninIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Ip_DesIninOptSetAIdx(void)
{
    extern __PST__UINT8 TunSelnMngt_Ip_DesIninOptSetAIdx;
    
    /* initialization with random value */
    {
        TunSelnMngt_Ip_DesIninOptSetAIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Ip_DesRtIdx(void)
{
    extern __PST__UINT8 TunSelnMngt_Ip_DesRtIdx;
    
    /* initialization with random value */
    {
        TunSelnMngt_Ip_DesRtIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_OnlineCalSts(void)
{
    extern struct __PST__g__60 TunSelnMngt_Pim_OnlineCalSts;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_OnlineCalSts = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_PrevActvIninIdx(void)
{
    extern __PST__UINT8 TunSelnMngt_Pim_PrevActvIninIdx;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_PrevActvIninIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_PrevActvIninOptSetAIdx(void)
{
    extern __PST__UINT8 TunSelnMngt_Pim_PrevActvIninOptSetAIdx;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_PrevActvIninOptSetAIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_PrevActvRtIdx(void)
{
    extern __PST__UINT8 TunSelnMngt_Pim_PrevActvRtIdx;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_PrevActvRtIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_PrevRamPageAcs(void)
{
    extern __PST__UINT8 TunSelnMngt_Pim_PrevRamPageAcs;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_PrevRamPageAcs = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_RamTblSwt(void)
{
    extern __PST__UINT8 TunSelnMngt_Pim_RamTblSwt;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_RamTblSwt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnMngt_Pim_PrevRtIdxChgSts(void)
{
    extern __PST__UINT8 TunSelnMngt_Pim_PrevRtIdxChgSts;
    
    /* initialization with random value */
    {
        TunSelnMngt_Pim_PrevRtIdxChgSts = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TunSelnMngt_Srv_Calc32BitCrc_u32_DataPtr : useless (never read) */

    /* init for variable TunSelnMngt_Srv_Calc32BitCrc_u32_Len : useless (never read) */

    /* init for variable TunSelnMngt_Srv_Calc32BitCrc_u32_StrtVal : useless (never read) */

    /* init for variable TunSelnMngt_Srv_Calc32BitCrc_u32_FirstCall : useless (never read) */

    /* init for variable TunSelnMngt_Srv_Calc32BitCrc_u32_CalcCrcRes */
    _main_gen_init_sym_TunSelnMngt_Srv_Calc32BitCrc_u32_CalcCrcRes();
    
    /* init for variable TunSelnMngt_Srv_Calc32BitCrc_u32_Return */
    _main_gen_init_sym_TunSelnMngt_Srv_Calc32BitCrc_u32_Return();
    
    /* init for variable TunSelnMngt_Srv_RtCalChgReq_Return */
    _main_gen_init_sym_TunSelnMngt_Srv_RtCalChgReq_Return();
    
    /* init for variable TunSelnMngt_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable TunSelnMngt_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable TunSelnMngt_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable TunSelnMngt_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable TunSelnMngt_Srv_SetNtcSts_Return */
    _main_gen_init_sym_TunSelnMngt_Srv_SetNtcSts_Return();
    
    /* init for variable TunSelnMngt_Cli_CopyCalPageReq_Seg_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_CopyCalPageReq_Seg_Arg();
    
    /* init for variable TunSelnMngt_Cli_CopyCalPageReq_Return : useless (never read) */

    /* init for variable TunSelnMngt_Cli_GetCalPageReq_Seg_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Seg_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetCalPageReq_Mod_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Mod_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetCalPageReq_Page_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Page_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetCalPageReq_Rtn_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetCalPageReq_Rtn_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_Mod_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Mod_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_Seg_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Seg_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_SegInfo_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_SegInfo_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_MpgIdx_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_MpgIdx_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_Resp_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Resp_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_RespLen_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_RespLen_Arg();
    
    /* init for variable TunSelnMngt_Cli_GetSegInfoReq_Rtn_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_GetSegInfoReq_Rtn_Arg();
    
    /* init for variable TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqAdr_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqAdr_Arg();
    
    /* init for variable TunSelnMngt_Cli_OnlineTunRamAdrMpg_CorrdAdr_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_OnlineTunRamAdrMpg_CorrdAdr_Arg();
    
    /* init for variable TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqTyp_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_OnlineTunRamAdrMpg_ReqTyp_Arg();
    
    /* init for variable TunSelnMngt_Cli_SetCalPageReq_Seg_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_SetCalPageReq_Seg_Arg();
    
    /* init for variable TunSelnMngt_Cli_SetCalPageReq_Mod_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_SetCalPageReq_Mod_Arg();
    
    /* init for variable TunSelnMngt_Cli_SetCalPageReq_Page_Arg */
    _main_gen_init_sym_TunSelnMngt_Cli_SetCalPageReq_Page_Arg();
    
    /* init for variable RteParameterRefTab */
    _main_gen_init_sym_RteParameterRefTab();
    
    /* init for variable RteParameterBase : useless (never read) */

    /* init for variable TunSelnMngt_Ip_DesIninIdx */
    _main_gen_init_sym_TunSelnMngt_Ip_DesIninIdx();
    
    /* init for variable TunSelnMngt_Ip_DesIninOptSetAIdx */
    _main_gen_init_sym_TunSelnMngt_Ip_DesIninOptSetAIdx();
    
    /* init for variable TunSelnMngt_Ip_DesRtIdx */
    _main_gen_init_sym_TunSelnMngt_Ip_DesRtIdx();
    
    /* init for variable TunSelnMngt_Op_ActvGroup : useless (never read) */

    /* init for variable TunSelnMngt_Op_ActvIninIdx : useless (never read) */

    /* init for variable TunSelnMngt_Op_ActvIninOptSetAIdx : useless (never read) */

    /* init for variable TunSelnMngt_Op_ActvRtIdx : useless (never read) */

    /* init for variable TunSelnMngt_Op_CalCopySts : useless (never read) */

    /* init for variable TunSelnMngt_Op_RtIdxChgSts : useless (never read) */

    /* init for variable TunSelnMngt_Pim_OnlineCalSts */
    _main_gen_init_sym_TunSelnMngt_Pim_OnlineCalSts();
    
    /* init for variable TunSelnMngt_Pim_PrevActvIninIdx */
    _main_gen_init_sym_TunSelnMngt_Pim_PrevActvIninIdx();
    
    /* init for variable TunSelnMngt_Pim_PrevActvIninOptSetAIdx */
    _main_gen_init_sym_TunSelnMngt_Pim_PrevActvIninOptSetAIdx();
    
    /* init for variable TunSelnMngt_Pim_PrevActvRtIdx */
    _main_gen_init_sym_TunSelnMngt_Pim_PrevActvRtIdx();
    
    /* init for variable TunSelnMngt_Pim_PrevRamPageAcs */
    _main_gen_init_sym_TunSelnMngt_Pim_PrevRamPageAcs();
    
    /* init for variable TunSelnMngt_Pim_RamTblSwt */
    _main_gen_init_sym_TunSelnMngt_Pim_RamTblSwt();
    
    /* init for variable TunSelnMngt_Pim_PrevRtIdxChgSts */
    _main_gen_init_sym_TunSelnMngt_Pim_PrevRtIdxChgSts();
    
}
