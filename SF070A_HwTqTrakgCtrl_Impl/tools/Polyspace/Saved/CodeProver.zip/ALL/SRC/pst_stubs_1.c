#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__25 _main_gen_init_g25(void);

extern struct __PST__g__22 _main_gen_init_g22(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__22 _main_gen_init_g22(void)
{
    static struct __PST__g__22 x;
    /* struct/union type */
    x.MotVelEstimd = _main_gen_init_g10();
    x.TorsBarTqEstimd = _main_gen_init_g10();
    x.TorsBarRotatmEstimd = _main_gen_init_g10();
    x.DrvrTqEstimd = _main_gen_init_g10();
    x.RackTqEstimd = _main_gen_init_g10();
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwTqTrakgCtrl_Ip_HwTqCmd(void)
{
    extern __PST__FLOAT32 HwTqTrakgCtrl_Ip_HwTqCmd;
    
    /* initialization with random value */
    {
        HwTqTrakgCtrl_Ip_HwTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Ip_MotTqCmdOvrl(void)
{
    extern __PST__FLOAT32 HwTqTrakgCtrl_Ip_MotTqCmdOvrl;
    
    /* initialization with random value */
    {
        HwTqTrakgCtrl_Ip_MotTqCmdOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Ip_SysTqRat(void)
{
    extern __PST__FLOAT32 HwTqTrakgCtrl_Ip_SysTqRat;
    
    /* initialization with random value */
    {
        HwTqTrakgCtrl_Ip_SysTqRat = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Ip_TorsBarStEstimd(void)
{
    extern struct __PST__g__22 HwTqTrakgCtrl_Ip_TorsBarStEstimd;
    
    /* initialization with random value */
    {
        HwTqTrakgCtrl_Ip_TorsBarStEstimd = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 HwTqTrakgCtrl_Ip_VehSpd;
    
    /* initialization with random value */
    {
        HwTqTrakgCtrl_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain1(void)
{
    extern __PST__g__23 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 4; _main_gen_tmp_0_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain1[_main_gen_tmp_0_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain2(void)
{
    extern __PST__g__23 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain2;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 4; _main_gen_tmp_1_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain2[_main_gen_tmp_1_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain3(void)
{
    extern __PST__g__23 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain3;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain3[_main_gen_tmp_2_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain4(void)
{
    extern __PST__g__23 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain4;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 4; _main_gen_tmp_3_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain4[_main_gen_tmp_3_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain5(void)
{
    extern __PST__g__23 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain5;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 4; _main_gen_tmp_4_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain5[_main_gen_tmp_4_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFfGainScaY(void)
{
    extern __PST__g__23 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFfGainScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 4; _main_gen_tmp_5_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFfGainScaY[_main_gen_tmp_5_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlMotTqCmdOvrlGain(void)
{
    extern __PST__g__25 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlMotTqCmdOvrlGain;
    
    /* initialization with random value */
    {
        HwTqTrakgCtrl_Cal_HwTqTrakgCtrlMotTqCmdOvrlGain = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlVehSpdScaX(void)
{
    extern __PST__g__26 HwTqTrakgCtrl_Cal_HwTqTrakgCtrlVehSpdScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 4; _main_gen_tmp_6_0++)
            {
                /* base type */
                HwTqTrakgCtrl_Cal_HwTqTrakgCtrlVehSpdScaX[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwTqTrakgCtrl_Ip_HwTqCmd */
    _main_gen_init_sym_HwTqTrakgCtrl_Ip_HwTqCmd();
    
    /* init for variable HwTqTrakgCtrl_Ip_MotTqCmdOvrl */
    _main_gen_init_sym_HwTqTrakgCtrl_Ip_MotTqCmdOvrl();
    
    /* init for variable HwTqTrakgCtrl_Ip_SysTqRat */
    _main_gen_init_sym_HwTqTrakgCtrl_Ip_SysTqRat();
    
    /* init for variable HwTqTrakgCtrl_Ip_TorsBarStEstimd */
    _main_gen_init_sym_HwTqTrakgCtrl_Ip_TorsBarStEstimd();
    
    /* init for variable HwTqTrakgCtrl_Ip_VehSpd */
    _main_gen_init_sym_HwTqTrakgCtrl_Ip_VehSpd();
    
    /* init for variable HwTqTrakgCtrl_Op_MotTqCmdTrakgCtrl : useless (never read) */

    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain1 */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain1();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain2 */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain2();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain3 */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain3();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain4 */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain4();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain5 */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFbGain5();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFfGainScaY */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlFfGainScaY();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlMotTqCmdOvrlGain */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlMotTqCmdOvrlGain();
    
    /* init for variable HwTqTrakgCtrl_Cal_HwTqTrakgCtrlVehSpdScaX */
    _main_gen_init_sym_HwTqTrakgCtrl_Cal_HwTqTrakgCtrlVehSpdScaX();
    
}
