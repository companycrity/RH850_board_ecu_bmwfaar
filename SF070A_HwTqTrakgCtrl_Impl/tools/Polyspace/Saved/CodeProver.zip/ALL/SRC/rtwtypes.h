
#ifndef RTWTYPES_H
#define RTWTYPES_H

/* The contents of rtwtypes.h has been removed since this definition is not used for the autocode compilation. 
However we cannot remove this file since this is included in the Component.h file */

               
#endif    
