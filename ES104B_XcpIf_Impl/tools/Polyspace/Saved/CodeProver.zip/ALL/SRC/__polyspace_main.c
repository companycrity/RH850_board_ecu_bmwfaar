#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile enum __PST__g__34 pst_random_g_34;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern enum __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

enum __PST__g__34 _main_gen_init_g34(void)
{
    enum __PST__g__34 x;
    /* enum */
    x = pst_random_g_34;
    
    /* range value according to enum bounds */
    unchecked_assert(x >= 0);
    unchecked_assert(x <= 2);
    
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_XcpAppl_GetTimestamp(void)
{
    extern __PST__UINT16 XcpAppl_GetTimestamp(__PST__VOID);

    __PST__UINT16 __ret__;
    
    
    /* call it */
    __ret__ = XcpAppl_GetTimestamp();
}

static void _main_gen_call_XcpAppl_MeasurementRead(void)
{
    extern __PST__UINT8 XcpAppl_MeasurementRead(__PST__g__16, __PST__UINT32, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__g__16 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT8 __arg__2;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = XcpAppl_MeasurementRead(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_XcpAppl_CalibrationWrite(void)
{
    extern __PST__UINT8 XcpAppl_CalibrationWrite(__PST__UINT32, __PST__g__20, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT32 __arg__0;
    __PST__g__20 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = XcpAppl_CalibrationWrite(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_XcpAppl_CalibrationWriteTrustd(void)
{
    extern __PST__UINT8 XcpAppl_CalibrationWriteTrustd(__PST__UINT32, __PST__g__20, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT32 __arg__0;
    __PST__g__20 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = XcpAppl_CalibrationWriteTrustd(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_XcpAppl_GetPointer(void)
{
    extern __PST__UINT32 XcpAppl_GetPointer(__PST__UINT8, __PST__UINT8, __PST__g__25);

    __PST__UINT32 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__g__25 __arg__2;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g25();
    
    /* call it */
    __ret__ = XcpAppl_GetPointer(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_XcpAppl_CheckReadAccess(void)
{
    extern __PST__UINT8 XcpAppl_CheckReadAccess(__PST__UINT8, __PST__UINT32, __PST__UINT32);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT32 __arg__2;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = XcpAppl_CheckReadAccess(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_XcpAppl_OpenCmdIf(void)
{
    extern __PST__UINT8 XcpAppl_OpenCmdIf(__PST__UINT8, __PST__g__20, __PST__g__16, __PST__g__16);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__g__20 __arg__1;
    __PST__g__16 __arg__2;
    __PST__g__16 __arg__3;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = XcpAppl_OpenCmdIf(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_XcpAppl_SetCalPage(void)
{
    extern __PST__UINT8 XcpAppl_SetCalPage(__PST__UINT8, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = XcpAppl_SetCalPage(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_XcpAppl_GetCalPage(void)
{
    extern __PST__UINT8 XcpAppl_GetCalPage(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = XcpAppl_GetCalPage(__arg__0, __arg__1);
}

static void _main_gen_call_XcpAppl_CopyCalPage(void)
{
    extern __PST__UINT8 XcpAppl_CopyCalPage(__PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT8 __arg__3;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = XcpAppl_CopyCalPage(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_XcpAppl_UserService(void)
{
    extern __PST__UINT8 XcpAppl_UserService(__PST__g__20);

    __PST__UINT8 __ret__;
    __PST__g__20 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = XcpAppl_UserService(__arg__0);
}

static void _main_gen_call_XcpAppl_ConStateNotification(void)
{
    extern __PST__VOID XcpAppl_ConStateNotification(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    XcpAppl_ConStateNotification(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_Rte_Call_CopyCalPageReq_Oper(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_Rte_Call_CopyCalPageReq_Oper(enum __PST__g__34, __PST__g__11);

    enum __PST__g__34 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g34();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_Rte_Call_CopyCalPageReq_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_Rte_Call_SetCalPageReq_Oper(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_Rte_Call_SetCalPageReq_Oper(enum __PST__g__34, __PST__g__11);

    enum __PST__g__34 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g34();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_Rte_Call_SetCalPageReq_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_Xcp_Event(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_Xcp_Event(enum __PST__g__34, __PST__g__11);

    enum __PST__g__34 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g34();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_Xcp_Event(__arg__0, __arg__1);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function XcpAppl_GetTimestamp */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_GetTimestamp();
        }
        
        /* call of function XcpAppl_MeasurementRead */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_MeasurementRead();
        }
        
        /* call of function XcpAppl_CalibrationWrite */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_CalibrationWrite();
        }
        
        /* call of function XcpAppl_CalibrationWriteTrustd */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_CalibrationWriteTrustd();
        }
        
        /* call of function XcpAppl_GetPointer */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_GetPointer();
        }
        
        /* call of function XcpAppl_CheckReadAccess */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_CheckReadAccess();
        }
        
        /* call of function XcpAppl_OpenCmdIf */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_OpenCmdIf();
        }
        
        /* call of function XcpAppl_SetCalPage */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_SetCalPage();
        }
        
        /* call of function XcpAppl_GetCalPage */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_GetCalPage();
        }
        
        /* call of function XcpAppl_CopyCalPage */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_CopyCalPage();
        }
        
        /* call of function XcpAppl_UserService */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_UserService();
        }
        
        /* call of function XcpAppl_ConStateNotification */
        if (PST_TRUE())
        {
            _main_gen_call_XcpAppl_ConStateNotification();
        }
        
        /* call of function NONTRUSTED_NtWrapS_Rte_Call_CopyCalPageReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_Rte_Call_CopyCalPageReq_Oper();
        }
        
        /* call of function NONTRUSTED_NtWrapS_Rte_Call_SetCalPageReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_Rte_Call_SetCalPageReq_Oper();
        }
        
        /* call of function NONTRUSTED_NtWrapS_Xcp_Event */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_Xcp_Event();
        }
        
        /* call of function CDD_XcpIfXcpEveCh2MilliSecPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CDD_XcpIfXcpEveCh2MilliSecPer1(__PST__VOID);

            CDD_XcpIfXcpEveCh2MilliSecPer1();
        }
        
        /* call of function Rte_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_Stub(__PST__VOID);

            Rte_Stub();
        }
        
    }
}
