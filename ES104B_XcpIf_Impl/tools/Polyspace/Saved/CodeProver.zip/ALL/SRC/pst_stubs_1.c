#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__50 _main_gen_init_g50(void);

extern __PST__UINT8 _main_gen_init_g6(void);

union __PST__g__50 _main_gen_init_g50(void)
{
    static union __PST__g__50 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_21_0;
        
        for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 28; _main_gen_tmp_21_0++)
        {
            /* base type */
            x.b[_main_gen_tmp_21_0] = pst_random_g_6;
        }
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_XcpIf_Ip_ActvGroup(void)
{
    extern __PST__UINT8 XcpIf_Ip_ActvGroup;
    
    /* initialization with random value */
    {
        XcpIf_Ip_ActvGroup = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Ip_ActvIninIdx(void)
{
    extern __PST__UINT8 XcpIf_Ip_ActvIninIdx;
    
    /* initialization with random value */
    {
        XcpIf_Ip_ActvIninIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Ip_ActvRtIdx(void)
{
    extern __PST__UINT8 XcpIf_Ip_ActvRtIdx;
    
    /* initialization with random value */
    {
        XcpIf_Ip_ActvRtIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Ip_CalCopySts(void)
{
    extern __PST__UINT8 XcpIf_Ip_CalCopySts;
    
    /* initialization with random value */
    {
        XcpIf_Ip_CalCopySts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Ip_CustXcpEna(void)
{
    extern __PST__UINT8 XcpIf_Ip_CustXcpEna;
    
    /* initialization with random value */
    {
        XcpIf_Ip_CustXcpEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Ip_MfgEnaSt(void)
{
    extern __PST__UINT8 XcpIf_Ip_MfgEnaSt;
    
    /* initialization with random value */
    {
        XcpIf_Ip_MfgEnaSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Xcp_ChannelInfo(void)
{
    extern __PST__g__48 Xcp_ChannelInfo;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 1; _main_gen_tmp_20_0++)
            {
                /* struct/union type */
                Xcp_ChannelInfo[_main_gen_tmp_20_0].ResponseFrame = _main_gen_init_g50();
                Xcp_ChannelInfo[_main_gen_tmp_20_0].ResponseFrameLength = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_XcpIf_Srv_CopyCalPageReq_Return(void)
{
    extern __PST__UINT8 XcpIf_Srv_CopyCalPageReq_Return;
    
    /* initialization with random value */
    {
        XcpIf_Srv_CopyCalPageReq_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_GetCalPageReq_Page_Arg(void)
{
    extern __PST__UINT8 XcpIf_Srv_GetCalPageReq_Page_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Srv_GetCalPageReq_Page_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_GetCalPageReq_Rtn_Arg(void)
{
    extern __PST__UINT8 XcpIf_Srv_GetCalPageReq_Rtn_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Srv_GetCalPageReq_Rtn_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_GetSegInfoReq_Resp_Arg(void)
{
    extern __PST__UINT8 XcpIf_Srv_GetSegInfoReq_Resp_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Srv_GetSegInfoReq_Resp_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_GetSegInfoReq_RespLen_Arg(void)
{
    extern __PST__UINT8 XcpIf_Srv_GetSegInfoReq_RespLen_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Srv_GetSegInfoReq_RespLen_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_GetSegInfoReq_Rtn_Arg(void)
{
    extern __PST__UINT8 XcpIf_Srv_GetSegInfoReq_Rtn_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Srv_GetSegInfoReq_Rtn_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_OnlineTunRamAdrMpg_CorrdAdr_Arg(void)
{
    extern __PST__UINT32 XcpIf_Srv_OnlineTunRamAdrMpg_CorrdAdr_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Srv_OnlineTunRamAdrMpg_CorrdAdr_Arg = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_XcpIf_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 XcpIf_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        XcpIf_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_ActvRtIdx_Arg(void)
{
    extern __PST__UINT8 XcpIf_Cli_ActvTunStsReq_ActvRtIdx_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Cli_ActvTunStsReq_ActvRtIdx_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_ActvIninIdx_Arg(void)
{
    extern __PST__UINT8 XcpIf_Cli_ActvTunStsReq_ActvIninIdx_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Cli_ActvTunStsReq_ActvIninIdx_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_CalChgAllwd_Arg(void)
{
    extern __PST__UINT8 XcpIf_Cli_ActvTunStsReq_CalChgAllwd_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Cli_ActvTunStsReq_CalChgAllwd_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_ActvGroup_Arg(void)
{
    extern __PST__UINT8 XcpIf_Cli_ActvTunStsReq_ActvGroup_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Cli_ActvTunStsReq_ActvGroup_Arg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_CalCopyCmpl_Arg(void)
{
    extern __PST__UINT8 XcpIf_Cli_ActvTunStsReq_CalCopyCmpl_Arg;
    
    /* initialization with random value */
    {
        XcpIf_Cli_ActvTunStsReq_CalCopyCmpl_Arg = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable XcpIf_Ip_ActvGroup */
    _main_gen_init_sym_XcpIf_Ip_ActvGroup();
    
    /* init for variable XcpIf_Ip_ActvIninIdx */
    _main_gen_init_sym_XcpIf_Ip_ActvIninIdx();
    
    /* init for variable XcpIf_Ip_ActvRtIdx */
    _main_gen_init_sym_XcpIf_Ip_ActvRtIdx();
    
    /* init for variable XcpIf_Ip_CalCopySts */
    _main_gen_init_sym_XcpIf_Ip_CalCopySts();
    
    /* init for variable XcpIf_Ip_CustXcpEna */
    _main_gen_init_sym_XcpIf_Ip_CustXcpEna();
    
    /* init for variable XcpIf_Ip_MfgEnaSt */
    _main_gen_init_sym_XcpIf_Ip_MfgEnaSt();
    
    /* init for variable Xcp_ControlState : useless (never read) */

    /* init for variable Xcp_ChannelInfo */
    _main_gen_init_sym_Xcp_ChannelInfo();
    
    /* init for variable XcpIf_Srv_CopyCalPageReq_Seg_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_CopyCalPageReq_Return */
    _main_gen_init_sym_XcpIf_Srv_CopyCalPageReq_Return();
    
    /* init for variable XcpIf_Srv_GetCalPageReq_Seg_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetCalPageReq_Mod_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetCalPageReq_Page_Arg */
    _main_gen_init_sym_XcpIf_Srv_GetCalPageReq_Page_Arg();
    
    /* init for variable XcpIf_Srv_GetCalPageReq_Rtn_Arg */
    _main_gen_init_sym_XcpIf_Srv_GetCalPageReq_Rtn_Arg();
    
    /* init for variable XcpIf_Srv_GetSegInfoReq_Mod_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetSegInfoReq_Seg_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetSegInfoReq_SegInfo_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetSegInfoReq_MpgIdx_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetSegInfoReq_Resp_Arg */
    _main_gen_init_sym_XcpIf_Srv_GetSegInfoReq_Resp_Arg();
    
    /* init for variable XcpIf_Srv_GetSegInfoReq_RespLen_Arg */
    _main_gen_init_sym_XcpIf_Srv_GetSegInfoReq_RespLen_Arg();
    
    /* init for variable XcpIf_Srv_GetSegInfoReq_Rtn_Arg */
    _main_gen_init_sym_XcpIf_Srv_GetSegInfoReq_Rtn_Arg();
    
    /* init for variable XcpIf_Srv_OnlineTunRamAdrMpg_ReqAdr_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_OnlineTunRamAdrMpg_CorrdAdr_Arg */
    _main_gen_init_sym_XcpIf_Srv_OnlineTunRamAdrMpg_CorrdAdr_Arg();
    
    /* init for variable XcpIf_Srv_OnlineTunRamAdrMpg_ReqTyp_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_SetCalPageReq_Seg_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_SetCalPageReq_Mod_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_SetCalPageReq_Page_Arg : useless (never read) */

    /* init for variable XcpIf_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_XcpIf_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable XcpIf_Cli_ActvTunStsReq_ActvRtIdx_Arg */
    _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_ActvRtIdx_Arg();
    
    /* init for variable XcpIf_Cli_ActvTunStsReq_ActvIninIdx_Arg */
    _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_ActvIninIdx_Arg();
    
    /* init for variable XcpIf_Cli_ActvTunStsReq_CalChgAllwd_Arg */
    _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_CalChgAllwd_Arg();
    
    /* init for variable XcpIf_Cli_ActvTunStsReq_ActvGroup_Arg */
    _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_ActvGroup_Arg();
    
    /* init for variable XcpIf_Cli_ActvTunStsReq_CalCopyCmpl_Arg */
    _main_gen_init_sym_XcpIf_Cli_ActvTunStsReq_CalCopyCmpl_Arg();
    
}
