#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_CDD_XcpIf_ActvIninOptSetAIdx_Val
 */


__PST__UINT8 Rte_Read_CDD_XcpIf_ActvIninOptSetAIdx_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Xcp_Event
 */

#pragma POLYSPACE_POLYMORPHIC "Xcp_Event"


__PST__UINT8 Xcp_Event(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Os_CallNonTrustedFunction
 */


__PST__UINT8 Os_CallNonTrustedFunction(enum __PST__g__34 P_0, __PST__g__11 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * GetApplicationID
 */

#pragma POLYSPACE_POLYMORPHIC "GetApplicationID"


enum __PST__g__60 GetApplicationID(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile enum __PST__g__60 real_random_for_return  = 0;
        enum __PST__g__60 random_for_return = real_random_for_return;
        
        /* range value according to enum bounds */
        unchecked_assert(random_for_return >= 0);
        unchecked_assert(random_for_return <= 0);
        
        return random_for_return;
    }
}

/*
 * Os_Call_XcpAppl_CalibrationWriteTrustd
 */

#pragma POLYSPACE_POLYMORPHIC "Os_Call_XcpAppl_CalibrationWriteTrustd"


__PST__UINT8 Os_Call_XcpAppl_CalibrationWriteTrustd(__PST__UINT32 P_0, __PST__g__20 P_1, __PST__UINT8 P_2)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

