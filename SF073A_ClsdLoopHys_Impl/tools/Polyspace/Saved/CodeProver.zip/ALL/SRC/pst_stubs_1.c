#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ClsdLoopHys_Ip_HwAg(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Ip_HwAg;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Ip_HwTqCmdEffort(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Ip_HwTqCmdEffort;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Ip_HwTqCmdEffort = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Ip_HwVel(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Ip_HwVel;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Ip_RackFEstimd(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Ip_RackFEstimd;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Ip_RackFEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Ip_SysFricOffs(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Ip_SysFricOffs;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Ip_SysFricOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Ip_VehSpd;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysDeltaY(void)
{
    extern __PST__g__22 ClsdLoopHys_Cal_ClsdLoopHysDeltaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 12; _main_gen_tmp_0_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysDeltaY[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysGainY(void)
{
    extern __PST__g__22 ClsdLoopHys_Cal_ClsdLoopHysGainY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 12; _main_gen_tmp_1_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysGainY[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgBlndFac(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysHwAgBlndFac;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysHwAgBlndFac = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndX(void)
{
    extern __PST__g__25 ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 2; _main_gen_tmp_2_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndY(void)
{
    extern __PST__g__25 ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 2; _main_gen_tmp_3_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrX(void)
{
    extern __PST__g__25 ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 2; _main_gen_tmp_4_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrX[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrY(void)
{
    extern __PST__g__25 ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 2; _main_gen_tmp_5_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndX(void)
{
    extern __PST__g__25 ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 2; _main_gen_tmp_6_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndX[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndY(void)
{
    extern __PST__g__25 ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 2; _main_gen_tmp_7_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysPolarity(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysPolarity;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysPolarity = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysRackFFacX(void)
{
    extern __PST__g__26 ClsdLoopHys_Cal_ClsdLoopHysRackFFacX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 4; _main_gen_tmp_8_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysRackFFacX[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysRackFFacY(void)
{
    extern __PST__g__27 ClsdLoopHys_Cal_ClsdLoopHysRackFFacY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 12; _main_gen_tmp_9_0++)
            {
                __PST__UINT32 _main_gen_tmp_9_1;
                
                for (_main_gen_tmp_9_1 = 0; _main_gen_tmp_9_1 < 4; _main_gen_tmp_9_1++)
                {
                    /* base type */
                    ClsdLoopHys_Cal_ClsdLoopHysRackFFacY[_main_gen_tmp_9_0][_main_gen_tmp_9_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysRhoY(void)
{
    extern __PST__g__22 ClsdLoopHys_Cal_ClsdLoopHysRhoY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 12; _main_gen_tmp_10_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysRhoY[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegLowrLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegLowrLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegLowrLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegUpprLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegUpprLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegUpprLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosLowrLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosLowrLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosLowrLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosUpprLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosUpprLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosUpprLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegLowrLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegLowrLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegLowrLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegUpprLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegUpprLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegUpprLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosLowrLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosLowrLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosLowrLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosUpprLim(void)
{
    extern __PST__g__24 ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosUpprLim;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosUpprLim = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimX(void)
{
    extern __PST__g__28 ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 5; _main_gen_tmp_11_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimX[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimY(void)
{
    extern __PST__g__28 ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 5; _main_gen_tmp_12_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimY[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricScaX(void)
{
    extern __PST__g__29 ClsdLoopHys_Cal_ClsdLoopHysSysFricScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 7; _main_gen_tmp_13_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysSysFricScaX[_main_gen_tmp_13_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricScaY(void)
{
    extern __PST__g__31 ClsdLoopHys_Cal_ClsdLoopHysSysFricScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 7; _main_gen_tmp_14_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_ClsdLoopHysSysFricScaY[_main_gen_tmp_14_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__22 ClsdLoopHys_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 12; _main_gen_tmp_15_0++)
            {
                /* base type */
                ClsdLoopHys_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_15_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_ClsdLoopHys_Pim_IntgtrSt(void)
{
    extern __PST__FLOAT32 ClsdLoopHys_Pim_IntgtrSt;
    
    /* initialization with random value */
    {
        ClsdLoopHys_Pim_IntgtrSt = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ClsdLoopHys_Ip_HwAg */
    _main_gen_init_sym_ClsdLoopHys_Ip_HwAg();
    
    /* init for variable ClsdLoopHys_Ip_HwTqCmdEffort */
    _main_gen_init_sym_ClsdLoopHys_Ip_HwTqCmdEffort();
    
    /* init for variable ClsdLoopHys_Ip_HwVel */
    _main_gen_init_sym_ClsdLoopHys_Ip_HwVel();
    
    /* init for variable ClsdLoopHys_Ip_RackFEstimd */
    _main_gen_init_sym_ClsdLoopHys_Ip_RackFEstimd();
    
    /* init for variable ClsdLoopHys_Ip_SysFricOffs */
    _main_gen_init_sym_ClsdLoopHys_Ip_SysFricOffs();
    
    /* init for variable ClsdLoopHys_Ip_VehSpd */
    _main_gen_init_sym_ClsdLoopHys_Ip_VehSpd();
    
    /* init for variable ClsdLoopHys_Op_HwTqCmdHys : useless (never read) */

    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysDeltaY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysDeltaY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysGainY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysGainY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwAgBlndFac */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgBlndFac();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndX */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndX();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadBlndY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrX */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrX();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwAgQuadQlfrY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndX */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndX();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysHwVelQuadBlndY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysPolarity */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysPolarity();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysRackFFacX */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysRackFFacX();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysRackFFacY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysRackFFacY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysRhoY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysRhoY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegLowrLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegLowrLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegUpprLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgNegUpprLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosLowrLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosLowrLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosUpprLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerInHwAgPosUpprLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegLowrLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegLowrLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegUpprLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgNegUpprLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosLowrLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosLowrLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosUpprLim */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSteerOutHwAgPosUpprLim();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimX */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimX();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricOffsLimY();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSysFricScaX */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricScaX();
    
    /* init for variable ClsdLoopHys_Cal_ClsdLoopHysSysFricScaY */
    _main_gen_init_sym_ClsdLoopHys_Cal_ClsdLoopHysSysFricScaY();
    
    /* init for variable ClsdLoopHys_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_ClsdLoopHys_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable ClsdLoopHys_Pim_IntgtrSt */
    _main_gen_init_sym_ClsdLoopHys_Pim_IntgtrSt();
    
}
